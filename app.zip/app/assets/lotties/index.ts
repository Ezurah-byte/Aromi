export const Lotties = {
  pop: require('../lotties/pop.json'),
  loader: require('../lotties/loader.json'),
};
