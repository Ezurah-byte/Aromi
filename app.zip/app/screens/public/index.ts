import AuthScreen from './authScreen';
import OtpScreen from './otpScreen';

export {AuthScreen, OtpScreen};
