import {View, Text, TouchableOpacity} from 'react-native';
import React, {useState} from 'react';
import {sizeConfig, storage, styleConfig} from '@utils/index';
import {PhoneNumber} from '@molecules/index';
import {Colors} from '@theme/colors';
import {Button, HeaderText, ContenText, GrayText} from '@atoms/index';
import {AppleVector, GoogleVector} from '@vectors/vectorImages';
import {navigate} from '@root/';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';
import NumberValidate from 'libphonenumber-js';
import Animated from 'react-native-reanimated';
import {starterAnimation} from '@animation/starterAnimation';
const AuthScreen = () => {
  const {ms, vs, wh} = sizeConfig;
  const {container} = styleConfig;
  const [number, setCurrentNumber] = useState(null);
  const [errorNumber, setErrorNumber] = useState(false);
  const [countryCode, setCountryCode] = useState({
    dial_code: '+91',
    code: 'IN',
  });

  const hanldeNumber = value => {
    console.log(value, 'handleNumber');
    setCurrentNumber(value);
  };

  const submitLogin = () => {
    const data = countryCode.dial_code + number;
    console.log(data, 'data');
    const isValidPhoneNumber = NumberValidate(data, countryCode.code);
    console.log('isValidPhoneNumber');

    if (isValidPhoneNumber?.isValid()) {
      console.log('success');
      setErrorNumber(false);
      navigate('otpScreen', {
        mobileNumber: number,
        dailCode: countryCode.dial_code,
      });
    } else {
      console.log('invalide number');
      setErrorNumber(true);
    }
    // Example with a US number
  };
  return (
    <View style={{...container, flexGrow: 1}}>
      <KeyboardAwareScrollView>
        <Animated.View
          {...starterAnimation('FadeInDown', 500, 500, 0)}
          style={{
            gap: vs(12),
            // flex: 1.7
            paddingVertical: vs(25),
          }}
          className="justify-center">
          <HeaderText content={'Log in / Sign Up'} />
          <ContenText
            content={
              'To get start with your Ezurah account we need mobile number.'
            }
          />
        </Animated.View>

        <Animated.View
          {...starterAnimation('FadeInDown', 500, 200, 1)}
          style={{
            // flex: 1.3,
            paddingVertical: vs(20),

            gap: vs(12),
          }}>
          <PhoneNumber
            {...{
              countryCode,
              setCountryCode,
              currentValue: number,
              handleChange: hanldeNumber,
              placeholder: 'EX:9834575932',
              holderColor: Colors.gy,
              error: errorNumber,
            }}
          />

          <View className="flex-row flex-wrap">
            <Text
              className="text-gy font-inr"
              style={{fontSize: ms(14)}}></Text>
            <GrayText content={'By registering you accept our '} />
            <TouchableOpacity>
              <Text className="font-inr text-vt" style={{fontSize: ms(14)}}>
                {' '}
                Terms of Use{' '}
              </Text>
            </TouchableOpacity>
            <GrayText content={' and '} />

            <TouchableOpacity>
              <Text className="font-inr text-vt" style={{fontSize: ms(14)}}>
                Privacy Policy{' '}
              </Text>
            </TouchableOpacity>
          </View>
        </Animated.View>
        <Animated.View {...starterAnimation('FadeInDown', 500, 200, 2)}>
          <View
            style={{
              // flex: 1.3,
              paddingVertical: vs(10),

              gap: vs(10),
            }}
            className="justify-center">
            <Button
              {...{
                enable: number?.length > 8 && number?.length < 13,
                label: 'Log In',
                onClick: () => submitLogin(),
              }}
            />
            <View
              className="mt-4 flex-row  justify-center items-center"
              style={{gap: ms(12)}}>
              <View className="border-b-[1px] flex-1 border-ph" />
              <GrayText content={'Or'} />
              <View className="border-b-[1px] flex-1  border-ph" />
            </View>
          </View>

          <View
            style={{
              gap: vs(16),
              // flex: 3
              paddingVertical: vs(10),
            }}>
            <TouchableOpacity
              className={`rounded-lg bg-ds justify-center border-ph border-[1.5px]`}
              style={{height: vs(44)}}>
              <View
                className="justify-center items-center flex-row"
                style={{gap: ms(9)}}>
                <GoogleVector />
                <Text
                  className={`text-center text-bls  font-in_sbl`}
                  style={{fontSize: ms(16)}}>
                  Sign in with Google
                </Text>
              </View>
            </TouchableOpacity>
            <TouchableOpacity
              className={`rounded-lg bg-b justify-center  border-[1.5px]`}
              style={{height: vs(44)}}>
              <View
                className="justify-center items-center flex-row"
                style={{gap: ms(9)}}>
                <AppleVector />
                <Text
                  className={`text-center text-w  font-in_sbl`}
                  style={{fontSize: ms(14)}}>
                  Sign in with Apple
                </Text>
              </View>
            </TouchableOpacity>
          </View>
        </Animated.View>
      </KeyboardAwareScrollView>
    </View>
  );
};

export default AuthScreen;
