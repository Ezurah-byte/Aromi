import {View, Text} from 'react-native';
import React, {useState} from 'react';
import {styleConfig} from '@utils/commonStyles';
import {
  HeaderBack,
  ContenText,
  OtpField,
  ButtonQuestion,
  HeaderText,
} from '@atoms/index';
import {sizeConfig, storage} from '@utils/index';
import {navigate} from '@root/*';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';
import Animated from 'react-native-reanimated';
import {starterAnimation} from '@animation/starterAnimation';

const OtpScreen = ({navigation, route: {params}}) => {
  const {container} = styleConfig;
  const {vs} = sizeConfig;
  const [isValid, setIsValid] = useState(false);

  return (
    <View style={container}>
      <KeyboardAwareScrollView>
        <Animated.View {...starterAnimation('FadeInUp', 500, 200, 1)}>
          <HeaderBack
            navigation={() => {
              navigation.goBack();
            }}
          />
        </Animated.View>
        <Animated.View
          {...starterAnimation('FadeInDown', 500, 200, 1)}
          style={{
            gap: vs(15),
            // flex: 1.5
            paddingVertical: vs(0),
          }}>
          <HeaderText content={'Enter OTP'} />
          <ContenText
            content={`Enter the 4-digit code sent to your mobile number (${
              params?.dailCode
            }) ${params?.mobileNumber || ''}`}
          />
        </Animated.View>
        <Animated.View
          {...starterAnimation('FadeInDown', 500, 300, 2)}
          style={{
            gap: vs(22),
            // flex: 5
            paddingVertical: vs(40),
          }}>
          <OtpField mobileNumber={params?.mobileNumber} />

          <ButtonQuestion
            onClick={() => {
              navigation.goBack();
            }}
            content="Change your mobile number?"
          />
        </Animated.View>
      </KeyboardAwareScrollView>
    </View>
  );
};

export default OtpScreen;
