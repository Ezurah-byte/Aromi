import {View, Text, Image, StatusBar} from 'react-native';
import React from 'react';
import {GradientView, HeaderTwo, Button, HeaderText} from '@atoms/index';
import {Images} from '@images/index';
import {sizeConfig, BarHeight} from '@utils/index';
import FastImage from 'react-native-fast-image';
import {navigate} from '@root/';
import Animated from 'react-native-reanimated';
import {starterAnimation} from '@animation/starterAnimation';
const WifiSuccess = () => {
  const {tOverlay, bOverlay, cWifi, wDevice} = Images;
  const {wh, ms, vs} = sizeConfig;
  return (
    <GradientView isfull={true} colors={['#1B1F24', '#102522']}>
      <StatusBar barStyle={'light-content'} />
      <Animated.View
        {...starterAnimation('FadeInUp', 500, 200, 1)}
        style={{position: 'absolute', top: 0, zIndex: 0, left: 0}}>
        <Image source={tOverlay} style={{width: wh, height: 200}} />
      </Animated.View>
      <Animated.View
        {...starterAnimation('FadeInDown', 500, 200, 1)}
        style={{position: 'absolute', bottom: 0, zIndex: 0, left: 0}}>
        <Image source={bOverlay} style={{width: wh, height: 200}} />
      </Animated.View>
      <View style={{marginTop: BarHeight, flex: 1}}>
        <HeaderTwo bg="none" iconC="#FFFFFF" single={true} />

        <Animated.View
          {...starterAnimation('FadeInDown', 500, 200, 1)}
          className="justify-center "
          style={{flex: 0.7, rowGap: vs(10)}}>
          <FastImage
            resizeMode="contain"
            source={Images.success}
            style={{
              height: '45%',
              width: '100%',
              // position: 'absolute',
              // zIndex: 999,
              // bottom: 20,
            }}
          />
          <Text
            className="font-inbl text-center text-lgr"
            style={{fontSize: ms(16)}}>
            Aromi device added successfully
          </Text>
          <Text
            className="font-inm text-center text-lgr"
            style={{fontSize: ms(14)}}>
            Make sure you have connect to your Aromi device’s Wi-Fi:
            Exurah_Device_XXX
          </Text>
        </Animated.View>
      </View>
      <Animated.View
        {...starterAnimation('FadeInDown', 500, 200, 1)}
        className=" justify-center"
        style={{flex: 0.1, marginHorizontal: vs(30)}}>
        <Button
          {...{
            onClick: () => {
              navigate('trayName', {});
            },
            label: 'Next',
            // border: true,
            // bcl: 'bg-vt',
            // bcc: 'border-vt',
            // c: 'text-w',
            enable: true,
          }}
        />
      </Animated.View>
    </GradientView>
  );
};

export default WifiSuccess;
