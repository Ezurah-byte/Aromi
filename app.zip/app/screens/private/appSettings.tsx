import {View, Text, TouchableOpacity, FlatList} from 'react-native';
import React, {memo, useState} from 'react';
import {styleConfig} from '@utils/commonStyles';
import {
  HeaderText,
  HeaderTwo,
  Button,
  RoundedImage,
  GrayText,
  ButtonEdit,
} from '@atoms/index';
import {sizeConfig} from '@utils/sizeConfig';
import {Images} from '@images/index';
import {Colors} from '@theme/colors';
import {PhoneNumber, TextField} from '@molecules/index';
import ToggleSwitch from 'toggle-switch-react-native';
import Animated from 'react-native-reanimated';
import {starterAnimation} from '@animation/starterAnimation';
const AppSettings = ({navigation}) => {
  const {containerX} = styleConfig;
  const {ms, vs} = sizeConfig;
  const [number, setCurrentNumber] = useState(null);
  const [name, setName] = useState('');
  const [isNotify, setIsNotify] = useState(true);
  const [isGoogle, setIsGoogle] = useState(true);
  const [isApple, setIsApple] = useState(true);
  const toggleSwitch = () => setIsEnabled(previousState => !previousState);

  const swicthMenu = [
    {
      name: 'Push Notification',
      content: 'Receive notifications about Tray’s, Smart Jar and Spice level.',
      value: isNotify,
      action: () => {
        setIsNotify(!isNotify);
      },
    },
    // {
    //   name: 'Google',
    //   content: 'Sign in with Google for a seamless experience',
    //   value: isGoogle,
    //   action: () => {
    //     setIsGoogle(!isGoogle);
    //   },
    // },
    // {
    //   name: 'Apple',
    //   content: 'Sign in with Apple for a seamless experience',
    //   value: isApple,
    //   action: () => {
    //     setIsApple(!isApple);
    //   },
    // },
    {
      name: 'Version',
      content: 'App build version',
      isVersion: true,
    },
  ];

  const RenderSwitch = ({item, index}) => {
    const {name, content} = item;
    return (
      <View
        key={index}
        className={`rounded-lg items-center  flex-row border-[#F7F7F7] ${
          index != 0 && index != 3 ? 'border-[1px]' : ''
        } `}
        style={{
          height: vs(60),
          paddingHorizontal: vs(10),
          //   paddingVertical: vs(10),
        }}>
        <View style={{flex: 1, rowGap: vs(0)}}>
          <View>
            <Text className="font-in_sbl text-blp" style={{fontSize: ms(14)}}>
              {name}
            </Text>
          </View>
          <View className="flex-row gap-x-2">
            <View className="flex-row items-center" style={{columnGap: ms(3)}}>
              <GrayText content={content} color={Colors.mgy} size={12} />
            </View>
          </View>
        </View>
        <View className=" items-center bg-white" style={{flex: 0.3}}>
          {item?.isVersion ? (
            <GrayText content={'1.0.1'} color={Colors.blp} size={14} />
          ) : (
            <ToggleSwitch
              isOn={item?.value}
              onColor="#7F56D9"
              offColor="#F2F4F7"
              onToggle={isOn => {
                item?.action();
                console.log('changed to : ', isOn);
              }}
            />
          )}
        </View>
      </View>
    );
  };
  return (
    <View style={containerX}>
      <View>
        <HeaderTwo
          navigation={() => {
            navigation.goBack();
          }}
          header={'App Settings'}
          bottom={true}
        />
      </View>
      <Animated.View
        // {...starterAnimation('FadeInLeft', 500, 500, 1)}
        style={{paddingHorizontal: ms(12), paddingVertical: vs(10)}}
        className="flex-1 bg-[#F5F7FA]">
        <View className="rounded-lg bg-w" style={{paddingVertical: vs(10)}}>
          {/* {swicthMenu.map((item, index) => {
            return <RenderSwitch item={item} index={index} />;
          })} */}

          <FlatList
            data={swicthMenu}
            renderItem={({item, index}) => (
              <RenderSwitch item={item} index={index} />
            )}
            keyExtractor={item => item.name}
          />
        </View>
      </Animated.View>
      <View
        style={{flex: 0.11, paddingHorizontal: ms(20)}}
        className="justify-center bg-red border-t-[1.5px] border-[#E3E5F0]">
        <Animated.View {...starterAnimation('FadeInDown', 500, 500, 1)}>
          <Button
            {...{
              enable: true,
              label: 'Save',
            }}
          />
        </Animated.View>
      </View>
    </View>
  );
};

export default AppSettings;
