import {View, Text, ImageBackground, TouchableOpacity} from 'react-native';
import React, {useState, useRef} from 'react';
import {styleConfig} from '@utils/commonStyles';
import {
  HeaderText,
  HeaderTwo,
  Button,
  RoundedImage,
  GrayText,
  DatePicker,
  DropDown,
  SpiceSheet,
  ButtonEdit,
} from '@atoms/index';
import {sizeConfig} from '@utils/sizeConfig';
import {Colors} from '@theme/colors';
import {Images} from '@images/index';
import ToggleSwitch from 'toggle-switch-react-native';
import {navigate} from '@root/';
import Animated from 'react-native-reanimated';
import {starterAnimation} from '@animation/starterAnimation';
import BottomSheet from '@gorhom/bottom-sheet';
import {useAppDispatch, useAppSelector} from '@hooks/';
import {updateJar, setJar} from '@library/features/auth/userSlice';
import uuid from 'react-native-uuid';
import moment from 'moment';
import {AnimatedCircularProgress} from 'react-native-circular-progress';

const SmartJar = ({navigation, route: {params}}) => {
  const dispatch = useAppDispatch();
  const user = useAppSelector(state => state?.user);
  const {addTray, trayDetails, Cindex} = params;
  const gramsPer = Cindex == 0 ? 50 : Cindex == 1 ? 70 : Cindex == 2 ? 35 : 80;
  const grams = (gramsPer / 100) * 300;
  const jarData = params?.jarData;
  const isLayout = jarData?.layouts;

  console.log(jarData, 'jarData jarData', moment(jarData?.expDate).format(''));
  const {containerX} = styleConfig;
  const {ms, vs} = sizeConfig;
  const [isEnabled, setIsEnabled] = useState(true);
  const [showQuantity, setShowQuantity] = useState(jarData?.showQuantity);
  const [sendNofication, setNotification] = useState(jarData?.sendNofication);
  const [expDate, setExpDate] = useState(jarData?.expDate || null);
  const [showDate, setShowDate] = useState(false);
  const [spiceType, setSpiceType] = useState(jarData?.spiceType || null);
  const [sheetOpen, setSheetOpen] = useState(false);
  const bottomSpiceSheet = useRef<BottomSheet>(null);
  const [spiceName, setSpiceName] = useState(jarData?.spiceName || null);
  const [spicePx, setSpicePx] = useState(isLayout?.spicePx || 0);
  const [spicePy, setSpicePy] = useState(isLayout?.spicePy || 0);
  const [spiceFontsize, setSpiceFontsize] = useState(
    isLayout?.spiceFontsize || 36,
  );
  const [spiceAlign, setSpiceAlign] = useState(isLayout?.spiceAlign || 1);
  const [spiceLayout, setSpiceLayout] = useState(isLayout?.spiceLayout || 0);
  const [spiceStyle, setSpiceStyle] = useState(
    isLayout?.spiceStyle || {
      bold: false,
      italic: false,
      underline: false,
    },
  );

  const openSheet = () => {
    console.log(sheetOpen, 'Sheet open');
    setSheetOpen(true);
  };

  const closeSheet = () => {
    setSheetOpen(false);
  };

  const swicthMenu = [
    {
      name: 'Spice Quantity',
      content: `${grams} grams`,
      value: gramsPer,
      isquantity: true,
      grams: grams,
    },
    {
      name: 'Show Quantity',
      content: 'Spice quantity will be shown in grams',
      value: showQuantity,
      action: () => {
        setShowQuantity(!showQuantity);
      },
    },
    {
      name: 'Send Notifications',
      content: 'Alert when spice level is low than 20%',
      value: sendNofication,
      action: () => {
        setNotification(!sendNofication);
      },
    },
  ];

  const handleSave = () => {
    let jarTempData = {
      spiceName,
      expDate: moment(expDate).format(''),
      spiceType,
      showQuantity,
      sendNofication,
      layouts: {
        spicePx,
        spicePy,
        spiceAlign,
        spiceFontsize,
        spiceStyle,
        spiceLayout,
      },
      id: !addTray ? jarData?.id : uuid.v4(),
    };
    if (addTray) {
      let tempJar = [...trayDetails.jars];
      console.log(tempJar, 'temp Jar');

      tempJar.push(jarTempData);
      console.log(tempJar, 'temp Jar');
      dispatch(
        setJar({
          name: 'setJar',
          data: {
            jars: tempJar,
            id: trayDetails.id,
          },
        }),
      );
      navigate('homeScreen', {});
    } else {
      dispatch(
        updateJar({
          name: 'updateJar',
          data: {
            jarData: jarTempData,
            id: trayDetails.id,
            jarId: jarTempData.id,
          },
        }),
      );
      navigate('homeScreen', {});
    }
  };

  const handleLayout = (name, px, py, al, st, fz, ly) => {
    console.log('value handleSetSpiceName', name, px, py, al, st, fz, ly);
    setSpiceName(name);
    setSpicePx(px);
    setSpicePy(py);
    setSpiceAlign(al);
    setSpiceStyle(st);
    setSpiceFontsize(fz);
    setSpiceLayout(ly);
  };
  const RenderSwitch = ({item, index}) => {
    const {name, content} = item;
    return (
      <View
        key={index}
        className=" rounded-lg items-center flex-row border-[#F7F7F7] border-[1px]"
        style={{
          height: vs(53),
          paddingHorizontal: vs(10),
          marginVertical: 0,
        }}>
        <View className=" " style={{flex: 0.2}}>
          {item?.isquantity ? (
            <AnimatedCircularProgress
              size={43}
              width={2}
              backgroundWidth={8}
              fill={item?.value}
              tintColor="#FFFFFF"
              backgroundColor="#7F56D9">
              {fill => (
                <Text
                  className="font-in_sbl text-blp"
                  style={{fontSize: vs(7)}}>
                  {item?.grams}
                </Text>
              )}
            </AnimatedCircularProgress>
          ) : (
            <ToggleSwitch
              isOn={item?.value}
              onColor="#7F56D9"
              offColor="#F2F4F7"
              onToggle={isOn => {
                item?.action();
                console.log('changed to : ', isOn);
              }}
            />
          )}
        </View>

        <View style={{flex: 1, rowGap: vs(0)}}>
          <View>
            <Text className="font-inm text-blp" style={{fontSize: ms(13)}}>
              {name}
            </Text>
          </View>
          <View className="flex-row gap-x-2">
            <View className="flex-row items-center" style={{columnGap: ms(3)}}>
              <GrayText content={content} color={Colors.mgy} size={12} />
            </View>
          </View>
        </View>
      </View>
    );
  };
  console.log(spicePx, spicePy, 'spice types ######################');
  const hvNm = spiceName?.length > 0;
  return (
    <View style={containerX}>
      <View style={{flex: 0.1}}>
        <HeaderTwo
          navigation={() => {
            navigation.goBack();
          }}
          header={'Add Smart Jar'}
          bottom={true}
        />
      </View>
      <View style={{}} className="flex-1 bg-bggy">
        <View style={{paddingVertical: vs(10)}}>
          <Animated.View
            {...starterAnimation('FadeInUp', 500, 200, 1)}
            className="items-center">
            <ImageBackground
              // source={Images.nameBoard}
              source={
                spiceName?.length > 0
                  ? spiceLayout == 0
                    ? Images.emptyBoard
                    : spiceLayout == 1
                    ? Images.rightBoard
                    : spiceLayout == 2
                    ? Images.equalBoard
                    : Images.verticalBoard
                  : Images.nameBoard
              }
              resizeMode="cover"
              className="justify-center items-center mt-2"
              style={{
                height: 200,
                width: 320,
                borderRadius: 50,
                // backgroundColor: hvNm ? 'white' : 'white',
              }}>
              {expDate && spiceName?.length > 0 && (
                <View
                  className="absolute"
                  style={{
                    height: 150,
                    width: 320,
                    borderRadius: 50,
                    zIndex: 5,
                    justifyContent: 'flex-end',
                    alignItems: 'center',
                    paddingVertical: vs(10),
                    paddingHorizontal: vs(10),
                    // backgroundColor: hvNm ? 'white' : 'white',
                  }}>
                  <View style={{}}>
                    <Text
                      className={`${
                        spiceLayout == 0 ? 'text-blp' : 'text-w'
                      } font-inm`}
                      style={{fontSize: ms(16)}}>
                      Exp : {moment(expDate).format('MMM D, YYYY')}
                    </Text>
                  </View>
                </View>
              )}
              {hvNm && (
                <TouchableOpacity
                  className="absolute top-2 right-2"
                  style={{
                    zIndex: 10,
                  }}
                  onPress={() => {
                    navigate('customizeLayout', {
                      handleSave,
                      spiceName,
                      handleLayout,
                      spicePx,
                      spicePy,
                      spiceAlign,
                      spiceFontsize,
                      spiceStyle,
                      spiceLayout,
                    });
                  }}>
                  <ButtonEdit isBg={true} />
                </TouchableOpacity>
              )}
              {!(spiceName?.length > 0) ? (
                <TouchableOpacity
                  onPress={() => {
                    navigate('customizeLayout', {
                      handleSave,
                      spiceName,
                      handleLayout,

                      spicePx,
                      spicePy,
                      spiceAlign,
                      spiceFontsize,
                      spiceStyle,
                      spiceLayout,
                    });
                  }}
                  className="flex-row  w-1/2 items-center justify-center gap-x-1 border-[1px] border-ph px-2 bg-w rounded-lg py-[6px]">
                  <Text
                    className="font-in_sbl text-blp text-center"
                    style={{fontSize: vs(10)}}>
                    Add Spice Name
                  </Text>
                </TouchableOpacity>
              ) : (
                <View
                  className={''}
                  style={[
                    {
                      flex: 1,
                      width: '100%',
                      backgroundColor: 'transparent',
                      borderRadius: 3,
                      transform: [{translateX: spicePx}, {translateY: spicePy}],
                    },
                  ]}>
                  <Text
                    className={'text-b'}
                    style={{
                      fontWeight: spiceStyle?.bold ? 'bold' : '300',
                      textDecorationLine: spiceStyle?.underline
                        ? 'underline'
                        : 'none',
                      fontStyle: spiceStyle?.italic ? 'italic' : '',
                      fontSize: spiceFontsize,
                    }}>
                    {spiceName}
                  </Text>
                </View>
              )}
            </ImageBackground>
            <View
              className={`flex-row mt-3 items-center ${
                hvNm ? 'bg-[#ECFDF3]' : ''
              } gap-x-1 border-[1px] ${
                hvNm ? 'border-[#ABEFC6]' : 'border-ph'
              }  px-2 rounded-xl py-[1px]`}>
              <View
                className={`h-2 w-2 rounded-full ${
                  hvNm ? 'bg-[#17B26A]' : 'bg-slate-500'
                } `}
              />
              <Text
                className={`font-inm ${
                  hvNm ? 'text-[#067647]' : 'text-slate-500'
                }  text-center`}
                style={{fontSize: vs(10)}}>
                Preview
              </Text>
            </View>
          </Animated.View>
          <Animated.View {...starterAnimation('SlideInDown', 500, 200, 1)}>
            <View style={{paddingHorizontal: ms(10), rowGap: vs(5)}}>
              <DropDown {...{openSheet, spiceType, setSpiceType}} />
              <DatePicker {...{showDate, setShowDate, expDate, setExpDate}} />
            </View>

            <View style={{paddingVertical: vs(10)}}>
              <View>
                <Text></Text>
              </View>
              {swicthMenu.map((item, index) => {
                return <RenderSwitch item={item} index={index} />;
              })}
            </View>
          </Animated.View>
        </View>
      </View>
      <View
        style={{flex: 0.11, paddingHorizontal: ms(20)}}
        className="justify-center bg-red border-t-[1.5px] border-[#E3E5F0]">
        <Animated.View {...starterAnimation('FadeInDown', 500, 200, 1)}>
          <Button
            {...{
              onClick: handleSave,
              label: 'Save',
              // border: true,
              // bcl: 'bg-w',
              // bcc: 'border-fb',
              // c: 'text-vt',
              enable: spiceName && expDate && spiceType,
            }}
          />
        </Animated.View>
      </View>

      {sheetOpen && (
        <SpiceSheet
          {...{
            modalRef: bottomSpiceSheet,
            openSheet,
            closeSheet,
            snap: ['50%', '50%'],
            spiceType,
            setSpiceType,
          }}
        />
      )}
    </View>
  );
};

export default SmartJar;
