import React, {useCallback, useEffect, useRef, useState} from 'react';

import {
  DashBoardHeader,
  DashedView,
  EditNameSheet,
  GradientView,
  GrayText,
  HeaderText,
  InfiniteRotatingImage,
  Modal,
  TraySheet,
} from '@atoms/index';
import {
  View,
  Text,
  SafeAreaView,
  useWindowDimensions,
  TouchableOpacity,
  Image,
  ScrollView,
  PermissionsAndroid,
  Platform,
} from 'react-native';
import BleManager from 'react-native-ble-manager';

import BottomSheet from '@gorhom/bottom-sheet';
import {useToast} from 'react-native-toast-notifications';
import LottieView from 'lottie-react-native';

import {Colors} from '@theme/colors';
import {sizeConfig} from '@utils/sizeConfig';
import {LogoAI, StarAI} from '@vectors/vectorImages';
import {Images} from '@images/index';
import {styleConfig, storage} from '@utils/index';
import {CollapsibleView, TrayMenu} from '@molecules/index';
import {Lotties} from '@lotties/index';
import FastImage from 'react-native-fast-image';
import {navigate} from '@root/';
import {useFocusEffect} from '@react-navigation/native';
import Animated from 'react-native-reanimated';
import {starterAnimation} from '@animation/starterAnimation';
import {useAppDispatch, useAppSelector} from '@hooks/';
import {setUser} from '@library/features/auth/userSlice';
import {
  PERMISSIONS,
  request,
  requestMultiple,
  RESULTS,
} from 'react-native-permissions';
const HomeScreen = ({navigation, route}) => {
  const user = useAppSelector(state => state?.user);
  // const totalJars = user?.trays.reduce(
  //   (acc, item) => acc + item.jars.length,
  //   0,
  // );
  const jarsArray = user?.trays.reduce((acc, tray) => {
    return acc.concat(
      tray.jars.map((jar, index) => {
        console.log(jar.spiceName, 'spice name index:', index);
        return jar.spiceName;
      }),
    );
  }, []);
  useEffect(() => {}, []);
  const requestBluetoothPermission = async () => {
    console.log('requestBluetoothPermission', Platform.Version);
    if (Platform.OS == 'ios') {
      return await request(PERMISSIONS.IOS.BLUETOOTH_PERIPHERAL);
    } else {
      if (Platform.Version >= 31) {
        console.log(`[Ble Scan Platform >23] ${Platform.Version}`);
        const result = await requestMultiple([
          PERMISSIONS.ANDROID.BLUETOOTH_SCAN,
          PERMISSIONS.ANDROID.BLUETOOTH_CONNECT,
          PERMISSIONS.ANDROID.ACCESS_FINE_LOCATION,
        ]);

        return Object.values(result).every(x => x === RESULTS.GRANTED)
          ? result[PERMISSIONS.ANDROID.BLUETOOTH_SCAN]
          : 'denied';
      } else {
        console.log('[Ble Scan Platform <23]');
        return await request(PERMISSIONS.ANDROID.ACCESS_FINE_LOCATION);
      }
    }
  };

  console.log(jarsArray, 'total Jarsdd: length');
  const dispatch = useAppDispatch();

  const [sheetOpen, setSheetOpen] = useState(false);

  const toast = useToast();
  const {ms, vs} = sizeConfig;
  const {shadow1} = styleConfig;
  const bottomTraySheet = useRef<BottomSheet>(null);

  const openSheet = () => {
    console.log(sheetOpen, 'Sheet open');
    setSheetOpen(true);
  };

  const closeSheet = () => {
    setSheetOpen(false);
  };
  /* 2. Get the param */
  console.log(JSON.stringify(user.trays), 'Params home screeen');

  useFocusEffect(
    React.useCallback(() => {
      // Do something when the screen is focused
      console.log('tray Added useFocusEffect', route?.params?.isTrayAdded);

      if (route.params?.isTrayAdded) {
        toast.show('This is a customized toast! you can implement your own', {
          type: 'custom_toast',
          animationDuration: 100,
          data: {
            title: 'Customized toast',
          },
        });
      }
    }, []),
  );

  useEffect(() => {
    console.log('tray Added', route?.params?.isTrayAdded);
  }, [route?.params?.isTrayAdded]);

  useEffect(() => {
    try {
      const lastLogin = storage.getString('lastLogin');
      console.log('Already have a lastLogin', lastLogin);

      const userDataStringfy = storage.getString(`${lastLogin}`);
      let userData = JSON.parse(userDataStringfy);
      console.log('Already have a number', userData);
      dispatch(
        setUser({
          name: 'allData',
          data: userData,
        }),
      );
    } catch (e) {
      console.log('new Login  number');
    }
  }, []);

  return (
    <>
      <GradientView colors={['#FFF4ED', '#FCE6FF', '#D4EBFF', '#D1FEFC']}>
        <SafeAreaView className="flex-1">
          <DashBoardHeader
            content="Home"
            openSheet={async () => {
              const btResult = await requestBluetoothPermission();

              if (btResult === RESULTS.GRANTED) {
                BleManager.start({showAlert: false}).then(() => {
                  // Success code
                  console.log('Module initialized');
                });

                BleManager.enableBluetooth()
                  .then(async () => {
                    setSheetOpen(true);

                    console.log(
                      'BleManager',
                      'The BT is already enabled or the user confirm',
                    );
                  })
                  .catch(error => {
                    console.log(
                      'BleManager',
                      `The user refuse to enable bluetooth - ${error}`,
                    );
                  });
              } else {
              }
            }}
            isRight={true}
          />

          <ScrollView showsVerticalScrollIndicator={false}>
            {!(user?.trays?.length > 0) && (
              <Animated.View
                {...starterAnimation('FadeInDown', 500, 200, 0)}
                className="bg-w items-center  flex-row rounded-xl "
                style={{
                  height: vs(110),
                  width: '100%',
                  ...shadow1,
                }}>
                <View
                  className=" justify-center px-3 flex-1 h-full"
                  style={{rowGap: vs(5)}}>
                  <HeaderText content={'Get Started'} />
                  <GrayText content={'Pair your AROMI Tray'} />
                  <TouchableOpacity
                    onPress={async () => {
                      const btResult = await requestBluetoothPermission();

                      if (btResult === RESULTS.GRANTED) {
                        BleManager.start({showAlert: false}).then(() => {
                          // Success code
                          console.log('Module initialized');
                        });

                        BleManager.enableBluetooth()
                          .then(async () => {
                            setSheetOpen(true);

                            console.log(
                              'BleManager',
                              'The BT is already enabled or the user confirm',
                            );
                          })
                          .catch(error => {
                            console.log(
                              'BleManager',
                              `The user refuse to enable bluetooth - ${error}`,
                            );
                          });
                      } else {
                      } // storage.set(
                      //   'arraytest',
                      //   JSON.stringify({
                      //     name: 'akilan',
                      //     trays: [{name: 'akilan'}],
                      //   }),
                      // );
                      // const datacheck = storage.getString('arraytest');
                      // console.log(datacheck, 'dataacheck add now ');
                    }}>
                    <Text
                      className="text-nvt font-in_sbl"
                      style={{fontSize: ms(14)}}>
                      Add now
                    </Text>
                  </TouchableOpacity>
                </View>
                <View className="flex-1  items-end ">
                  <Image
                    style={{height: '100%', width: ms(129)}}
                    source={Images.addTray}
                    resizeMode="contain"
                    className="rounded-br-xl rounded-tr-xl "
                  />
                </View>
              </Animated.View>
            )}
            {user?.trays?.length > 0 && (
              <View>
                <Animated.View {...starterAnimation('FadeInDown', 500, 200, 0)}>
                  <TouchableOpacity
                    onPress={() => {
                      // setSingleTrayVisible(true);
                      navigate('recipeList', {recipeList: jarsArray});
                    }}>
                    {jarsArray?.length >= 4 && (
                      <DashedView
                        borderRadius={10}
                        color={Colors.nvt}
                        height={115}>
                        <View
                          className="flex-row gap-x-5  "
                          style={{
                            height: 115,
                            width: 356,
                            paddingHorizontal: ms(14),
                            // paddingVertical: vs(10),
                          }}>
                          <View className=" justify-center">
                            <InfiniteRotatingImage
                              source={Images.nLogo}
                              style={{width: vs(45), height: vs(45)}}
                            />
                          </View>
                          <View
                            className="justify-center flex-1"
                            style={{rowGap: ms(8)}}>
                            <View className="flex-row items-center">
                              <Text
                                className="font-in_sbl text-b"
                                style={{fontSize: ms(16)}}>
                                Hi, my name is Nuvolux
                              </Text>
                              <View className="ml-2">
                                <Image
                                  source={Images.niLogo}
                                  style={{width: vs(15), height: vs(15)}}
                                  resizeMode="contain"
                                />
                              </View>
                            </View>
                            <View className="flex-row flex-wrap">
                              <View>
                                <Text
                                  className="font-inr text-mgy "
                                  style={{
                                    fontSize: ms(12),
                                    lineHeight: ms(18),
                                  }}>
                                  Get personalised recipe suggestions based on
                                  your spice jars.{' '}
                                  <Text className="font-inm underline text-center text-nvt">
                                    Explore now
                                  </Text>
                                </Text>
                              </View>
                            </View>
                          </View>
                        </View>
                      </DashedView>
                    )}
                  </TouchableOpacity>
                </Animated.View>

                <View className="my-1"></View>
                <CollapsibleView trays={user.trays} navigation={navigation} />
              </View>
            )}
          </ScrollView>
        </SafeAreaView>
        {/* <TrayMenu {...{modalRef: bottomSheetModalRef, openSheet, closeSheet}} /> */}
        {sheetOpen && (
          <TraySheet
            {...{
              modalRef: bottomTraySheet,
              openSheet,
              closeSheet,
              snap: ['20%', '30%'],
            }}
          />
        )}
      </GradientView>
      {/* {true && <Modal type={'loader'} close={setSingleTrayVisible} />} */}
    </>
  );
};

export default HomeScreen;
