import {Text, View, TouchableOpacity} from 'react-native';
import React from 'react';
import {
  GradientView,
  DashBoardHeader,
  RoundedImage,
  HeaderText,
  GrayText,
} from '@atoms/index';
import {Images} from '@images/index';
import {sizeConfig} from '@utils/sizeConfig';
import {Colors} from '@theme/colors';
import {Read} from '@vectors/vectorImages';
import Animated from 'react-native-reanimated';
import {starterAnimation} from '@animation/starterAnimation';

const NotificationScreen = () => {
  const {noNotify} = Images;
  const {ms, vs, wh} = sizeConfig;
  return (
    <GradientView colors={['#FFF4ED', '#FCE6FF', '#D4EBFF', '#D1FEFC']}>
      <DashBoardHeader content="Notification" />
      <View style={{flex: 1}}>
        <Animated.View
          {...starterAnimation('FadeInUp', 500, 200, 1)}
          className="flex-row">
          <View className="flex-1">
            <Text className="font-in_sbl  text-blp text-start">Today</Text>
          </View>
          <View className="flex-1 ">
            <Text className="text-right font-in_sbl underline text-vt">
              Mark all read
            </Text>
          </View>
        </Animated.View>
        <Animated.View {...starterAnimation('FadeInDown', 500, 500, 1)}>
          <View style={{paddingVertical: vs(20)}}>
            <View
              className="bg-[#ECF4FA] items-center justify-center rounded-lg "
              style={{
                // height: vs(73),
                paddingHorizontal: vs(10),
                marginVertical: 0,
                paddingVertical: vs(15),
              }}>
              <View className="flex-row">
                <View className=" " style={{flex: 0.15}}>
                  <Read />
                </View>

                <View style={{flex: 1, rowGap: vs(0)}}>
                  <View>
                    <HeaderText
                      content={'Alert: Hey there, Welcome to EZURAH.!'}
                      size={14}
                    />
                  </View>
                </View>
              </View>
              <View className="mt-3">
                <Text className="text-mgy font-inr text-start">
                  Elevate your cooking game with Nuvolux. Sync your Smart Tray
                  and get customized recipe recommendations at your fingertips.
                </Text>
                <Text className="text-mgy mt-1 font-inr ">Just now</Text>
              </View>
            </View>
          </View>
          <Text
            className="text-center font-inebl text-blp "
            style={{fontSize: vs(10)}}>
            That’s all your notifications from last 30 days
          </Text>
        </Animated.View>
      </View>

      {/* <View className={'flex-1 justify-center'}>
        <Image
          source={noNotify}
          resizeMode="contain"
          style={{width: vs(300), height: vs(200)}}
        />
      </View> */}
    </GradientView>
  );
};

export default NotificationScreen;
