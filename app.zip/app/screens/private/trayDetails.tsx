import {
  View,
  Text,
  StatusBar,
  Image,
  TouchableOpacity,
  ScrollView,
} from 'react-native';
import React, {useState, useRef, useCallback} from 'react';
import {Images} from '@images/index';
import {sizeConfig} from '@utils/sizeConfig';
import {EditNameSheet, TrayJar} from '@atoms/index';
import {Delete, EditIcon, WhiteBackArrow} from '@vectors/vectorImages';
import {BarHeight} from '@utils/barHeight';
import ToggleSwitch from 'toggle-switch-react-native';
import {navigate} from '@root/';
import Animated from 'react-native-reanimated';
import {starterAnimation} from '@animation/starterAnimation';
import {useAppDispatch, useAppSelector} from '@hooks/index';
import {Colors} from '@theme/colors';
import {setUser, updateTray} from '@library/features/auth/userSlice';

const TrayDetails = ({navigation, route: {params}}) => {
  const dispatch = useAppDispatch();

  const {trayDetails} = params;
  const user = useAppSelector(state => state?.user);
  console.log(trayDetails.name, 'TrayDetails');
  const {vs, ms} = sizeConfig;
  const [, setIsEnabled] = useState(true);
  const [isBattery, setIsBattery] = useState(trayDetails?.showBattery);
  const [isJarCount, setIsJarCount] = useState(trayDetails?.showJarCount);
  const [isJarDetails, setIsJarDetails] = useState(trayDetails?.showJarDetails);
  const [sheetOpen, setSheetOpen] = useState(false);
  const [name, setName] = useState(trayDetails?.name || '');

  const bottomEditSheetRef = useRef<BottomSheet>(null);

  const openSheet = type => {
    // bottomSheetModalRef.current?.present();
    setSheetOpen(true);
  };

  const closeSheet = () => {
    setSheetOpen(false);
    // bottomSheetModalRef.current?.dismiss();
  };

  const handleName = value => {
    console.log('handleName', value);
    setName(value);
    dispatch(
      updateTray({
        name: 'name',
        data: {
          id: trayDetails?.id,
          value: value,
        },
      }),
    );
    closeSheet();
  };

  const trayMenus = [
    {
      name: name,
    },
    {
      name: 'Show Battery',
      action: () => {
        setIsBattery(!isBattery);
        dispatch(
          updateTray({
            name: 'showBattery',
            data: {
              id: trayDetails?.id,
              value: !isBattery,
            },
          }),
        );
      },
      value: isBattery,
    },
    {
      name: 'Show Jar Count',
      action: () => {
        setIsJarCount(!isJarCount);
        dispatch(
          updateTray({
            name: 'showJarCount',
            data: {
              id: trayDetails?.id,
              value: !isJarCount,
            },
          }),
        );
      },
      value: isJarCount,
    },
    {
      name: 'Show Jar Details',
      action: () => {
        setIsJarDetails(!isJarDetails);
        dispatch(
          updateTray({
            name: 'showJarDetails',
            data: {
              id: trayDetails?.id,
              value: !isJarDetails,
            },
          }),
        );
      },
      value: isJarDetails,
    },
  ];

  const RenderSwitch = ({item, index}) => {
    const {name, content} = item;
    return (
      <View
        key={index}
        className={` items-center  flex-row border-[#F7F7F7] ${
          index != 0 && index != 3 ? 'border-[1px]' : ''
        } `}
        style={{
          height: vs(50),
          paddingHorizontal: vs(10),
          //   paddingVertical: vs(10),
        }}>
        <View style={{flex: 1, rowGap: vs(0)}}>
          <View>
            <Text className="font-inm text-blp" style={{fontSize: ms(14)}}>
              {name}
            </Text>
          </View>
        </View>
        {index == 0 ? (
          <TouchableOpacity
            onPress={() => {
              setSheetOpen(true);
            }}
            className="flex-row gap-x-2 justify-center items-center">
            <Text className="font-in_sbl text-blp " style={{fontSize: vs(12)}}>
              {name}
            </Text>
            <View>
              <EditIcon />
            </View>
          </TouchableOpacity>
        ) : (
          <View className=" items-center" style={{flex: 0.3}}>
            <ToggleSwitch
              isOn={item?.value}
              onColor="#7F56D9"
              offColor="#F2F4F7"
              onToggle={isOn => {
                item?.action();
                console.log('changed to : ', isOn);
              }}
            />
          </View>
        )}
      </View>
    );
  };
  return (
    <View style={{flex: 1, backgroundColor: Colors.bggy}}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* <View className="flex-1"> */}
        <StatusBar barStyle={'light-content'} />
        <View className="bg-dvt" style={{flex: 1, paddingTop: BarHeight}}>
          <Animated.View
            {...starterAnimation('FadeInUp', 500, 200, 1)}
            className=" justify-between  items-center flex-row "
            style={{paddingTop: vs(20)}}>
            <TouchableOpacity
              className=" px-5 "
              onPress={() => {
                navigation.goBack();
              }}>
              <WhiteBackArrow />
            </TouchableOpacity>
            <TouchableOpacity className=" px-5 ">
              <Delete />
            </TouchableOpacity>
          </Animated.View>

          <Animated.View
            {...starterAnimation('FadeInUp', 500, 200, 1)}
            className=" items-center "
            style={{paddingBottom: vs(20)}}>
            <Text className="font-inbl text-w" style={{fontSize: ms(20)}}>
              Aromi Tray
            </Text>
          </Animated.View>
          <Animated.View
            {...starterAnimation('FadeInUp', 500, 200, 1)}
            style={{paddingTop: vs(10)}}
            className=" justify-end items-center">
            <Image
              source={Images.trayD}
              style={{height: vs(100), width: vs(100)}}
            />
          </Animated.View>
        </View>
        <View className="bg-dvt ">
          <Animated.View
            {...starterAnimation('SlideInDown', 500, 500, 1)}
            className="flex-1 bg-bggy rounded-tr-2xl rounded-tl-2xl">
            <Animated.View
              // {...starterAnimation('SlideInDown', 500, 200, 2)}
              className="mx-5 my-4">
              <Text className="text-blp font-inm" style={{fontSize: vs(14)}}>
                Name your tray
              </Text>
              <View className="my-3">
                <View className="rounded-2xl bg-w">
                  {trayMenus.map((item, index) => {
                    return <RenderSwitch item={item} index={index} />;
                  })}
                </View>
              </View>
            </Animated.View>

            <View className="mx-4">
              <View className="flex-row justify-between items-center">
                <View>
                  <Text
                    className="text-blp font-inm"
                    style={{fontSize: vs(14)}}>
                    Jar details
                  </Text>
                </View>
                {trayDetails?.jars?.length < 4 && (
                  <TouchableOpacity>
                    <Text
                      className="font-in_sbl text-nvt"
                      style={{fontSize: vs(12)}}>
                      Add new jar
                    </Text>
                  </TouchableOpacity>
                )}
              </View>

              <View>
                <View
                  style={{
                    paddingHorizontal: ms(10),
                    //   backgroundColor: '#EFF5FF',
                    paddingVertical: vs(10),
                    borderRadius: ms(10),
                    marginBottom: vs(10),
                  }}>
                  {trayDetails?.jars?.map((item, index) => {
                    return (
                      <TrayJar
                        trayDetails={trayDetails}
                        index={index}
                        item={item}
                      />
                    );
                  })}
                </View>
              </View>
            </View>
          </Animated.View>
        </View>
        {/* </View> */}
      </ScrollView>
      {sheetOpen && (
        <EditNameSheet
          {...{
            modalRef: bottomEditSheetRef,
            openSheet,
            closeSheet,
            snap: ['50%', '50%'],
            name,
            handleName,
          }}
        />
      )}
    </View>
  );
};

export default TrayDetails;
