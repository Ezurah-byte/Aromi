import {View, Image, Text, TouchableOpacity, ScrollView} from 'react-native';
import React, {useEffect} from 'react';
import {
  DashedView,
  GradientView,
  InfiniteRotatingImage,
  Modal,
} from '@atoms/index';
import {Images} from '@images/index';
import {sizeConfig, sliceString} from '@utils/sizeConfig';
import {BurnIcon, CloseIcon, StarIcon, TimeIcon} from '@vectors/vectorImages';
import {Colors} from '@theme/colors';
import Animated from 'react-native-reanimated';
import {starterAnimation} from '@animation/starterAnimation';
import {
  useGetPostsQuery,
  useGetRecipsMutation,
} from '@library/service/apiSlice';
import FastImage from 'react-native-fast-image';
const RecipeList = ({navigation, route: {params}}) => {
  const {recipeList} = params;
  console.log(recipeList, 'received recipeList');
  const [
    getRecipes,
    {
      data: allRecips,
      isSuccess: recipesIsSuccess,
      isLoading: recipeIsLoading,
      error: recipeError,
    },
  ] = useGetRecipsMutation();
  console.log(
    JSON.stringify(allRecips),
    recipeIsLoading,
    recipeError,
    recipesIsSuccess,
    'useREcipe Data',
  );

  useEffect(() => {
    getRecipes({recipeData: {input: recipeList}});
  }, []);

  const {vs, ms} = sizeConfig;
  const {r1, r2, r3, r4} = Images;
  const recipes = [
    {
      url: r1,
      name: 'Cinnamon Coffee Latte',
      content: 'Warm and comforting coffee drink with a hint of cinnamon',
      rating: 4,
      duration: '5',
      calories: '120',
    },
    {
      url: r2,
      name: 'Cinnamon Sugar Coffee ',
      content: 'Cinnamon Sugar Coffee Cake: Indulge in a slice (or two) ',
      rating: 2,
      duration: '3',
      calories: '90',
    },
    {
      url: r3,
      name: 'Frosty Delight',
      content: 'Cinnamon Coffee Frappé: Chill out with this  .',
      rating: 5,
      duration: '1',
      calories: '100',
    },
    {
      url: r4,
      name: 'Donut Love',
      content: 'Cinnamon Sugar Donuts with Coffee Glaze: Sweet ..',
      rating: 3,
      duration: '2',
      calories: '50',
    },
  ];

  const RenderRecipes = ({item, index}) => {
    console.log(item?.Nutrition_Per_Serving, 'Nutrition_Per_Serving');
    return (
      <TouchableOpacity
        onPress={() => {
          navigation.navigate('recipeDetails', {recipeData: item});
        }}
        className="my-2">
        <DashedView
          bg={'#EAECF0'}
          borderRadius={10}
          color={Colors.nvt}
          height={125}>
          <View style={{borderRadius: 10}} className="flex-row h-full">
            <View className="justify-center" style={{flex: 0.9}}>
              <FastImage
                source={{uri: item?.image_url}}
                style={{
                  borderTopLeftRadius: 10,
                  borderBottomLeftRadius: 10,
                  height: 122,
                  marginLeft: 2,
                }}
                className=" w-full"
                // resizeMode="contain"
              />
            </View>
            <View style={{flex: 1.9}} className="justify-evenly px-3">
              <View style={{rowGap: vs(10)}}>
                <Text
                  className="font-in_sbl  text-blp"
                  style={{fontSize: vs(13)}}>
                  {sliceString(item?.name, 20)}
                </Text>
                <Text className="font-inr  text-blp" style={{fontSize: vs(12)}}>
                  {sliceString(item?.Short_Description, 50)}
                </Text>
              </View>
              <View className="flex-row justify-center">
                <View className="flex-row " style={{}}>
                  <View className="px-1 border-r-[0px]  border-r-nvt justify-center flex-row  ">
                    <FastImage
                      source={Images.star}
                      style={{
                        height: vs(13),
                        width: vs(13),
                      }}
                      // className=" w-full"
                      resizeMode="contain"
                    />
                    <Text
                      className="font-inl text-mgy pl-1"
                      style={{fontSize: vs(10)}}>
                      {item?.Ratings}/5
                    </Text>
                  </View>
                  <View className="px-1 items-center  border-r-[0px] justify-center border-r-nvt  flex-row ">
                    <FastImage
                      source={Images.clock}
                      style={{
                        height: vs(13),
                        width: vs(13),
                      }}
                      // className=" w-full"
                      resizeMode="contain"
                    />
                    <Text
                      className="font-inl text-mgy pl-1"
                      style={{fontSize: vs(10)}}>
                      {/* {item?.Duration} */}
                      {sliceString(item?.Duration, 12)}
                    </Text>
                  </View>
                  <View className="px-1 flex-row  justify-center ">
                    <FastImage
                      source={Images.calories}
                      style={{
                        height: vs(13),
                        width: vs(13),
                      }}
                      // className=" w-full"
                      resizeMode="contain"
                    />
                    <Text
                      className="font-inl text-mgy"
                      style={{fontSize: vs(10)}}>
                      {item?.Nutrition_Per_Serving?.calories} calories
                    </Text>
                  </View>
                </View>
              </View>
            </View>
          </View>
        </DashedView>
      </TouchableOpacity>
    );
  };

  return (
    <GradientView colors={['#FFF4ED', '#FCE6FF', '#D4EBFF', '#D1FEFC']}>
      <View style={{marginTop: vs(16)}}>
        <Animated.View
          {...starterAnimation('FadeInUp', 500, 500, 1)}
          className="items-end">
          <TouchableOpacity
            onPress={() => {
              navigation.goBack();
            }}>
            <CloseIcon />
          </TouchableOpacity>
        </Animated.View>
        <ScrollView
          contentContainerStyle={{paddingBottom: vs(30)}}
          showsVerticalScrollIndicator={false}>
          <View className="items-center gap-y-2">
            <Animated.View {...starterAnimation('FadeInUp', 500, 700, 1)}>
              <InfiniteRotatingImage
                source={Images.nLogo}
                style={{height: vs(50), width: vs(50)}}
              />
            </Animated.View>
            <Animated.View
              {...starterAnimation('FadeInUp', 500, 500, 1)}
              className="flex-row items-center gap-x-2">
              <InfiniteRotatingImage
                source={Images.niLogo}
                style={{width: vs(15), height: vs(15)}}
              />

              <View>
                <Text className="font-inbl text-blp" style={{fontSize: vs(20)}}>
                  Welcome to Nuvolux
                </Text>
              </View>

              <InfiniteRotatingImage
                source={Images.niLogo}
                style={{width: vs(15), height: vs(15)}}
              />
            </Animated.View>
            <Animated.View {...starterAnimation('FadeInUp', 500, 500, 1)}>
              <Text
                className="font-inr text-mgy text-center"
                style={{fontSize: vs(12)}}>
                Your personalized cooking companion. Discover new recipes,
                explore flavors, and cook with confidence. I'm here to help you
                unleash your culinary creativity!
              </Text>
            </Animated.View>
          </View>

          <Animated.View
            {...starterAnimation('FadeInDown', 500, 700, 1)}
            className="bg-w mt-4 rounded-lg border-[1px] border-vlvtb"
            style={{paddingVertical: vs(10), paddingHorizontal: vs(10)}}>
            <Text className="text-vt font-inm">
              <Text className="font-inbl">Note:</Text>
              Your spice jars inspired us to suggest these delicious recipes!
            </Text>
          </Animated.View>

          {recipesIsSuccess && (
            <Animated.View
              {...starterAnimation('FadeInDown', 500, 700, 1)}
              className="my-4">
              <Text
                className="font-inbl mb-4 text-blp"
                style={{fontSize: vs(12)}}>
                Suggested Recipes
              </Text>
              <View>
                {Object.values(allRecips?.recipes).map((item, index) => {
                  return <RenderRecipes item={item} index={index} />;
                })}
              </View>
            </Animated.View>
          )}
        </ScrollView>
      </View>

      {recipeIsLoading && <Modal type={'loader'} content={'Loading...'} />}
    </GradientView>
  );
};

export default RecipeList;
