import {View, Text, Image} from 'react-native';
import React, {useState} from 'react';
import {styleConfig} from '@utils/commonStyles';
import {
  HeaderText,
  HeaderTwo,
  Button,
  RoundedImage,
  GrayText,
  ButtonEdit,
} from '@atoms/index';
import {sizeConfig} from '@utils/sizeConfig';
import {Images} from '@images/index';
import {Colors} from '@theme/colors';
import {PhoneNumber, TextField} from '@molecules/index';
import Animated from 'react-native-reanimated';
import {starterAnimation} from '@animation/starterAnimation';

const AboutScreen = ({navigation}) => {
  const {containerX} = styleConfig;
  const {ms, vs} = sizeConfig;
  const [number, setCurrentNumber] = useState(null);
  const [name, setName] = useState('');

  const points = [
    {
      content:
        'Innovation: We embrace creativity and innovation to simplify cooking and enhance your experience.',
    },
    {
      content:
        'Quality: We strive for excellence in everything we do, from our app to our customer support.',
    },
    {
      content:
        'Community: We believe in building a community that shares knowledge, inspiration, and passion for cooking',
    },
  ];
  return (
    <View style={containerX}>
      <View>
        <HeaderTwo
          navigation={() => {
            navigation.goBack();
          }}
          header={'About'}
          bottom={true}
        />
      </View>
      <View style={{flex: 1}}>
        <View
          style={{paddingHorizontal: ms(12), paddingVertical: vs(10)}}
          className="flex-1 bg-[#F5F7FA]">
          <Animated.View
            {...starterAnimation('FadeInUp', 500, 500, 1)}
            className="items-center">
            <Image
              source={Images.logo}
              resizeMode="contain"
              style={{width: '90%', height: vs(120)}}
            />
          </Animated.View>
          <Animated.View
            {...starterAnimation('FadeInDown', 500, 500, 1)}
            className="bg-w rounded-lg mt-6"
            style={{paddingHorizontal: vs(10), paddingVertical: vs(10)}}>
            <Animated.Text
              {...starterAnimation('FadeInDown', 500, 700, 1)}
              className="font-inr text-b"
              style={{fontSize: vs(11), lineHeight: vs(16)}}>
              At Ezurah, we're a team of innovators, foodies, and technologists
              united by a passion for cooking and innovation. Our journey began
              with a simple idea: to make cooking easier, more efficient, and
              more enjoyable.
            </Animated.Text>
            <Animated.Text
              {...starterAnimation('FadeInDown', 500, 700, 2)}
              className="font-in_sbl text-b my-1"
              style={{fontSize: vs(14)}}>
              Our Values
            </Animated.Text>
            <Animated.View
              {...starterAnimation('FadeInDown', 500, 700, 2)}
              className="mx-2">
              {points.map((items, index) => {
                return (
                  <Animated.View style={{paddingVertical: vs(5)}} key={index}>
                    <View className="flex-row items-center gap-x-2">
                      <View
                        className="rounded-full bg-bls"
                        style={{height: vs(4), width: vs(4)}}
                      />
                      <View className="flex-1">
                        <Text
                          className="font-inr text-b"
                          style={{fontSize: vs(11), lineHeight: vs(16)}}>
                          {items.content}
                        </Text>
                      </View>
                    </View>
                  </Animated.View>
                );
              })}
            </Animated.View>
            <Animated.Text
              {...starterAnimation('FadeInDown', 500, 1000, 2)}
              className="font-in_sbl text-b my-1"
              style={{fontSize: vs(14)}}>
              Our Team
            </Animated.Text>
            <Animated.Text
              {...starterAnimation('FadeInDown', 500, 1000, 2)}
              className="font-inr text-b"
              style={{fontSize: vs(11), lineHeight: vs(16)}}>
              Our team consists of dedicated individuals with diverse
              backgrounds and expertise, including software development,
              culinary arts, and design. We're committed to delivering the best
              possible experience for our users.
            </Animated.Text>
          </Animated.View>
        </View>
      </View>
    </View>
  );
};

export default AboutScreen;
