import {
  View,
  Text,
  Image,
  TouchableOpacity,
  ImageBackground,
} from 'react-native';
import React, {useState, useCallback, useRef} from 'react';
import {styleConfig} from '@utils/commonStyles';
import {
  HeaderText,
  HeaderTwo,
  Button,
  RoundedImage,
  GrayText,
  DatePicker,
  DropDown,
  ExpandableBox,
  ExpandableText,
  DraggableText,
  SpiceBottomSheet,
} from '@atoms/index';

import {sizeConfig} from '@utils/sizeConfig';
import {Colors} from '@theme/colors';
import {Images} from '@images/index';
import ToggleSwitch from 'toggle-switch-react-native';

import BottomSheet from '@gorhom/bottom-sheet';
import {SpiceSheet} from '@molecules/index';
import Slider from '@react-native-community/slider';
import {useSharedValue} from 'react-native-reanimated';

const CustomizeLayout = ({navigation, route: {params}}) => {
  const {
    handleSave,
    spiceName,
    handleLayout,
    spicePx,
    spicePy,
    spiceAlign,
    spiceFontsize,
    spiceStyle,
    spiceLayout,
  } = params;
  const {containerX} = styleConfig;
  const {ms, vs, wh} = sizeConfig;
  const [sheetOpen, setSheetOpen] = useState(false);
  const [name, setName] = useState(spiceName || '');
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isBold, setIsBold] = useState(spiceStyle?.bold);
  const [isItalic, setIsItalic] = useState(spiceStyle?.italic);
  const [isUnderline, setIsUnderline] = useState(spiceStyle?.underline);
  const [currentAlign, setCurrentAlign] = useState(spiceAlign);
  const [fontSize, setFontSize] = useState(spiceFontsize);
  const [type, setType] = useState('');
  const [currentLayout, setCurrentlayout] = useState(spiceLayout);
  const [initialTranslateX, setinitialTranslateX] = useState(spicePx);
  const [initialTranslateY, setinitialTranslateY] = useState(spicePy);
  const translateX = useSharedValue(0);
  const translateY = useSharedValue(0);

  // ref
  const bottomSheetRef = useRef<BottomSheet>(null);
  const openSheet = useCallback(type => {
    // bottomSheetModalRef.current?.present();
    setSheetOpen(true);
    setType(type);
  }, []);

  const closeSheet = () => {
    setSheetOpen(false);
    // bottomSheetModalRef.current?.dismiss();
  };
  const handleName = value => {
    console.log('handleName', value);
    setName(value);
  };

  const [textWidth, setTextWidth] = useState(0);
  const [textHeight, setTextHeight] = useState(0);
  const onLayout = useCallback(event => {
    const {width, height} = event.nativeEvent.layout;
    console.log(width, '9087657890-');
    setTextWidth(width + 10);
    setTextHeight(height);
  }, []);
  const text = 'hello i m akilan hello';

  const editMenus = [
    // {
    //   name: 'Templates',
    //   url: Images.template,
    //   disable: true,
    //   action: () => {
    //     openSheet('templates');
    //   },
    // },
    {
      name: 'Text',
      url: Images.text,
      disable: true,
      action: () => {
        openSheet('text');
      },
    },
    // {
    //   name: 'Icons',
    //   url: Images.emoji,
    //   disable: true,
    //   action: () => {
    //     openSheet('icons');
    //   },
    // },
    // {
    //   name: 'Line',
    //   url: Images.line,
    //   disable: true,
    //   action: () => {
    //     openSheet('line');
    //   },
    // },
    // {
    //   name: 'Photos',
    //   url: Images.photo,
    //   disable: true,
    //   action: () => {
    //     openSheet('photos');
    //   },
    // },
    {
      name: 'Layout',
      url: Images.layout,
      disable: true,
      action: () => {
        openSheet('layout');
      },
    },
  ];
  console.log(handleLayout, '*******************888');
  return (
    <View style={containerX}>
      <HeaderTwo
        navigation={() => {
          navigation.goBack();
        }}
        header={'Spice Name '}
        bottom={true}
      />
      <Text
        style={{
          position: 'absolute',
          opacity: 0, // Make /the text invisible
          fontWeight: isBold ? 'bold' : '300',
          textDecorationLine: isUnderline ? 'underline' : 'none',

          fontStyle: isItalic ? 'italic' : '',
          fontSize: fontSize,
        }}
        onLayout={onLayout}>
        {name}
      </Text>
      <View style={{}} className="flex-1  bg-bggy">
        <View className="mt-16 items-center">
          <View
            className="bg-white rounded-xl"
            style={{
              shadowColor: '#000',
              shadowOffset: {width: 0, height: 1},
              shadowOpacity: 0.8,
              shadowRadius: 2,
              elevation: 2,
              height: 200,
              width: 320,
              // marginHorizontal: vs(10),
            }}>
            <ImageBackground
              source={
                currentLayout == 0
                  ? null
                  : currentLayout == 1
                  ? Images.rightBoard
                  : currentLayout == 2
                  ? Images.equalBoard
                  : Images.verticalBoard
              }
              className="h-full w-full rounded-xl">
              <ExpandableBox
                isBold={isBold}
                isItalic={isItalic}
                isUnderline={isUnderline}
                align={
                  initialTranslateX == 0 && initialTranslateY == 0
                    ? currentAlign == 0
                      ? 'left'
                      : currentAlign == 1
                      ? 'center'
                      : 'right'
                    : 'none'
                }
                fontSize={fontSize}
                parentWidth={320} // Width of the parent view
                parentHeight={200} // Height of the parent view
                text={name}
                boxWidth={Math.round(textWidth?.toFixed(2))}
                boxHeight={Math.round(textHeight?.toFixed(2))}
                initialTranslateX={initialTranslateX}
                initialTranslateY={initialTranslateY}
                setinitialTranslateX={setinitialTranslateX}
                setinitialTranslateY={setinitialTranslateY}
                translateX={translateX}
                translateY={translateY}
              />
            </ImageBackground>
            {/* <DraggableText text="Drag me around!" /> */}
          </View>
        </View>
      </View>
      <View
        style={{
          flex: 0.3,
          // paddingHorizontal: ms(20),
        }}
        className="rounded-tl-lg  rounded-tr-lg pb-2 bg-red ">
        <View className="items-center  my-1">
          <Image
            source={Images.bar}
            resizeMode="contain"
            className="h-3 w-12"
          />
          <View className="flex-row px-5 mt-2 flex-wrap">
            {editMenus.map((item, index) => {
              return (
                <TouchableOpacity
                  onPress={() => item?.action()}
                  className="items-center  w-20 mx-1 my-1">
                  <Image
                    source={item?.url}
                    style={{height: vs(40), width: vs(40)}}
                    resizeMode="contain"
                  />
                  <Text
                    className="font-inr text-blp"
                    style={{fontSize: vs(11)}}>
                    {item?.name}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </View>
        </View>
        <View className="flex-1 justify-end px-6 ">
          <Button
            {...{
              onClick: () => {
                console.log('onClick', name);
                handleLayout(
                  name,
                  translateX.value,
                  translateY.value,
                  currentAlign,
                  {bold: isBold, italic: isItalic, underline: isUnderline},
                  fontSize,
                  currentLayout,
                );
                navigation.goBack();
              },
              label: 'Save',
              enable: name?.length > 3 && name != 'Tab-Text-Menu',
              // border: true,
              // bcl: 'bg-w',
              // bcc: 'border-fb',
              // c: 'text-vt',
            }}
          />
        </View>
      </View>
      {sheetOpen && (
        <SpiceBottomSheet
          {...{
            modalRef: bottomSheetRef,
            openSheet,
            closeSheet,
            type: type,
            snap: ['50%', '50%'],
            name,
            handleName,
            currentIndex,
            isBold,
            isItalic,
            isUnderline,
            currentAlign,
            fontSize,
            setCurrentIndex,
            setIsBold,
            setIsItalic,
            setIsUnderline,
            setCurrentAlign,
            setFontSize,
            currentLayout,
            setCurrentlayout,
            navigation,
            handleLayout,
            initialTranslateX,
            initialTranslateY,
            translateX,
            translateY,
          }}
        />
      )}
    </View>
  );
};

export default CustomizeLayout;
