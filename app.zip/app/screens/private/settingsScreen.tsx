import {Text, View, TouchableOpacity, ScrollView} from 'react-native';
import React, {memo, useCallback, useState} from 'react';
import {sizeConfig} from '@utils/sizeConfig';
import {styleConfig, storage} from '@utils/index';

import {
  DashBoardHeader,
  RoundedImage,
  HeaderText,
  GrayText,
  ButtonEdit,
  Modal,
} from '@atoms/index';
import {Images} from '@images/index';
import {Colors} from '@theme/colors';
import {
  SettingIcon,
  AboutIcon,
  RateIcon,
  InteliIcon,
  SupportIcon,
  DocumentIcon,
  DeleteIcon,
  LogoutIcon,
  RightArrow,
} from '@vectors/vectorImages';
import {navigate} from '@root/';
import Animated from 'react-native-reanimated';
import {starterAnimation} from '@animation/starterAnimation';
import {useAppSelector} from '@hooks/';
const SettingsScreen = () => {
  const user = useAppSelector(state => state?.user);
  console.log('user Settig Screen1', user);
  const {container} = styleConfig;
  const {vs, ms} = sizeConfig;
  const {mgy} = Colors;
  const [isLogout, setIsLogout] = useState(false);
  const [isDelete, setIsDelete] = useState(false);

  const settingMenu = [
    {
      name: 'Settings',
      Icon: SettingIcon,
      navigation: () => {
        navigate('appSettings', {});
      },
    },
    {
      name: 'About Us',
      Icon: AboutIcon,
      navigation: () => {
        navigate('about', {});
      },
    },
    {
      name: 'Rate this app',
      Icon: RateIcon,
      disable: true,

      navigation: () => {
        // navigate("about",{})
      },
    },
  ];

  const AIMenu = [
    {
      name: 'Automation',
      Icon: InteliIcon,
      disable: true,

      navigation: () => {
        // navigate("about",{})
      },
    },
  ];

  const privacyMenu = [
    {
      name: 'Help & Support',
      Icon: SupportIcon,
      disable: true,
      navigation: () => {
        // navigate("about",{})
      },
    },
    {
      name: 'Legal Document',
      Icon: DocumentIcon,

      navigation: () => {
        navigate('about', {});
      },
    },
    {
      name: 'Delete Account',
      Icon: DeleteIcon,
      color: 'text-r',

      navigation: () => {
        setIsDelete(true);
        storage.delete(user.number);
      },
    },
    {
      name: 'Log out',
      Icon: LogoutIcon,
      color: 'text-r',
      navigation: () => {
        storage.delete('lastLogin');
        setIsLogout(true);
      },
    },
  ];

  const RenderMenus = ({name, menus, index}) => {
    return (
      <Animated.View
        {...starterAnimation('FadeInDown', 500, 200, index + 1)}
        style={{paddingVertical: vs(10), rowGap: vs(10)}}>
        <Text className="text-blp font-inbl" style={{fontSize: vs(12)}}>
          {name}
        </Text>

        <View className="bg-w rounded-lg ">
          {menus.map((item, index) => {
            const {Icon, name, content} = item;
            return (
              <TouchableOpacity
                onPress={() => {
                  item.navigation();
                }}>
                <View
                  className="items-center flex-row  "
                  style={{
                    height: vs(52),
                    paddingHorizontal: vs(10),
                    marginVertical: 0,
                    opacity: item?.disable ? 0.3 : 1,
                  }}>
                  <View className=" " style={{flex: 0.2}}>
                    <Icon />
                  </View>

                  <View style={{flex: 1.5, rowGap: vs(0)}}>
                    <View>
                      <Text
                        className={`font-in_sbl ${item.color || 'text-blp'} `}
                        style={{fontSize: ms(14)}}>
                        {name}
                      </Text>
                    </View>
                    <View className="flex-row gap-x-2">
                      <View
                        className="flex-row items-center"
                        style={{columnGap: ms(3)}}>
                        {/* <GrayText content={content} color={mgy} size={12} /> */}
                      </View>
                    </View>
                  </View>

                  <View className="items-center" style={{flex: 0.2}}>
                    <TouchableOpacity onPress={() => {}}>
                      <RightArrow />
                    </TouchableOpacity>
                  </View>
                </View>
                {index != 2 && menus.length != 1 && (
                  <View
                    className="border-b-[1px] flex-1 border-[#EAECF0]"
                    style={{marginHorizontal: ms(10)}}
                  />
                )}
              </TouchableOpacity>
            );
          })}
        </View>
      </Animated.View>
    );
  };

  const RenderConatiner = useCallback(() => {
    return (
      <ScrollView showsVerticalScrollIndicator={false}>
        <View>
          <Animated.View
            {...starterAnimation('FadeInUp', 500, 400, 0)}
            className="bg-w rounded-lg items-center flex-row border-[#F7F7F7] border-[1px]"
            style={{
              height: vs(63),
              paddingHorizontal: vs(10),
              marginVertical: 0,
            }}>
            <View className=" " style={{flex: 0.3}}>
              <RoundedImage
                url={Images.profile}
                style={{
                  height: vs(40),
                  width: vs(40),
                  borderRadius: ms(100),
                  backgroundColor: Colors.w,
                }}
              />
            </View>

            <View style={{flex: 1, rowGap: vs(0)}}>
              <View>
                <HeaderText content={`${user.name || 'Profile'}`} size={14} />
              </View>
              <View className="flex-row gap-x-2">
                <View
                  className="flex-row items-center"
                  style={{columnGap: ms(3)}}>
                  <GrayText
                    content={user.number}
                    color={Colors.mgy}
                    size={12}
                  />
                </View>
              </View>
            </View>

            <View className="items-center" style={{flex: 0.2}}>
              <TouchableOpacity
                onPress={() => {
                  navigate('profile', {});
                }}>
                <ButtonEdit />
              </TouchableOpacity>
            </View>
          </Animated.View>
        </View>
        <RenderMenus index={1} name={'App Settings'} menus={settingMenu} />
        <RenderMenus
          index={1}
          name={'Ezurah Intelligence(EI)'}
          menus={AIMenu}
        />
        <RenderMenus index={1} name={'Privacy'} menus={privacyMenu} />
        <Text className="font-inr text-center my-2" style={{fontSize: vs(12)}}>
          Build Version 1.0.1
        </Text>
      </ScrollView>
    );
  }, [user.name]);

  return (
    <View
      className="bg-bggy"
      style={{...container, backgroundColor: '#F5F7FA'}}>
      <DashBoardHeader content="Settings" />

      <RenderConatiner />
      {isLogout && <Modal type={'logout'} close={setIsLogout} />}
      {isDelete && <Modal type={'delete'} close={setIsDelete} />}
    </View>
  );
};

export default SettingsScreen;
