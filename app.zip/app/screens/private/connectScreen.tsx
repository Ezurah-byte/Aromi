import {View, Text, Image, TouchableOpacity} from 'react-native';
import React, {useEffect, useState} from 'react';
import {styleConfig} from '@utils/commonStyles';
import {Images} from '@images/index';
import {sizeConfig} from '@utils/sizeConfig';
import {HeaderText, Button, Modal} from '@atoms/index';
import {BarHeight} from '@utils/barHeight';
import {GrayBack} from '@vectors/vectorImages';
import {navigate} from '@root/';
import Animated from 'react-native-reanimated';
import {starterAnimation} from '@animation/starterAnimation';
import {useToast} from 'react-native-toast-notifications';
import {
  ESPProvisionManager,
  ESPTransport,
  ESPSecurity,
  ESPDevice,
} from '@orbital-systems/react-native-esp-idf-provisioning';
const ConnectScreen = ({navigation, route: {params}}) => {
  const toast = useToast();

  const {connectableDevice} = params;
  const {container} = styleConfig;
  const {vs, ms} = sizeConfig;
  const [isconnected, setIsConnected] = useState(false);
  const points = [
    {
      content: 'Get Closer to your tray',
    },
    {
      content: 'Press the button quickly to activate paring',
    },
    {
      content: 'Blinking green light means the tray is ready to pair',
    },
  ];
  useEffect(() => {
    handleConnectAndWifi(connectableDevice);
  }, []);

  const handleConnectAndWifi = async item => {
    try {
      setIsConnected(false);
      console.log(
        'init  ',
        item.security,
        item.security == 0
          ? ESPSecurity.unsecure
          : item.security == 1
          ? ESPSecurity.secure
          : ESPSecurity.secure2,
      );

      const device = new ESPDevice({
        name: item.name,
        transport: ESPTransport.ble,
        security:
          item.security == 0
            ? ESPSecurity.unsecure
            : item.security == 1
            ? ESPSecurity.secure
            : ESPSecurity.secure2,
      });
      // Connect to device with proofOfPossession
      console.log('Connecting to device', device);
      const proofOfPossession = 'abcd1234';
      try {
        console.log('proofOfPossession init', device);

        await device.setProofOfPossession(proofOfPossession);
        console.log('proofOfPossession complete');
      } catch (error) {
        console.log('proofOfPossession error', error);
        setIsConnected(true);
        toast.show('Unable to Connect');
      }

      try {
        console.log('Connecting to device init', device);
        await device?.connect(proofOfPossession, null, 'wifiprov');
        console.log('Connecting to device CONENETCJKHBJHDJHB');
        setIsConnected(true);
        // toast.show('Device connected successfully!');
        navigate('searchWifi', {connectableDevice: item});
      } catch (err) {
        console.log('Connecting to erro ', err);
        setIsConnected(true);
        toast.show('Unable to connect');
      }
    } catch (err) {
      console.log('init err ', err);
      toast.show('Unable to connect');
      setIsConnected(true);
    }
  };

  return (
    <View className="bg-[#F5F7FA]" style={{flex: 1}}>
      <TouchableOpacity
        onPress={() => {
          navigation.goBack();
        }}
        className="absolute"
        style={{zIndex: 1, top: vs(BarHeight + 10), left: vs(15)}}>
        <Animated.View
          className={` bg-w justify-center items-center  rounded-full `}
          style={{
            width: vs(30),
            height: vs(30),
          }}
          {...starterAnimation('FadeInUp', 500, 200, 1)}>
          <GrayBack />
        </Animated.View>
      </TouchableOpacity>
      <View style={{flex: 1}}>
        <Animated.Image
          {...starterAnimation('FadeInUp', 500, 200, 1)}
          source={Images.connect}
          style={{width: '100%', height: '30%'}}
        />

        <Animated.View
          {...starterAnimation('FadeInDown', 500, 200, 1)}
          style={{paddingHorizontal: ms(10), paddingVertical: vs(10)}}>
          <HeaderText content={'Searching...'} size={vs(16)} />
          <View style={{paddingVertical: vs(5), paddingHorizontal: ms(10)}}>
            {points.map((items, index) => {
              return (
                <View style={{paddingVertical: vs(5)}} key={index}>
                  <View className="flex-row items-center gap-x-2">
                    <View
                      className="rounded-full bg-bls"
                      style={{height: vs(5), width: vs(5)}}
                    />
                    <View>
                      <Text
                        className="font-inr text-bls"
                        style={{fontSize: vs(12)}}>
                        {items.content}
                      </Text>
                    </View>
                  </View>
                </View>
              );
            })}
          </View>
        </Animated.View>
      </View>
      <View
        style={{flex: 0.1, paddingHorizontal: ms(20)}}
        className="justify-center bg-w  border-t-[1.5px] border-[#E3E5F0]">
        <Animated.View {...starterAnimation('FadeInDown', 500, 200, 1)}>
          <Button
            {...{
              enable: true,
              label: 'Search again',

              onClick: () => {
                navigate('trouble', {});
              },
            }}
          />
        </Animated.View>
      </View>
      {!isconnected && <Modal type={'loader'} content={'Connecting...'} />}
    </View>
  );
};

export default ConnectScreen;
