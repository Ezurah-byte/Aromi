import {View, Text, Image, StatusBar} from 'react-native';
import React, {useEffect, useState} from 'react';
import {GradientView, HeaderTwo, HeaderText, ZoomingImage} from '@atoms/index';
import {Images} from '@images/index';
import {sizeConfig, BarHeight, storage} from '@utils/index';
import {navigate} from '@root/';
import Animated from 'react-native-reanimated';
import {starterAnimation} from '@animation/starterAnimation';
import {useToast} from 'react-native-toast-notifications';
import {useAppDispatch, useAppSelector} from '@hooks/';
import {setUser} from '@library/features/auth/userSlice';

const WifiCommunication = ({navigation, route: {params}}) => {
  const toast = useToast();
  const dispatch = useAppDispatch();
  const mobileNumber = useAppSelector(state => state?.user?.number);

  const {connectableDevice, ssid, password} = params;
  const [isLoading, setIsLoading] = useState(false);

  const {tOverlay, bOverlay, cWifi, wDevice} = Images;
  const {wh, ms, vs} = sizeConfig;
  useEffect(() => {
    handleProvision(connectableDevice, ssid, password);
  }, []);

  const handleProvision = async (connectableDevice, ssid, password) => {
    try {
      setIsLoading(true);
      console.log('Wifi Connect', password);
      const feedback = await connectableDevice?.provision(ssid, password);
      console.log('Provision Done', feedback);

      connectableDevice?.disconnect();
      setIsLoading(false);

      dispatch(setUser({name: 'wifiCred', data: {ssid, password}}));

      const userDataStringfy = storage.getString(`${mobileNumber}`);
      let userData = JSON.parse(userDataStringfy);
      userData = {...userData, wiifiCred: {ssid, password}};
      storage.set(`${mobileNumber}`, JSON.stringify(userData));
      const userDataCheck = storage.getString(`${mobileNumber}`);
      console.log(userDataCheck, 'userDataCheck');

      navigate('wifiSuccess', {});
      console.log('Provision Disconnect', password);
    } catch (e) {
      setIsLoading(false);
      toast.show('Password Incorrect');
      console.log('Provision Error', e);
    }
  };

  return (
    <GradientView isfull={true} colors={['#1B1F24', '#102522']}>
      <StatusBar barStyle={'light-content'} />
      <Animated.View
        {...starterAnimation('FadeInUp', 500, 200, 1)}
        style={{position: 'absolute', top: 0, zIndex: 0, left: 0}}>
        <Image source={tOverlay} style={{width: wh, height: 200}} />
      </Animated.View>
      <Animated.View
        {...starterAnimation('FadeInDown', 500, 200, 1)}
        style={{position: 'absolute', bottom: 0, zIndex: 0, left: 0}}>
        <Image source={bOverlay} style={{width: wh, height: 200}} />
      </Animated.View>
      <View style={{marginTop: BarHeight, flex: 2}}>
        <HeaderTwo
          navigation={() => {
            navigation.goBack();
          }}
          bg="none"
          iconC="#FFFFFF"
          single={true}
        />
        <View style={{rowGap: vs(140)}}>
          <Animated.Text
            {...starterAnimation('FadeInUp', 500, 200, 1)}
            className="font-inm text-center text-lgr"
            style={{fontSize: ms(14)}}>
            Exurah is looking for your Aromi device..
          </Animated.Text>

          <Animated.View
            {...starterAnimation('FadeInDown', 500, 200, 1)}
            style={{}}
            className="flex-row  justify-center">
            <View
              className="bg-vlgr rounded-full justify-center items-center"
              style={{height: vs(80), width: vs(80)}}>
              <ZoomingImage
                source={cWifi}
                className="rounded-full"
                // delay={1000}
                direction="clock"
                style={{width: vs(65), height: vs(65)}}
              />
            </View>
            <View className="flex-row  items-center gap-x-3">
              <Text className="text-center text-w">-</Text>
              <View>
                <View
                  className="items-center rounded-lg border-[2px] border-vlgr mt-3 bg-w"
                  style={{
                    paddingHorizontal: ms(5),
                    paddingVertical: ms(5),
                  }}>
                  <HeaderText content={'Establishing connection'} size={8} />
                </View>
              </View>
              <Text className="text-center text-w">-</Text>
            </View>
            <View
              className="bg-vlgr rounded-full justify-center items-center"
              style={{height: vs(80), width: vs(80)}}>
              <ZoomingImage
                source={wDevice}
                // direction="anti-clock"
                className="rounded-full"
                // delay={1000}
                style={{width: vs(65), height: vs(65)}}
              />
            </View>
          </Animated.View>
        </View>
      </View>
      <View style={{flex: 0.2}}>
        <Animated.Text
          {...starterAnimation('FadeInDown', 500, 200, 1)}
          className="font-inm text-center text-lgr"
          style={{fontSize: ms(13)}}>
          Make sure you have connect to your Aromi device’s Wi-Fi:
          Exurah_Device_XXX
        </Animated.Text>
      </View>
    </GradientView>
  );
};

export default WifiCommunication;
