import {View, Text, Image, TouchableOpacity} from 'react-native';
import React, {useRef, useState, useCallback, useEffect} from 'react';
import {sizeConfig} from '@utils/sizeConfig';
import {styleConfig} from '@utils/commonStyles';
import {HeaderText, HeaderTwo, Button, WifiSheet, Modal} from '@atoms/index';
import {Images} from '@images/index';
import BottomSheet from '@gorhom/bottom-sheet';
import {WifiMenu} from '@molecules/index';
import {navigate} from '@root/';
import Animated from 'react-native-reanimated';
import {starterAnimation} from '@animation/starterAnimation';
import {
  ESPProvisionManager,
  ESPTransport,
  ESPSecurity,
  ESPDevice,
} from '@orbital-systems/react-native-esp-idf-provisioning';
import {useToast} from 'react-native-toast-notifications';

const SearchWifi = ({navigation, route: {params}}) => {
  const {connectableDevice} = params;
  const toast = useToast();

  const {container} = styleConfig;
  const {vs, ms} = sizeConfig;
  const [sheetOpen, setSheetOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [wifiDevices, setWifiDevices] = useState(null);

  const bottomWifiSheet = useRef<BottomSheet>(null);
  console.log(wifiDevices, 'wifiDevices screen');
  useEffect(() => {
    handleConnectAndWifi(connectableDevice);
  }, []);

  const openSheet = () => {
    console.log(sheetOpen, 'Sheet open');
    setSheetOpen(true);
  };

  const closeSheet = () => {
    setSheetOpen(false);
  };

  const handleConnectAndWifi = async item => {
    try {
      setIsLoading(true);

      try {
        const wifiList = await item?.scanWifiList();
        console.log('Connecting to wifis', wifiList);
        setWifiDevices(wifiList);
        setIsLoading(false);
        setSheetOpen(true);
      } catch (err) {
        setIsLoading(false);
        toast.show('Unable to scan');
        console.log('Connecting to wifis eror', err);
      }
    } catch (err) {
      toast.show('Unable to scan');
      console.log('init err ', err);
    }
  };

  return (
    <View style={{...container, backgroundColor: '#F5F7FA'}}>
      <HeaderTwo
        navigation={() => {
          navigation.goBack();
        }}
        bg={'#F5F7FA'}
        single={true}
      />
      <Animated.View
        {...starterAnimation('FadeInUp', 500, 200, 1)}
        className="items-center "
        style={{rowGap: vs(10), flex: 1}}>
        <HeaderText content={'Connect to Your  WiFi'} size={vs(14)} />
        <Text
          className="font-inr text-bls text-center"
          style={{fontSize: vs(12)}}>
          Take your Aromi Tray to the next level! Connect to WiFi for seamless
          updates, remote access, and more.
        </Text>
      </Animated.View>
      <Animated.View
        {...starterAnimation('FadeInDown', 500, 200, 1)}
        style={{flex: 3}}
        className="">
        <Image
          resizeMode="contain"
          source={Images.wifi}
          style={{width: '100%', height: '55%'}}
        />
      </Animated.View>
      <Animated.View
        {...starterAnimation('FadeInDown', 500, 200, 1)}
        style={{rowGap: vs(20), flex: 0.8}}>
        <Button
          {...{
            onClick: () => {
              setSheetOpen(true);
            },
            label: 'Connect now',
            // border: true,
            // bcl: 'bg-vt',
            // bcc: 'border-vt',
            // c: 'text-w',
            enable: true,
          }}
        />
        <TouchableOpacity
          className=""
          onPress={() => {
            navigate('communication', {});
          }}>
          <Text className="text-center font-inbl text-vt">
            I'm Already Connected
          </Text>
        </TouchableOpacity>
      </Animated.View>
      {sheetOpen && (
        <WifiSheet
          {...{
            modalRef: bottomWifiSheet,
            openSheet,
            closeSheet,
            snap: ['50%', '50%'],
            wifiList: wifiDevices,
            connectableDevice: connectableDevice,
          }}
        />
      )}
      {/* <WifiMenu {...{modalRef: bottomSheetModalRef, openSheet, closeSheet}} /> */}
      {isLoading && <Modal type={'loader'} content={'Scaning WiFi...'} />}
    </View>
  );
};

export default SearchWifi;
