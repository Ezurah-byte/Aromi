import {View, Text, TouchableOpacity} from 'react-native';
import React, {useCallback, useMemo, useState} from 'react';
import {styleConfig} from '@utils/commonStyles';
import {Images} from '@images/index';
import {sizeConfig} from '@utils/sizeConfig';
import {HeaderText, Button, GrayText} from '@atoms/index';
import {BarHeight, storage} from '@utils/index';
import {GrayBack} from '@vectors/vectorImages';
import {TextField} from '@molecules/index';
import {Colors} from '@theme/colors';
import ToggleSwitch from 'toggle-switch-react-native';
import {navigate} from '@root/';
import Animated from 'react-native-reanimated';
import {starterAnimation} from '@animation/starterAnimation';
import {KeyboardAvoidingView} from 'react-native';
import {useAppDispatch, useAppSelector} from '@hooks/';
import {setUser} from '@library/features/auth/userSlice';
import uuid from 'react-native-uuid';
const TrayName = ({navigation}) => {
  const dispatch = useAppDispatch();
  const user = useAppSelector(state => state?.user);
  const {container} = styleConfig;
  const {vs, ms} = sizeConfig;
  const [name, setName] = useState('');
  const [isBattery, setIsBattery] = useState(true);
  const [isJarCount, setIsJarCount] = useState(true);

  const handleFinish = () => {
    console.log('user handle finish', user);
    let tempTray = user.trays ? [...user.trays] : [];
    let trayData = {
      name,
      showBattery: isBattery,
      showJarCount: isJarCount,
      noOfJar: 0,
      battery: 62,
      jars: [],
      id: uuid.v4(),
    };
    tempTray.push(trayData);
    dispatch(setUser({name: 'trays', data: tempTray}));

    const userDataStringfy = storage.getString(`${user.number}`);
    let userData = JSON.parse(userDataStringfy);
    let trays = userData.trays || [];
    trays?.push(trayData);
    console.log(trays, 'updated trays');
    userData = {...userData, trays: trays};
    storage.set(`${user.number}`, JSON.stringify(userData));
    const userDataCheck = storage.getString(`${user.number}`);
    console.log(userDataCheck, 'userDataCheck');

    navigate('homeScreen', {isTrayAdded: true});
  };
  const swicthMenu = [
    {
      name: 'Show Battery %',
      content: 'Aromi Tray battery will be shown in %',
      action: () => {
        setIsBattery(!isBattery);
      },
      value: isBattery,
    },
    {
      name: 'Show Jar Counts',
      content: 'Aromi Tray will display Jar counts',
      action: () => {
        setIsJarCount(!isJarCount);
      },
      value: isJarCount,
    },
  ];
  const RenderSwitch = useCallback(({item, index}) => {
    const {name, content, value, action} = item;
    return (
      <View
        key={index}
        className=" rounded-lg items-center flex-row border-[#F7F7F7] border-[1px]"
        style={{
          height: vs(53),
          paddingHorizontal: vs(10),
          marginVertical: 0,
        }}>
        <View className=" " style={{flex: 0.2}}>
          <ToggleSwitch
            isOn={value}
            onColor="#7F56D9"
            offColor="#F2F4F7"
            onToggle={isOn => {
              action();
              console.log('changed to : ', isOn);
            }}
          />
        </View>

        <View style={{flex: 1, rowGap: vs(0)}}>
          <View>
            <Text className="font-in_sbl text-blp" style={{fontSize: ms(14)}}>
              {name}
            </Text>
          </View>
          <View className="flex-row gap-x-2">
            <View className="flex-row items-center" style={{columnGap: ms(3)}}>
              <GrayText content={content} color={Colors.mgy} size={12} />
            </View>
          </View>
        </View>
      </View>
    );
  }, []);

  return (
    <View className="bg-[#F5F7FA]" style={{flex: 1}}>
      <TouchableOpacity
        onPress={() => {
          navigation.goBack();
        }}
        className="absolute"
        style={{zIndex: 1, top: vs(BarHeight + 10), left: vs(15)}}>
        <Animated.View
          className={` bg-w justify-center items-center  rounded-full `}
          style={{
            width: vs(30),
            height: vs(30),
          }}
          {...starterAnimation('FadeInUp', 500, 200, 1)}>
          <GrayBack />
        </Animated.View>
      </TouchableOpacity>
      <View style={{flex: 1}}>
        <Animated.Image
          {...starterAnimation('FadeInUp', 500, 200, 1)}
          source={Images.connect}
          style={{width: '100%', height: '30%'}}
        />
        <Animated.View
          {...starterAnimation('FadeInDown', 500, 200, 1)}
          style={{paddingHorizontal: ms(10), paddingVertical: vs(10)}}>
          <HeaderText
            navigation={() => {
              navigation.goBack();
            }}
            content={'Customise your tray'}
            size={vs(15)}
          />
          <View style={{paddingVertical: vs(10), paddingHorizontal: ms(0)}}>
            <TextField
              {...{
                label: 'Name your tray',
                currentValue: name,
                handleChange: setName,
                placeholder: 'Enter your tray name',
                holderColor: Colors.gy,
                inputStyle: {
                  marginLeft: sizeConfig.ms(7),
                },
              }}
            />
            <View style={{paddingVertical: vs(10)}}>
              {swicthMenu.map((item, index) => {
                return <RenderSwitch item={item} index={index} />;
              })}
            </View>
          </View>
        </Animated.View>
      </View>
      <KeyboardAvoidingView
        style={{paddingHorizontal: ms(20), paddingVertical: vs(10)}}
        className="justify-center bg-w  border-t-[1.5px] border-[#E3E5F0]">
        <Animated.View {...starterAnimation('FadeInDown', 500, 200, 1)}>
          <Button
            {...{
              onClick: handleFinish,
              label: 'Finish',
              // border: true,
              // bcl: 'bg-w',
              // bcc: 'border-fb',
              // c: 'text-vt',
              enable: name.length > 3 && true,
            }}
          />
        </Animated.View>
      </KeyboardAvoidingView>
    </View>
  );
};

export default TrayName;
