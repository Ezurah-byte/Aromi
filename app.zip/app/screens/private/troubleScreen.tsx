import {View, Text, TouchableOpacity} from 'react-native';
import React from 'react';
import {styleConfig} from '@utils/commonStyles';
import {
  HeaderText,
  HeaderTwo,
  Button,
  RoundedImage,
  GrayText,
} from '@atoms/index';
import {sizeConfig} from '@utils/sizeConfig';
import {navigate} from '@root/';
const TroubleScreen = ({navigation}) => {
  const {containerX} = styleConfig;
  const {ms, vs} = sizeConfig;
  const points = [
    {
      content: 'tap Bluetooth',
    },
    {
      content: 'find and tap info-circle next to Aromoi_Tray_xyz...',
    },
    {
      content: 'tap ‘Forget this device’',
    },
    {
      content: 'then tap retry',
    },
  ];
  return (
    <View style={containerX}>
      <View style={{flex: 0.1}}>
        <HeaderTwo
          header={'Trouble pairing?'}
          navigation={() => {
            navigation.goBack();
          }}
          bottom={true}
        />
      </View>
      <View style={{paddingHorizontal: ms(16)}} className="flex-1 bg-[#F5F7FA]">
        <View style={{paddingVertical: vs(10)}}>
          <View className="mb-2">
            <HeaderText content={'Light is blinking?'} size={18} />
          </View>
          <View className="">
            <Text className="font-inr text-bls " style={{fontSize: vs(12)}}>
              If you see a blinking light but nothing happens, open up iOS
              settings
            </Text>
            <View style={{paddingVertical: vs(10)}}>
              {points.map((items, index) => {
                return (
                  <View style={{paddingVertical: vs(5)}} key={index}>
                    <View className="flex-row items-center gap-x-2">
                      <View
                        className="rounded-full bg-bls"
                        style={{height: vs(5), width: vs(5)}}
                      />
                      <View>
                        <Text
                          className="font-inr text-bls"
                          style={{fontSize: vs(12)}}>
                          {items.content}
                        </Text>
                      </View>
                    </View>
                  </View>
                );
              })}
            </View>
          </View>
        </View>
      </View>
      <View
        style={{flex: 0.11, paddingHorizontal: ms(20)}}
        className="justify-center bg-red border-t-[1.5px] border-[#E3E5F0]">
        <Button
          {...{
            onClick: () => {
              navigate('connect', {});
            },
            label: 'Retry Pairing',
            border: true,
            bcl: 'bg-w',
            bcc: 'border-fb',
            c: 'text-vt',
          }}
        />
      </View>
    </View>
  );
};

export default TroubleScreen;
