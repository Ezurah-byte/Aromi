import {View, Text, TouchableOpacity} from 'react-native';
import React, {useState} from 'react';
import {styleConfig, storage} from '@utils/index';
import {
  HeaderText,
  HeaderTwo,
  Button,
  RoundedImage,
  GrayText,
  ButtonEdit,
} from '@atoms/index';
import {sizeConfig} from '@utils/sizeConfig';
import {Images} from '@images/index';
import {Colors} from '@theme/colors';
import {PhoneNumber, TextField} from '@molecules/index';
import NumberValidate from 'libphonenumber-js';
import {navigate} from '@root/';
import Animated from 'react-native-reanimated';
import {starterAnimation} from '@animation/starterAnimation';
import {useAppDispatch, useAppSelector} from '@hooks/index';
import {setUser} from '@library/features/auth/userSlice';

const ProfileScreen = ({navigation}) => {
  const user = useAppSelector(state => state?.user);
  const dispatch = useAppDispatch();

  const {containerX} = styleConfig;
  const {ms, vs} = sizeConfig;
  const [number, setCurrentNumber] = useState(user.number);
  const [name, setName] = useState(user?.name || '');
  const [errorNumber, setErrorNumber] = useState(false);
  const [errorName, setErrorName] = useState({isError: false, message: ''});
  const [countryCode, setCountryCode] = useState({
    dial_code: '+91',
    code: 'IN',
  });

  const profileSubmit = () => {
    const data = countryCode.dial_code + number;
    console.log(data, 'data');
    const isValidPhoneNumber = NumberValidate(data, countryCode?.code);
    console.log('isValidPhoneNumber');

    if (isValidPhoneNumber?.isValid()) {
      console.log('success');
      setErrorNumber(false);
      dispatch(
        setUser({
          name: 'name',
          data: name,
        }),
      );
      dispatch(
        setUser({
          name: 'number',
          data: number,
        }),
      );
      navigate('settingsScreen', {});
    } else {
      console.log('invalide number');
      setErrorNumber(true);
    }
  };

  return (
    <View style={{...containerX}}>
      <View style={{flex: 0.1}}>
        <HeaderTwo
          navigation={() => {
            navigation.goBack();
          }}
          header={'Profile'}
          bottom={true}
        />
      </View>
      <View
        style={{paddingHorizontal: ms(12), paddingVertical: vs(10)}}
        className="flex-1 bg-[#F5F7FA]">
        <View>
          <Animated.View
            {...starterAnimation('FadeInDown', 500, 200, 1)}
            className="bg-w rounded-lg items-center flex-row border-[#F7F7F7] border-[1px]"
            style={{
              height: vs(63),
              paddingHorizontal: vs(10),
              marginVertical: 0,
            }}>
            <View className=" " style={{flex: 0.22}}>
              <RoundedImage
                url={Images.profile}
                style={{
                  height: vs(40),
                  width: vs(40),
                  borderRadius: ms(100),
                  backgroundColor: Colors.w,
                }}
              />
            </View>

            <View style={{flex: 1, rowGap: vs(0)}}>
              {/* <View>
                <HeaderText content={'Profile'} size={14} />
              </View> */}
              <View className="flex-row gap-x-2">
                <View
                  className="flex-row items-center"
                  style={{columnGap: ms(3)}}>
                  <GrayText
                    content={'Enter your name and add an optional Profile name'}
                    color={Colors.mgy}
                    size={13}
                  />
                </View>
              </View>
            </View>
          </Animated.View>
          <Animated.View
            {...starterAnimation('FadeInDown', 500, 400, 1)}
            style={{rowGap: vs(10), marginVertical: vs(20)}}>
            <PhoneNumber
              {...{
                countryCode,
                setCountryCode,
                currentValue: number,
                handleChange: setCurrentNumber,
                placeholder: 'EX:9834575932',
                holderColor: Colors.gy,
                error: errorNumber,
              }}
            />
            <TextField
              {...{
                error: errorName,
                label: 'Profile name',
                currentValue: name,
                handleChange: setName,
                placeholder: 'Enter your name',
                holderColor: Colors.gy,
                inputStyle: {
                  marginLeft: sizeConfig.ms(7),
                },
              }}
            />
          </Animated.View>
        </View>
      </View>
      <View
        style={{flex: 0.11, paddingHorizontal: ms(20)}}
        className="justify-center bg-red border-t-[1.5px] border-[#E3E5F0]">
        <Animated.View {...starterAnimation('FadeInDown', 500, 200, 1)}>
          <Button
            {...{
              onClick: profileSubmit,
              enable:
                name.length > 0 && number?.length > 8 && number?.length < 13,
              label: 'Save',
              // border: true,
              // bcl: 'bg-vt',
              // bcc: 'border-vt',
              // c: 'text-w',
            }}
          />
        </Animated.View>
      </View>
    </View>
  );
};

export default ProfileScreen;
