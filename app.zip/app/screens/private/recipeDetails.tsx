import {
  View,
  Image,
  Text,
  TouchableOpacity,
  ScrollView,
  StatusBar,
} from 'react-native';
import React from 'react';
import {GradientView, HeaderText} from '@atoms/index';
import {Images} from '@images/index';
import {sizeConfig} from '@utils/sizeConfig';
import {BurnIcon, CloseIcon, StarIcon, TimeIcon} from '@vectors/vectorImages';
import {Colors} from '@theme/colors';
import {BarHeight} from '@utils/barHeight';
import FastImage from 'react-native-fast-image';
import {FlatList} from 'react-native-gesture-handler';
const RecipeDetails = ({navigation, route: {params}}) => {
  const {recipeData} = params;
  const {vs, ms} = sizeConfig;
  const {} = Images;

  return (
    <ScrollView
      contentContainerStyle={{paddingBottom: vs(20)}}
      showsVerticalScrollIndicator={false}>
      <View>
        <StatusBar barStyle={'light-content'} />

        <View>
          <Image
            source={{uri: recipeData.image_url}}
            style={{height: vs(200), width: '100%'}}
          />
        </View>

        <View
          style={{marginTop: BarHeight}}
          className="absolute right-7 items-end">
          <TouchableOpacity
            onPress={() => {
              navigation.goBack();
            }}>
            <CloseIcon />
          </TouchableOpacity>
        </View>

        <View>
          <View className="px-3 my-1">
            <HeaderText content={recipeData?.name} size={vs(15)} />
          </View>
          <View className="flex-row" style={{width: ms(250)}}>
            <View className=" border-r-[1px] px-4 border-r-nvt justify-center flex-row gap-x-1 ">
              <FastImage
                source={Images.star}
                style={{
                  height: vs(13),
                  width: vs(13),
                }}
                // className=" w-full"
                resizeMode="contain"
              />
              <Text className="font-inl text-mgy" style={{fontSize: vs(10)}}>
                {recipeData?.Ratings}/5
              </Text>
            </View>
            <View className=" items-center px-4 border-r-[1px] justify-center border-r-nvt  flex-row gap-x-2">
              <FastImage
                source={Images.clock}
                style={{
                  height: vs(13),
                  width: vs(13),
                }}
                // className=" w-full"
                resizeMode="contain"
              />
              <Text className="font-inl text-mgy" style={{fontSize: vs(10)}}>
                {recipeData?.Duration}
              </Text>
            </View>
            <View className=" flex-row gap-x-1 px-4 justify-center ">
              <FastImage
                source={Images.calories}
                style={{
                  height: vs(13),
                  width: vs(13),
                }}
                // className=" w-full"
                resizeMode="contain"
              />
              <Text className="font-inl text-mgy" style={{fontSize: vs(10)}}>
                {recipeData?.Nutrition_Per_Serving?.calories} calories
              </Text>
            </View>
          </View>
        </View>

        <View className="flex-row mt-4 border-t-[1px] border-t-ph py-4">
          {/* {recipeData?.category.map((item, index) => {
            return (
              <View
                className="py-1 px-2 border-[1px] border-ph rounded-lg mx-2 justify-center"
                key={index}>
                <Text
                  className="font-inm text-bls text-center"
                  style={{fontSize: vs(10)}}>
                  {item}
                </Text>
              </View>
            );
          })} */}

          <FlatList
            horizontal
            showsHorizontalScrollIndicator={false}
            data={recipeData?.category}
            renderItem={({item, index}) => (
              <View
                className="py-1 px-2 border-[1px] border-ph rounded-lg mx-2 justify-center"
                key={index}>
                <Text
                  className="font-inm text-bls text-center"
                  style={{fontSize: vs(10)}}>
                  {item}
                </Text>
              </View>
            )}
            keyExtractor={item => item.name}
          />
        </View>

        <View className="mx-4">
          <View>
            <HeaderText content={'Nutrition Per Serving'} size={vs(12)} />

            <View className="flex-row mt-1">
              {Object.entries(recipeData?.Nutrition_Per_Serving).map(
                ([key, value]) => {
                  return (
                    <View className="py-1 px-2 gap-y-1 mx-1 justify-center">
                      <Text
                        className="font-inbl text-bls text-center"
                        style={{fontSize: vs(12)}}>
                        {value}
                      </Text>
                      <Text
                        className="font-inl text-bls text-center"
                        style={{fontSize: vs(10)}}>
                        {key}
                      </Text>
                    </View>
                  );
                },
              )}
            </View>
          </View>
        </View>

        <View className="mx-4">
          <View className="mt-3">
            <HeaderText content={'Health Benefits'} size={vs(12)} />

            <View className=" mt-5  bg-[#F5F7FA] rounded-lg">
              {recipeData?.health_benefits.map((item, index) => {
                return (
                  <View
                    className={`py-3 ${
                      recipeData?.health_benefits?.length - 1 != index
                        ? 'border-b-[#EAECF0] border-b-[1px]'
                        : ''
                    }  px-2 gap-y-1 items-center gap-x-2  px-5  flex-row`}
                    key={index}>
                    <View className="h-[7px] w-[7px] rounded-full bg-bls" />
                    <Text
                      className="font-in_sbl text-bls text-start"
                      style={{fontSize: vs(12)}}>
                      {item}
                    </Text>
                  </View>
                );
              })}
            </View>
          </View>
        </View>

        <View className="mx-4">
          <View className="mt-3">
            <HeaderText content={'Instructions'} size={vs(12)} />

            <View className=" mt-5  bg-[#F5F7FA] rounded-lg">
              {recipeData?.instructions.map((item, index) => {
                return (
                  <View
                    className={`py-3 ${
                      recipeData?.instructions.length - 1 != index
                        ? 'border-b-[#EAECF0] border-b-[1px]'
                        : ''
                    }  px-2 gap-y-1  px-5 justify-center`}
                    key={index}>
                    <Text
                      className="font-in_sbl text-bls text-start"
                      style={{fontSize: vs(12)}}>
                      Step {index + 1}: {item}
                    </Text>
                    {/* <Text
                      className="font-inl text-bls text-center"
                      style={{fontSize: vs(10)}}>
                      {item?.name}
                    </Text> */}
                  </View>
                );
              })}
            </View>
          </View>
        </View>

        {/* <View className="mx-4">
          <View className="mt-3">
            <HeaderText content={'Health Benefits'} size={vs(12)} />

            <View className=" mt-5  bg-[#F5F7FA] rounded-lg">
              {recipeData?.health_benefits.map((item, index) => {
                return (
                  <View
                    className={`py-3 ${
                      recipeData?.health_benefits?.length - 1 != index
                        ? 'border-b-[#EAECF0] border-b-[1px]'
                        : ''
                    }  px-2 gap-y-1  px-5 justify-center`}
                    key={index}>
                    <Text
                      className="font-in_sbl text-bls text-start"
                      style={{fontSize: vs(12)}}>
                      {item}
                    </Text>
                  </View>
                );
              })}
            </View>
          </View>
        </View> */}
      </View>
    </ScrollView>
  );
};

export default RecipeDetails;
