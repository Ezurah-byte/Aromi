import {View, Text, TouchableOpacity} from 'react-native';
import React, {useEffect, useState} from 'react';
import {styleConfig} from '@utils/commonStyles';
import {
  HeaderText,
  HeaderTwo,
  Button,
  RoundedImage,
  GrayText,
  Modal,
} from '@atoms/index';
import {sizeConfig} from '@utils/sizeConfig';
import {Colors} from '@theme/colors';
import {Images} from '@images/index';
import {navigate} from '@root/';
import Animated from 'react-native-reanimated';
import {starterAnimation} from '@animation/starterAnimation';
import {
  ESPProvisionManager,
  ESPTransport,
  ESPSecurity,
  ESPDevice,
} from '@orbital-systems/react-native-esp-idf-provisioning';
import {useToast} from 'react-native-toast-notifications';
const DeviceList = ({navigation}) => {
  const toast = useToast();

  const {containerX} = styleConfig;
  const {ms, vs} = sizeConfig;
  const [loading, setLoading] = useState(true);
  const [bleDevices, setBleDevices] = useState([]);
  useEffect(() => {
    orgesp();
  }, []);

  const orgesp = async () => {
    console.log('Devices ESP INIT', JSON.stringify(ESPProvisionManager));

    setLoading(true);
    try {
      let prefix = 'AR';
      let transport = ESPTransport.ble;
      let security = ESPSecurity.secure2;
      const devices = await ESPProvisionManager.searchESPDevices(
        prefix,
        transport,
        security,
      );
      console.log(devices, 'Devices ESP');
      setBleDevices(devices);
      setLoading(false);
    } catch (e) {
      console.log(e, 'Error Esp Scan');
      setLoading(false);
      toast.show('Search Again...');
    }
  };

  return (
    <View style={containerX}>
      <View style={{flex: 0.1}}>
        <HeaderTwo
          navigation={() => {
            navigation.goBack();
          }}
          header={'Device Found'}
          bottom={true}
        />
      </View>
      <View style={{}} className="flex-1 bg-bggy">
        {loading && (
          <Animated.View
            {...starterAnimation('FadeInUp', 500, 200, 1)}
            className="items-center rounded-lg mt-3 bg-[#C5D5DC]"
            style={{
              paddingHorizontal: ms(20),
              paddingVertical: ms(5),
              marginHorizontal: ms(70),
            }}>
            <HeaderText content={'Searching for device...'} size={12} />
          </Animated.View>
        )}

        {(!loading || bleDevices.length > 0) && (
          <Animated.View
            {...starterAnimation('FadeInDown', 500, 200, 1)}
            style={{paddingVertical: vs(10)}}>
            <View className="mb-2" style={{paddingHorizontal: ms(10)}}>
              <HeaderText content={'Device found'} size={16} />
            </View>
            <View className="bg-w" style={{flex: 1}}>
              {bleDevices.map((item, index) => {
                return (
                  <View
                    className="bg-w rounded-lg items-center flex-row border-[#F7F7F7] border-[1px]"
                    style={{
                      height: vs(63),
                      paddingHorizontal: vs(10),
                      marginVertical: 0,
                    }}>
                    <View className=" " style={{flex: 0.3}}>
                      <RoundedImage
                        url={Images.device}
                        style={{
                          height: vs(40),
                          width: vs(40),
                          borderRadius: ms(100),
                          backgroundColor: Colors.w,
                        }}
                      />
                    </View>

                    <View style={{flex: 1, rowGap: vs(0)}}>
                      <View>
                        <HeaderText
                          content={item?.name || 'Aromi Tray'}
                          size={14}
                        />
                      </View>
                      <View className="flex-row gap-x-2">
                        <View
                          className="flex-row items-center"
                          style={{columnGap: ms(3)}}>
                          <GrayText
                            content={`Modal: HGD4567${index + 1}`}
                            color={Colors.mgy}
                            size={12}
                          />
                        </View>
                      </View>
                    </View>

                    <TouchableOpacity
                      onPress={() => {
                        navigate('connect', {connectableDevice: item});
                      }}
                      className="items-center  py-3"
                      style={{flex: 0.5}}>
                      <View>
                        <Text className="font-in_sbl text-vt">Connect</Text>
                      </View>
                    </TouchableOpacity>
                  </View>
                );
              })}
            </View>
          </Animated.View>
        )}
      </View>
      <View
        style={{flex: 0.11, paddingHorizontal: ms(20)}}
        className="justify-center bg-red border-t-[1.5px] border-[#E3E5F0]">
        <Animated.View {...starterAnimation('FadeInDown', 500, 200, 1)}>
          <Button
            {...{
              onClick: () => {
                // navigate('trouble', {});
                orgesp();
              },
              label: 'Search again',
              // border: true,
              // bcl: 'bg-w',
              // bcc: 'border-fb',
              // c: 'text-vt',
              enable: true,
            }}
          />
        </Animated.View>
      </View>
      {loading && <Modal type={'loader'} content={'Searching...'} />}
    </View>
  );
};

export default DeviceList;
