export { OtpInput, OtpInputProps, Theme, OtpInputRef } from "./OtpInput";
