import {Colors} from '@theme/colors';
import {BarHeight} from './barHeight';
import {sizeConfig} from './sizeConfig';
const {ms} = sizeConfig;
const {w} = Colors;
const container = {
  flex: 1,
  paddingTop: BarHeight,
  paddingHorizontal: ms(16),
  backgroundColor: w,
};
const containerX = {
  flex: 1,
  paddingTop: BarHeight,
  backgroundColor: w,
};
const shadow1 = {
  shadowColor: '#000',
  shadowOffset: {width: 0, height: 1},
  shadowOpacity: 0.8,
  shadowRadius: 2,
  elevation: 2,
};

export const styleConfig = {container, shadow1, containerX};
