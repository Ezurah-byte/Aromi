import {Dimensions} from 'react-native';

const {width, height} = Dimensions.get('window');
const [shortDimension, longDimension] =
  width < height ? [width, height] : [height, width];

//Default guideline sizes are based on standard ~5" screen mobile device
const guidelineBaseWidth = 350;
const guidelineBaseHeight = 680;

const scale = size => (shortDimension / guidelineBaseWidth) * size;
const verticalScale = size => (longDimension / guidelineBaseHeight) * size;
const moderateScale = (size, factor = 0.5) =>
  size + (scale(size) - size) * factor;
const moderateVerticalScale = (size, factor = 0.5) =>
  size + (verticalScale(size) - size) * factor;

export const sizeConfig = {
  sl: scale,
  vs: verticalScale,
  ms: moderateScale,
  mvs: moderateVerticalScale,
  wh: width,
  ht: height,
};

export const sliceString = (str, size) => {
  if (!str) {
    return '';
  }
  if (str?.length > size + 2) {
    return str.slice(0, size) + '....';
  }
  return str;
};
