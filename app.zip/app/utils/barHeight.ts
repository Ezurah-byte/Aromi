import {StatusBar} from 'react-native';

const BarHeight = StatusBar.currentHeight;

export {BarHeight};
