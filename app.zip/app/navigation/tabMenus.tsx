import React from 'react';
import {
  createBottomTabNavigator,
  BottomTabNavigationOptions,
} from '@react-navigation/bottom-tabs';
import {tabStacks} from './tabStacks';
import {Colors} from '@theme/colors';
import {Platform, View} from 'react-native';
import {sizeConfig} from '@utils/sizeConfig';

const Tab = createBottomTabNavigator();

const TabMenus = () => {
  const {gy, nvt, tb} = Colors;
  const {ms, vs} = sizeConfig;

  const handleTabOptions = (
    item: any,
    i: number,
    fields: any,
  ): BottomTabNavigationOptions => {
    const {label} = fields;
    return {
      tabBarLabel: label,
      tabBarLabelStyle: {
        fontFamily: 'Inter-SemiBold',
        fontSize: ms(10),
        marginBottom: vs(4),
        // backgroundColor: 'red',
      },
      tabBarItemStyle: {
        // backgroundColor: 'blue',
        // height: vs(50),
      },
      tabBarStyle: {
        backgroundColor: tb,
        height: vs(Platform.OS == 'ios' ? 65 : 45),
        paddingTop: vs(5),
      },
      tabBarIcon: ({focused, color}): any =>
        handleTabIcon(focused, fields, color, i),
    };
  };

  const handleTabIcon = (
    focused: boolean,
    fields: any,
    color: string,
    i: number,
  ) => {
    const {Icon} = fields;
    console.log(Icon, 'Icon');
    return (
      <View key={i}>
        <Icon color={color} />
      </View>
    );
  };

  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: nvt,
        tabBarInactiveTintColor: gy,
      }}>
      {tabStacks.map((fields, i) => {
        const {name, component} = fields;
        return (
          <Tab.Screen
            options={item => handleTabOptions(item, i, fields)}
            key={name}
            name={name}
            component={component}
          />
        );
      })}
    </Tab.Navigator>
  );
};

export default TabMenus;
