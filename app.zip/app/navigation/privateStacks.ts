import {
  ConnectScreen,
  DeviceList,
  SearchWifi,
  TrayName,
  TroubleScreen,
  WifiCommunication,
  WifiSuccess,
  ProfileScreen,
  AboutScreen,
  AppSettings,
  RecipeList,
  RecipeDetails,
  SmartJar,
  CustomizeLayout,
  TrayDetails,
} from '@private/index';
import TabMenus from './tabMenus';

export const privateStacks = [
  {
    name: 'Home',
    component: TabMenus,
    animations: {
      animation: 'fade',
      animationDuration: 3000,
      // presentation: 'fullScreenModal',
    },
  },
  {
    name: 'deviceList',
    component: DeviceList,
    animations: {
      animation: 'slide_from_bottom',
      animationDuration: 1000,
      // presentation: 'fullScreenModal',
    },
  },
  {
    name: 'connect',
    component: ConnectScreen,
    animations: {
      animation: 'slide_from_right',
      animationDuration: 1000,
      // presentation: 'fullScreenModal',
    },
  },
  {
    name: 'searchWifi',
    component: SearchWifi,
    animations: {
      animation: 'slide_from_right',
      animationDuration: 1000,
      // presentation: 'modal',
    },
  },
  {
    name: 'trayName',
    component: TrayName,
    animations: {
      animation: 'slide_from_right',
      animationDuration: 1000,
      // presentation: 'formSheet',
    },
  },
  {
    name: 'trouble',
    component: TroubleScreen,
    animations: {
      animation: 'slide_from_right',
      animationDuration: 1000,
      // presentation: 'transparentModal',
    },
  },
  {
    name: 'communication',
    component: WifiCommunication,
    animations: {
      animation: 'fade_from_bottom',
      animationDuration: 2000,
      // presentation: 'containedTransaprentModal',
    },
  },
  {
    name: 'wifiSuccess',
    component: WifiSuccess,
    animations: {
      animation: 'fade_from_bottom',
      animationDuration: 2000,
      presentation: 'modal',
    },
  },
  {
    name: 'profile',
    component: ProfileScreen,
    animations: {
      animation: 'slide_from_bottom',
      animationDuration: 2000,
      // presentation: 'fullScreenModal',
    },
  },
  {
    name: 'about',
    component: AboutScreen,
    animations: {
      animation: 'slide_from_left',
      animationDuration: 1000,
      // presentation: 'fullScreenModal',
    },
  },
  {
    name: 'appSettings',
    component: AppSettings,
    animations: {
      animation: 'slide_from_left',
      animationDuration: 1000,
      // presentation: 'fullScreenModal',
    },
  },
  {
    name: 'recipeList',
    component: RecipeList,
    animations: {
      animation: 'slide_from_right',
      animationDuration: 2000,
      // presentation: 'containedTransaprentModal',
    },
  },
  {
    name: 'smartJar',
    component: SmartJar,
    animations: {
      animation: 'slide_from_left',
      animationDuration: 1000,
      // presentation: 'formSheet',
    },
  },
  {
    name: 'customizeLayout',
    component: CustomizeLayout,
    animations: {
      animation: 'slide_from_right',
      animationDuration: 1000,
      // presentation: 'fullScreenModal',
    },
  },
  {
    name: 'trayDetails',
    component: TrayDetails,
    animations: {
      animation: 'slide_from_bottom',
      animationDuration: 2000,
      // presentation: 'fullScreenModal',
    },
  },
  {
    name: 'recipeDetails',
    component: RecipeDetails,
    animations: {
      animation: 'slide_from_bottom',
      animationDuration: 1000,
      // presentation: 'modal',
    },
  },
];

export const privateStacksModal = [
  {name: 'recipeDetails', component: RecipeDetails},
];
