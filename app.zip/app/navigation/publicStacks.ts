import {AuthScreen, OtpScreen} from '@public/index';

export const publicStacks = [
  {
    name: 'authScreen',
    component: AuthScreen,
    animations: {
      animation: 'slide_from_bottom',
      animationDuration: 3000,
    },
  },
  {
    name: 'otpScreen',
    component: OtpScreen,
    animations: {
      animation: 'slide_from_right',
      animationDuration: 1000,
    },
  },
];
