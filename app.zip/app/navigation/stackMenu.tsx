import React from 'react';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import {publicStacks} from './publicStacks';
import {privateStacks} from './privateStacks';
import {useAppSelector} from '@hooks/';
import {storage} from '@utils/index';
import {
  createStackNavigator,
  CardStyleInterpolators,
  HeaderStyleInterpolators,
  TransitionPresets,
  TransitionSpecs,
} from '@react-navigation/stack';
import {Easing} from 'react-native';
// import {useTransition} from 'react-native-reanimated';
const StackMenu = () => {
  const Stack = createNativeStackNavigator();
  const token = useAppSelector(state => state?.auth?.token);
  const storageToken = storage.getString('token');
  const stacks = token || storageToken ? privateStacks : publicStacks;
  return (
    <Stack.Navigator
      screenOptions={{
        headerShown: false,
        // gestureEnabled: true,
      }}>
      {stacks.map(fields => {
        const {name, component} = fields;
        // const customTransitionSpec = {
        //   open: {
        //     animation: 'decay',
        //     config: {
        //       deceleration: 0.997,
        //       velocity: 1,
        //       // useNativeDriver: true,
        //     },
        //   },
        //   close: {
        //     animation: 'decay',
        //     config: {
        //       deceleration: 0.997,
        //       velocity: 1,
        //       // useNativeDriver: true,
        //     },
        //   },
        // };
        return (
          <Stack.Screen
            options={{
              title: name,
              headerStyle: {
                backgroundColor: '#f4511e',
              },
              headerTintColor: '#fff',
              headerTitleStyle: {
                fontWeight: 'bold',
              },
              ...fields?.animations,

              // cardStyleInterpolator: CardStyleInterpolators.forHorizontalIOS,
              // transitionSpec: {
              //   open: customTransitionSpec.open,
              //   close: customTransitionSpec.close,
              // },
            }}
            key={name}
            name={name}
            component={component}
          />
        );
      })}
    </Stack.Navigator>
  );
};

export default StackMenu;
