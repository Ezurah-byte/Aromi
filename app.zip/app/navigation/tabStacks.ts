import {HomeScreen, NotificationScreen, SettingsScreen} from '@private/index';
import {HomeTab, NotifyTab, SettingTab} from '@vectors/vectorImages';

export const tabStacks = [
  {
    name: 'homeScreen',
    component: HomeScreen,
    label: 'Home',
    Icon: HomeTab,
  },
  {
    name: 'notificationScreen',
    component: NotificationScreen,
    label: 'Notification',
    Icon: NotifyTab,
  },
  {
    name: 'settingsScreen',
    component: SettingsScreen,
    label: 'Settings',
    Icon: SettingTab,
  },
];
