export const Example = {};
