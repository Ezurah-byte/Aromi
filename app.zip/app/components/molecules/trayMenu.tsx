import {View, Text, TouchableOpacity} from 'react-native';
import React from 'react';
import {BottomViewSheet, GrayText, HeaderText} from '@atoms/index';
import {sizeConfig} from '@utils/sizeConfig';
import {
  AddJar,
  AddTray,
  CloseIcon,
  RightArrow,
  ScanIcon,
} from '@vectors/vectorImages';
import {Colors} from '@theme/colors';
const TrayMenu = (SheetItems: any) => {
  const WrapperComponent = () => {
    const {ms, vs} = sizeConfig;
    const {mgy} = Colors;
    const menus = [
      {
        name: 'Add Tray',
        content: 'Add new Aromi Tray',
        Icon: AddTray,
      },
      {
        name: 'Add Jar',
        content: 'Add new Aromi Jar',
        Icon: AddJar,
      },
      {
        name: 'Scan Device',
        content: 'Add new device Manually',
        Icon: ScanIcon,
      },
    ];
    return (
      <View>
        <View
          className="flex-row justify-between"
          style={{paddingHorizontal: ms(10)}}>
          <HeaderText content={'Add device'} />
          <TouchableOpacity onPress={() => SheetItems?.closeSheet()}>
            <CloseIcon />
          </TouchableOpacity>
        </View>

        <View style={{}}>
          {menus.map(item => {
            const {Icon, name, content} = item;
            return (
              <View>
                <View
                  className="bg-w rounded-lg items-center flex-row  "
                  style={{
                    height: vs(63),
                    paddingHorizontal: vs(10),
                    marginVertical: 0,
                  }}>
                  <View className=" " style={{flex: 0.2}}>
                    <Icon />
                  </View>

                  <View style={{flex: 1.5, rowGap: vs(0)}}>
                    <View>
                      <HeaderText content={name} size={16} />
                    </View>
                    <View className="flex-row gap-x-2">
                      <View
                        className="flex-row items-center"
                        style={{columnGap: ms(3)}}>
                        <GrayText content={content} color={mgy} size={12} />
                      </View>
                    </View>
                  </View>

                  <View className="items-center" style={{flex: 0.2}}>
                    <TouchableOpacity onPress={SheetItems?.closeSheet()}>
                      <RightArrow />
                    </TouchableOpacity>
                  </View>
                </View>
                <View
                  className="border-b-[1px] flex-1 border-ph"
                  style={{marginHorizontal: ms(10)}}
                />
              </View>
            );
          })}
        </View>
      </View>
    );
  };
  return <BottomViewSheet {...{...SheetItems, WrapperComponent}} />;
};

export default TrayMenu;
