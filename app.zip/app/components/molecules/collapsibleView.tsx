import {ImageBackground, View, Text} from 'react-native';
import React, {useState} from 'react';
import Accordion from 'react-native-collapsible/Accordion';
import {sizeConfig} from '@utils/sizeConfig';
import {TrayJar, TrayHeader, HeaderText, GrayText} from '@atoms/index';
import {Images} from '@images/index';
import {Image} from 'react-native';
import Button from '../atoms/button';
import {navigate} from '@root/';

const CollapsibleView = ({navigation, trays}) => {
  console.log('Collapsible', trays);
  const {vs, ms} = sizeConfig;
  const [activeSections, setActiveSections] = useState([]);
  const SECTIONS = [
    {
      title: 'First',
      content: 'Lorem ipsum...',
    },
    {
      title: 'First',
      content: 'Lorem ipsum...',
    },
  ];

  const jars = [
    {
      name: 'Instant Coffee',
      battery: '80%',
      date: 'Oct 6,2024',
      quantity: '70%',
      color: '#ECE7F3',
    },
    {
      name: 'Sugar',
      battery: '65%',
      date: 'Dec 16,2024',
      quantity: '35%',
      color: '#F0F3E7',
    },
    {
      name: 'Chinnamon Powder',
      battery: '75%',
      date: 'Jun 04,2024',
      quantity: '90%',
      color: '#E7F2F3',
    },
    {
      name: 'Fresh Cow Milk',
      battery: '90%',
      date: 'Feb 20,2024',
      quantity: '55%',
      color: '#FDE0E0',
    },
  ];

  const renderJars = (item, index) => {
    console.log(item, 'render Content Collapsile ');
    return !(item?.jars.length > 0) ? (
      <ImageBackground
        source={Images.emptyOverlay}
        className="bg-w"
        style={{
          height: vs(200),
          width: '100%',
          opacity: 0.8,
          paddingHorizontal: ms(10),
          paddingVertical: vs(10),
          borderRadius: ms(10),
          marginBottom: vs(10),
        }}>
        <View className="items-center justify-center" style={{flex: 1}}>
          <Image
            source={Images.emptyTray}
            style={{height: vs(80), width: '50%'}}
            resizeMode="contain"
          />
          <View className="items-center">
            <HeaderText content={'Your Tray is empty'} size={vs(12)} />
            <Text
              className="font-inm text-gy text-center"
              style={{fontSize: ms(14)}}>
              Try adding your spice jar in your tray
            </Text>
          </View>
          <View className="w-full px-5 " style={{paddingTop: vs(20)}}>
            <Button
              {...{
                onClick: () => {
                  navigate('smartJar', {addTray: true, trayDetails: item});
                },
                label: 'Add Smart Jar',
                border: true,
                bcl: 'bg-w',
                bcc: 'border-fb',
                c: 'text-vt',
                enable: true,
                h: 35,
              }}
            />
          </View>
        </View>
      </ImageBackground>
    ) : (
      <View
        style={{
          paddingHorizontal: ms(10),
          backgroundColor: '#EFF5FF',
          paddingVertical: vs(10),
          borderRadius: ms(10),
          marginBottom: vs(10),
        }}>
        {item?.jars.map((itemData, index) => {
          return <TrayJar item={itemData} index={index} trayDetails={item} />;
        })}
        {item?.jars.length < 4 && (
          <View className="w-full px-5 " style={{paddingVertical: vs(5)}}>
            <Button
              {...{
                onClick: () => {
                  navigate('smartJar', {addTray: true, trayDetails: item});
                },
                label: 'Add Smart Jar',
                border: true,
                bcl: 'bg-w',
                bcc: 'border-fb',
                c: 'text-vt',
                enable: true,
                h: 35,
              }}
            />
          </View>
        )}
      </View>
    );
  };

  const _updateSections = activeSections => {
    console.log(activeSections);
    setActiveSections(activeSections);
  };

  return (
    <Accordion
      sections={trays}
      expandMultiple
      underlayColor="none"
      activeSections={activeSections}
      renderHeader={(item, index) => {
        console.log(item, index, 'check header collapsible');

        return <TrayHeader item={item} index={index} />;
      }}
      renderContent={renderJars}
      onChange={_updateSections}
      sectionContainerStyle={{marginVertical: vs(5)}}
    />
  );
};

export default CollapsibleView;
