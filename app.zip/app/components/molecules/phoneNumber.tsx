import {View, Text} from 'react-native';
import React, {memo, useState} from 'react';
import {sizeConfig} from '@utils/sizeConfig';
import {DownArrowCountry, Invalid} from '@vectors/vectorImages';
import {InputField, CountrySelector, LabelText} from '@atoms/index';
import {Colors} from '@theme/colors';
import {TouchableOpacity} from 'react-native';

const PhoneNumber = ({
  handleChange,
  currentValue,
  placeholder,
  inputType,
  inputStyle,
  holderColor,
  countryCode,
  setCountryCode,
  error,
}) => {
  const {vs, ms} = sizeConfig;
  const [visible, setVisible] = useState(false);
  const [isFocus, setIsFocus] = useState(false);
  // const [countryCode, setCountryCode] = useState({
  //   dial_code: '+91',
  //   code: 'IN',
  // });
  const handleVisible = () => {
    setVisible(true);
  };
  console.log(countryCode, visible);
  return (
    <View>
      <View>
        <LabelText content={'Phone number'} />
      </View>
      <View
        className={`px-1 py-1 ${
          isFocus && !error ? 'bg-[#E0D7F3]' : error ? 'bg-[#fcd2cf]' : ''
        } ${error ? 'border-[#fda28b]' : 'border-[#E0D7F3]'}   rounded-xl`}>
        <View
          className={`bg-w flex-row w-full rounded-xl ${
            error ? 'border-[#fda28b]' : 'border-ph'
          }   border-[1.5px]`}
          style={{height: vs(40), width: '100%'}}>
          <TouchableOpacity
            onPress={handleVisible}
            style={{paddingHorizontal: ms(10)}}
            className="flex-row  items-center justify-center ">
            <Text className="mr-2 font-in_sbl text-b text-base ">
              {countryCode?.code}
            </Text>
            <DownArrowCountry />
            <Text
              className="ml-2  text-b text-base "
              style={{
                fontFamily: 'Inter-Medium',
                letterSpacing: 1.5,
                fontSize: sizeConfig.ms(14),
              }}>
              {countryCode?.dial_code}
            </Text>
          </TouchableOpacity>
          <View className="flex-1 ">
            <InputField
              {...{
                setIsFocus,
                handleChange,
                currentValue,
                placeholder: 'EX : 9834457878',
                inputType: 'numeric',
                inputStyle: {},
                holderColor: holderColor || Colors.gy,
              }}
            />
          </View>
          {error && (
            <View className="absolute right-5 top-0 h-full justify-center">
              <Invalid />
            </View>
          )}

          <CountrySelector
            {...{visible, setVisible, countryCode, setCountryCode}}
          />
        </View>
      </View>
      {error && (
        <View className=" px-1 py-1">
          <Text className=" font-inm text-r ">Invalid mobile number</Text>
        </View>
      )}
    </View>
  );
};

export default memo(PhoneNumber);
