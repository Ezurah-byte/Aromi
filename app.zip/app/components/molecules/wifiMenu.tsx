import {View, Text, TouchableOpacity} from 'react-native';
import React, {useRef, useState} from 'react';
import {BottomViewSheet, Button, HeaderText} from '@atoms/index';
import {sizeConfig} from '@utils/sizeConfig';
import {
  AddJar,
  AddTray,
  CloseIcon,
  Rssi,
  ScanIcon,
} from '@vectors/vectorImages';
import {Colors} from '@theme/colors';
import TextField from './textField';

const WifiMenu = (SheetItems: any) => {
  const [password, setPassword] = useState('');

  const WrapperComponent = () => {
    const {ms, vs} = sizeConfig;
    const {mgy} = Colors;
    const menus = [
      {
        name: 'Jio_networ_26',
        content: 'Add new Aromi Tray',
        Icon: AddTray,
      },
      {
        name: 'Jio_networ_27',
        content: 'Add new Aromi Jar',
        Icon: AddJar,
      },
      {
        name: 'Jio_networ_28',
        content: 'Add new device Manually',
        Icon: ScanIcon,
      },
      {
        name: 'Jio_networ_29',
        content: 'Add new Aromi Tray',
        Icon: AddTray,
      },
      {
        name: 'Jio_networ_20',
        content: 'Add new Aromi Jar',
        Icon: AddJar,
      },
    ];
    const isWifi = false;
    return (
      <View style={{flex: 1}}>
        <View
          className="flex-row justify-between"
          style={{paddingHorizontal: ms(15)}}>
          <HeaderText
            content={isWifi ? 'Choose your WiFi' : 'Wi-Fi Password'}
            size={vs(15)}
          />
          <TouchableOpacity onPress={() => SheetItems?.closeSheet()}>
            <CloseIcon />
          </TouchableOpacity>
        </View>

        <View
          style={{paddingVertical: vs(10), paddingHorizontal: vs(10), flex: 1}}>
          {isWifi ? (
            <View>
              {menus.map((item, index) => {
                const {Icon, name, content} = item;
                return (
                  <View style={{}}>
                    <View
                      className="bg-w rounded-lg items-center flex-row  "
                      style={{
                        height: vs(37),
                        paddingHorizontal: vs(15),
                        marginVertical: 0,
                        backgroundColor: index == 3 ? '#F9F5FF' : '',
                      }}>
                      <View style={{flex: 1.5, rowGap: vs(0)}}>
                        <View>
                          {/* <HeaderText content={name} size={16} /> */}
                          <Text
                            className="font-inm text-[#101010]"
                            style={{fontSize: vs(14)}}>
                            {name}
                          </Text>
                        </View>
                      </View>

                      <View className="items-center" style={{flex: 0.2}}>
                        <TouchableOpacity onPress={SheetItems?.closeSheet()}>
                          <Rssi />
                        </TouchableOpacity>
                      </View>
                    </View>
                  </View>
                );
              })}
              <Button
                {...{
                  onClick: () => {},
                  label: 'Connect',
                  border: true,
                  bcl: 'bg-vt',
                  bcc: 'border-vt',
                  c: 'text-w',
                }}
              />
            </View>
          ) : (
            <View style={{flex: 1, rowGap: vs(40)}}>
              <View style={{flex: 1, rowGap: vs(20)}}>
                <Text className="font-inr text-bls " style={{fontSize: vs(12)}}>
                  Now let’s add your Aromi Tray to your local WiFi
                </Text>

                <TextField
                  {...{
                    label: 'Password',
                    currentValue: password,
                    handleChange: setPassword,
                    placeholder: 'Type your password',
                    holderColor: Colors.gy,
                    inputStyle: {
                      marginLeft: sizeConfig.ms(7),
                    },
                  }}
                />
              </View>
              <View style={{flex: 1, rowGap: vs(10)}}>
                <Button
                  {...{
                    onClick: () => {},
                    label: 'Connect',
                    border: true,
                    bcl: 'bg-vt',
                    bcc: 'border-vt',
                    c: 'text-w',
                  }}
                />
                <TouchableOpacity className="">
                  <Text className="text-center font-inbl text-vt">
                    Change network
                  </Text>
                </TouchableOpacity>
              </View>
            </View>
          )}
        </View>
      </View>
    );
  };
  return <BottomViewSheet {...{...SheetItems, WrapperComponent}} />;
};

export default WifiMenu;
