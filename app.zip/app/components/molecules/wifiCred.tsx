import {View, TouchableOpacity} from 'react-native';
import React from 'react';
import {BottomViewSheet, HeaderText} from '@atoms/index';
import {sizeConfig} from '@utils/sizeConfig';
import {CloseIcon} from '@vectors/vectorImages';
import {Colors} from '@theme/colors';
const WifiCred = (SheetItems: any) => {
  const WrapperComponent = () => {
    const {ms, vs} = sizeConfig;
    const {mgy} = Colors;

    return (
      <View>
        <View
          className="flex-row justify-between"
          style={{paddingHorizontal: ms(10)}}>
          <HeaderText content={'Wi-Fi Password'} />
          <TouchableOpacity onPress={() => SheetItems?.closeSheet()}>
            <CloseIcon />
          </TouchableOpacity>
        </View>

        <View style={{}}></View>
      </View>
    );
  };
  return <BottomViewSheet {...{...SheetItems, WrapperComponent}} />;
};

export default WifiCred;
