import {View, Text, TouchableOpacity, Image} from 'react-native';
import React, {useState} from 'react';
import {BottomViewSheet, GradientView, HeaderText} from '@atoms/index';
import {sizeConfig} from '@utils/sizeConfig';
import {CloseIcon} from '@vectors/vectorImages';
import {Colors} from '@theme/colors';
import {Images} from '@images/index';
import TextField from './textField';
import {BottomSheetTextInput} from '@gorhom/bottom-sheet';
import {TextInput} from 'react-native';
const SpiceSheet = (SheetItems: any) => {
  const {ms, vs} = sizeConfig;
  const {mgy} = Colors;
  const [editname, setEditName] = useState(SheetItems.name);

  const [currentIndex, setCurrentIndex] = useState(0);
  const menus = [
    {
      name: 'Content',
      action: () => {
        setCurrentIndex(0);
      },
    },
    {
      name: 'Style',
      action: () => {
        setCurrentIndex(1);
      },
    },
    {
      name: 'Font',
      action: () => {
        setCurrentIndex(2);
      },
    },
  ];
  const WrapperComponent = () => {
    return (
      <GradientView rh={true} isfull={true} colors={['#FFFFFF', '#F2F2F2']}>
        <View className="flex-1 py-2">
          <View
            className="flex-row justify-between border-b-[0.5px] border-ph"
            style={{paddingHorizontal: ms(10)}}>
            <View className="flex-row ">
              {menus.map((item, index) => {
                return (
                  <TouchableOpacity
                    key={index}
                    onPress={() => item.action()}
                    className={`px-5 py-2 ${
                      index == currentIndex ? 'border-b-[2px] border-b-nvt' : ''
                    } `}>
                    <Text
                      className={`font-inbl ${
                        index == currentIndex ? 'text-nvt' : 'text-[#667085]'
                      } `}
                      style={{fontSize: vs(12)}}>
                      {item.name}
                    </Text>
                  </TouchableOpacity>
                );
              })}
            </View>
            <TouchableOpacity
              onPress={() => SheetItems?.closeSheet()}
              style={{flex: 1}}
              className="justify-center items-end">
              <Image
                source={Images.back}
                style={{height: vs(25), width: vs(25)}}
                resizeMode="contain"
              />
            </TouchableOpacity>
          </View>

          <View
            style={{paddingHorizontal: vs(10)}}
            className="flex-row items-center my-3 ">
            <View style={{flex: 3}} className=" ">
              {/* <BottomSheetTextInput
                value={name}
                onChange={setName}
                placeholder="Please enter content"
              /> */}
              <View
                className={`bg-w flex-row w-full rounded-xl border-ph border-[1.5px]`}
                style={{height: vs(40), width: '100%'}}>
                <TextInput
                  placeholder="Please enter content"
                  value={editname}
                  onChangeText={setEditName}
                  style={{
                    fontFamily: 'Inter-Medium',
                    letterSpacing: 1.5,
                    fontSize: sizeConfig.ms(12),
                    paddingHorizontal: 10,
                    // backgroundColor: 'red',
                    width: '100%',
                  }}
                />
                {/* <TextInput
                  placeholder="klkc"
                  value={editname}
                  onChangeText={setEditName}
                /> */}
              </View>

              {/* <TextField
                {...{
                  label: '',
                  currentValue: name,
                  handleChange: setName,
                  placeholder: 'Please enter content',
                  holderColor: Colors.gy,
                  inputStyle: {
                    marginLeft: sizeConfig.ms(7),
                  },
                  noborder: true,
                }}
              /> */}
            </View>
            <View className="items-center" style={{flex: 1}}>
              <TouchableOpacity
                onPress={() => {
                  console.log('handle function', editname);
                  SheetItems.handleName(editname);
                }}
                className="justify-center">
                <Text
                  className="font-in_sbl text-center text-vt"
                  style={{fontSize: vs(14)}}>
                  Done
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </GradientView>
    );
  };
  return <BottomViewSheet {...{...SheetItems, WrapperComponent}} />;
};

export default SpiceSheet;
