import {View, Text} from 'react-native';
import React, {memo, useState} from 'react';
import {sizeConfig} from '@utils/sizeConfig';
import {InputField, LabelText} from '@atoms/index';
import {Colors} from '@theme/colors';
import {Invalid} from '@vectors/vectorImages';

const TextField = ({
  handleChange,
  currentValue,
  placeholder,
  inputType,
  inputStyle,
  holderColor,
  label,
  noborder,
  error,
}) => {
  const {vs, ms} = sizeConfig;
  const [isFocus, setIsFocus] = useState(false);

  return (
    <View>
      <View>{label && <LabelText content={label} />}</View>
      <View
        className={` ${
          noborder
            ? ''
            : `px-1 py-1 ${
                isFocus && !error?.isError
                  ? 'bg-[#E0D7F3]'
                  : !error?.isError
                  ? 'border-[#fda28b]'
                  : 'border-[#E0D7F3]'
              }  border-[#E0D7F3] rounded-xl`
        }`}>
        <View
          className={`bg-w flex-row w-full rounded-xl ${
            error?.isError ? 'border-[#fda28b]' : 'border-ph'
          }  border-[1.5px]`}
          style={{height: vs(40), width: '100%'}}>
          <View className="flex-1 ">
            <InputField
              {...{
                handleChange,
                currentValue,
                placeholder: placeholder,
                inputType: 'default',
                inputStyle: inputStyle,
                holderColor: holderColor || Colors.gy,
                isFocus,
                setIsFocus,
              }}
            />
          </View>
          {error?.isError && (
            <View className="absolute right-5 top-0 h-full justify-center">
              <Invalid />
            </View>
          )}
        </View>
      </View>
      {error?.isError && (
        <View className=" px-1 py-1">
          <Text className=" font-inm text-r ">{error?.message}</Text>
        </View>
      )}
    </View>
  );
};

export default memo(TextField);
