import {View, Text, TouchableOpacity} from 'react-native';
import React from 'react';
import RoundedImage from './roundedImage';
import {sizeConfig} from '@utils/sizeConfig';
import {Images} from '@images/index';
import {Colors} from '@theme/colors';
import HeaderText from './headerText';
import GrayText from './grayText';
import ButtonEdit from './buttonEdit';
import {navigate} from '@root/';
import Animated from 'react-native-reanimated';
import {starterAnimation} from '@animation/starterAnimation';
const TrayHeader = ({item, index}) => {
  const {vs, ms} = sizeConfig;
  const {tray, battery, warning, jars} = Images;
  console.log(item, 'item Tray Header');
  const isEmptyTray = !(item?.jars.length > 0);
  return (
    <Animated.View
      {...starterAnimation('FadeInDown', 500, 500, index + 1)}
      className="bg-w rounded-lg items-center flex-row "
      style={{
        height: vs(63),
        paddingHorizontal: vs(10),
        marginVertical: 0,
      }}>
      <View className=" " style={{flex: 0.4}}>
        <RoundedImage
          url={tray}
          style={{
            height: vs(50),
            width: vs(50),
            borderRadius: ms(100),
            backgroundColor: Colors.w,
          }}
        />
      </View>

      <View style={{flex: 1, rowGap: vs(0)}}>
        <View>
          <HeaderText content={item?.name} size={18} />
        </View>
        <View className="flex-row gap-x-2">
          <View className="flex-row items-center" style={{columnGap: ms(3)}}>
            <RoundedImage
              url={battery}
              style={{height: vs(14), width: vs(14)}}
            />
            <GrayText
              content={`${item?.battery}%`}
              color={Colors.mgy}
              size={12}
            />
          </View>
          <View className="flex-row items-center" style={{columnGap: ms(5)}}>
            <RoundedImage
              url={isEmptyTray ? warning : jars}
              style={{height: vs(12), width: vs(12)}}
            />
            <GrayText
              font={'font-inm'}
              content={
                isEmptyTray ? 'Empty Tray' : `${item?.jars.length} Spice Jars`
              }
              color={Colors.mgy}
              size={12}
            />
          </View>
        </View>
      </View>

      <TouchableOpacity
        onPress={() => {
          navigate('trayDetails', {trayDetails: item});
        }}
        className="items-end"
        style={{flex: 0.3}}>
        <ButtonEdit isBg={true} />
      </TouchableOpacity>
    </Animated.View>
  );
};

export default TrayHeader;
