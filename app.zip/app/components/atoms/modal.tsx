import {View, TouchableOpacity, StatusBar, Image, Text} from 'react-native';
import React from 'react';
import Modalize from 'react-native-modal';
import {sizeConfig} from '@utils/sizeConfig';
import {Images} from '@images/index';
import {CloseIcon, ConfrmIcon} from '@vectors/vectorImages';
import Button from './button';
import LottieView from 'lottie-react-native';
import {Lotties} from '@lotties/index';
import HeaderTwo from './headerTwo';
import HeaderText from './headerText';
import {useAppDispatch} from '@hooks/';
import {setToken} from '@library/features/auth/authSlice';
import {storage} from '@utils/index';
const Modal = ({close, type, content}) => {
  const dispatch = useAppDispatch();

  const {vs, ms} = sizeConfig;

  const RenderSingleTray = () => {
    return (
      <View
        className="bg-w rounded-2xl"
        style={{height: vs(300), width: '100%'}}>
        <View
          className="items-end "
          style={{paddingHorizontal: ms(15), paddingVertical: vs(15)}}>
          <TouchableOpacity onPress={() => close(false)}>
            <CloseIcon />
          </TouchableOpacity>
        </View>
        <View>
          <Image
            source={Images.singleTray}
            style={{height: vs(180), width: '100%'}}
            resizeMode="contain"
            className="rounded-2xl"
          />
        </View>
        <View style={{paddingHorizontal: vs(25)}}>
          <Button
            {...{
              onClick: () => {},
              label: 'Connect',
              border: true,
              bcl: 'bg-vt',
              bcc: 'border-vt',
              c: 'text-w',
            }}
          />
        </View>
      </View>
    );
  };

  const RenderLogout = ({content, header, btnName, action}) => {
    return (
      <View>
        <View className="bg-w rounded-2xl py-4 px-4" style={{width: '100%'}}>
          <View className="flex-row justify-between " style={{}}>
            <View>
              <ConfrmIcon />
            </View>
            <TouchableOpacity onPress={() => close(false)}>
              <CloseIcon />
            </TouchableOpacity>
          </View>
          <View className="gap-y-2 py-5">
            <HeaderText content={header} size={18} />
            <Text
              className="text-[#475467] font-inr"
              style={{fontSize: vs(12)}}>
              {content}
            </Text>
          </View>

          <View style={{rowGap: vs(10)}}>
            <Button
              {...{
                onClick: () => action(),
                label: btnName,
                enable: true,
              }}
            />
            <Button
              {...{
                onClick: () => {
                  close();
                },
                label: 'Cancel',
                border: true,
                bcl: 'bg-w',
                bcc: 'border-ph',
                c: 'text-blp',
              }}
            />
          </View>
        </View>
      </View>
    );
  };
  let modalProps = {
    backdropColor: '#383831',
  };
  switch (type) {
    case 'singleTray':
      modalProps = {
        animationIn: 'fadeInUpBig',
        animationOut: 'fadeInDownBig',

        animationInTiming: 500,
        animationOutTiming: 500,

        style: {justifyContent: 'flex-end'},
        backdropColor: '#383831',
      };
      break;
    case 'loader':
      modalProps = {
        animationIn: 'fadeIn',
        animationInTiming: 500,
        // style: {justifyContent: 'flex-end'},
        backdropColor: '#383831',
        hasBackdrop: false,
      };
      break;
    case 'logout':
    case 'delete':
      modalProps = {
        animationIn: 'fadeInUpBig',
        animationOut: 'fadeInDownBig',
        animationInTiming: 500,
        animationOutTiming: 500,
        style: {justifyContent: 'flex-end'},
        backdropColor: '#383831',
      };
      break;
  }
  return (
    <Modalize isVisible={true} {...{...modalProps}}>
      {type != 'loader' && <StatusBar backgroundColor={'rgba(56,56,49,0.7)'} />}
      {type == 'singleTray' && <RenderSingleTray />}
      {type == 'loader' && (
        <View
          className="bg-white rounded-2xl gap-y-1 justify-center items-center self-center"
          style={{height: vs(90), width: vs(90)}}>
          <LottieView
            source={require('../../assets/lotties/loader.json')}
            style={{
              height: vs(40),
              width: vs(40),
            }}
            autoPlay
            loop
          />
          <Text className="font-in_sbl text-blp" style={{fontSize: vs(10)}}>
            {content}
          </Text>
        </View>
      )}
      {type == 'logout' && (
        <View>
          <RenderLogout
            {...{
              content:
                ' Are you sure you want to log out of your Ezurah account?',
              header: 'Logout Confirmation',
              btnName: 'Log Out',
              action: () => {
                try {
                  storage.clearAll();
                  dispatch(setToken({token: false}));
                } catch (err) {
                  console.log(err, 'clear all logout');
                }
              },
            }}
          />
        </View>
      )}

      {type == 'delete' && (
        <View>
          <RenderLogout
            {...{
              content:
                'Are you sure you want to delete your account? This action is permanent and cannot be undone.',
              header: 'Delete Account',
              btnName: 'Delete Account',
              action: () => {
                try {
                  storage.clearAll();
                  dispatch(setToken({token: false}));
                } catch (err) {
                  console.log(err, 'clear all logout');
                }
              },
            }}
          />
        </View>
      )}
    </Modalize>
  );
};

export default Modal;
