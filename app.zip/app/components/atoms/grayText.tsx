import {Text} from 'react-native';
import React from 'react';
import {sizeConfig} from '@utils/sizeConfig';

const GrayText = ({content, size, color, font}) => {
  const {ms} = sizeConfig;
  return (
    <Text
      className={`${color || 'text-gy'} ${font || 'font-inr'}`}
      style={{fontSize: ms(size || 14)}}>
      {content}
    </Text>
  );
};

export default GrayText;
