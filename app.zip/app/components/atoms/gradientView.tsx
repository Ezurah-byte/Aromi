import React from 'react';
import LinearGradient from 'react-native-linear-gradient';
import {BarHeight, sizeConfig} from '@utils/index';
const GradientView = ({children, colors, isfull, rh}: {children: any}) => {
  const {ms} = sizeConfig;

  return (
    <LinearGradient
      colors={colors}
      style={{
        flex: 1,
        paddingTop: isfull ? 0 : BarHeight,
        paddingHorizontal: rh ? 0 : ms(16),
        borderTopLeftRadius: !rh ? 0 : ms(10),
        borderTopRightRadius: !rh ? 0 : ms(10),
      }}>
      {children}
    </LinearGradient>
  );
};

export default GradientView;
