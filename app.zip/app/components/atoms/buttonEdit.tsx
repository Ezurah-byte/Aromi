import {View} from 'react-native';
import React from 'react';
import {EditIcon} from '@vectors/vectorImages';
import {sizeConfig} from '@utils/sizeConfig';

const ButtonEdit = ({isBg}) => {
  const {vs, ms} = sizeConfig;
  console.log(isBg, 'ISBG');
  return (
    <View
      className={`${isBg ? 'bg-vlvt' : ''} border-[${
        isBg ? '1px' : '0px'
      }] justify-center items-center rounded-full  border-[#E9D7FE]`}
      style={{height: vs(30), width: vs(30)}}>
      <EditIcon />
    </View>
  );
};

export default ButtonEdit;
