import {View, TouchableOpacity, Text, Image} from 'react-native';
import React, {useMemo, useCallback, useState} from 'react';
import BottomSheet, {
  BottomSheetView,
  BottomSheetBackdrop,
  BottomSheetScrollView,
} from '@gorhom/bottom-sheet';
import {GrayText, HeaderText, InputField} from '@atoms/index';
import {sizeConfig} from '@utils/sizeConfig';
import {
  AddJar,
  AddTray,
  CloseIcon,
  RightArrow,
  ScanIcon,
} from '@vectors/vectorImages';

import {TextField} from '@molecules/index';
import {Colors} from '@theme/colors';
import Button from './button';
import {navigate} from '@root/';

const TraySheet = ({modalRef, closeSheet, snap}) => {
  const {ms, vs} = sizeConfig;
  const {mgy} = Colors;
  const menus = [
    {
      name: 'Add Tray',
      content: 'Add new Aromi Tray',
      Icon: AddTray,
      action: () => {
        closeSheet();
        navigate('deviceList', {});
      },
    },
    // {
    //   name: 'Add Jar',
    //   content: 'Add new Aromi Jar',
    //   Icon: AddJar,
    // },
    {
      name: 'Scan Device',
      content: 'Add new device Manually',
      Icon: ScanIcon,
      action: () => {
        closeSheet();
        navigate('deviceList', {});
      },
    },
  ];

  const handleSheetChanges = useCallback((index: number) => {
    console.log('handleSheetChanges', index);
    index == -1 && closeSheet();
  }, []);

  const snapPoints = useMemo(() => snap || ['50%', '50%'], []);

  return (
    <BottomSheet
      enableContentPanningGesture={false}
      keyboardBehavior="interactive"
      keyboardBlurBehavior="restore"
      handleComponent={null}
      backdropComponent={props => (
        <BottomSheetBackdrop
          pressBehavior="none"
          {...props}
          disappearsOnIndex={-1}
          appearsOnIndex={0}
        />
      )}
      ref={modalRef}
      // index={1}
      enableDynamicSizing={true}
      // snapPoints={snapPoints}
      onChange={handleSheetChanges}>
      <BottomSheetScrollView scrollEnabled={false}>
        <View>
          <View
            className="flex-row justify-between"
            style={{paddingHorizontal: ms(10), paddingTop: vs(10)}}>
            <HeaderText content={'Add device'} />
            <TouchableOpacity onPress={() => closeSheet()}>
              <CloseIcon />
            </TouchableOpacity>
          </View>

          <View className="" style={{}}>
            {menus.map((item, index) => {
              const {Icon, name, content} = item;
              return (
                <TouchableOpacity onPress={() => item?.action()} key={index}>
                  <View
                    className="bg-w rounded-lg items-center flex-row  "
                    style={{
                      height: vs(63),
                      paddingHorizontal: vs(10),
                      marginVertical: 0,
                    }}>
                    <View className=" " style={{flex: 0.2}}>
                      <Icon />
                    </View>

                    <View style={{flex: 1.5, rowGap: vs(0)}}>
                      <View>
                        <HeaderText content={name} size={16} />
                      </View>
                      <View className="flex-row gap-x-2">
                        <View
                          className="flex-row items-center"
                          style={{columnGap: ms(3)}}>
                          <GrayText content={content} color={mgy} size={12} />
                        </View>
                      </View>
                    </View>

                    <View className="items-center" style={{flex: 0.2}}>
                      <View>
                        <RightArrow />
                      </View>
                    </View>
                  </View>
                  {menus.length - 1 != index && (
                    <View
                      className="border-b-[1px]  border-ph"
                      style={{marginHorizontal: ms(10)}}
                    />
                  )}
                </TouchableOpacity>
              );
            })}
          </View>
        </View>
      </BottomSheetScrollView>
    </BottomSheet>
  );
};

export default TraySheet;
