import {View, Text, TouchableOpacity} from 'react-native';
import React from 'react';
import {BackArrow} from '@vectors/vectorImages';
import {sizeConfig} from '@utils/sizeConfig';
import {navigate} from '@root/';

const HeaderBack = ({navigation}) => {
  const {vs} = sizeConfig;
  return (
    <TouchableOpacity
      onPress={() => {
        navigation();
      }}
      style={{paddingVertical: vs(17)}}>
      <BackArrow />
    </TouchableOpacity>
  );
};

export default HeaderBack;
