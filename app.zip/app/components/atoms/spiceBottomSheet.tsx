import {
  View,
  TouchableOpacity,
  TextInput,
  Text,
  Image,
  Keyboard,
} from 'react-native';
import React, {useMemo, useCallback, useState} from 'react';
import BottomSheet, {
  BottomSheetModalProvider,
  BottomSheetModal,
  BottomSheetView,
  BottomSheetBackdrop,
  BottomSheetScrollView,
} from '@gorhom/bottom-sheet';
import {GradientView} from '@atoms/index';
import {Images} from '@images/index';
import {sizeConfig} from '@utils/sizeConfig';
import {
  Bold,
  Underline,
  Italic,
  LeftAlign,
  CenterAlign,
  RightAlign,
} from '@vectors/vectorImages';
import Slider from '@react-native-community/slider';
import Button from './button';

const SpiceBottomSheet = ({
  navigation,
  modalRef,
  openSheet,
  closeSheet,
  snap,
  bg,
  name,
  handleName,
  isBold,
  isItalic,
  isUnderline,
  currentAlign,
  fontSize,
  setIsBold,
  setIsItalic,
  setIsUnderline,
  setCurrentAlign,
  setFontSize,
  type,
  currentLayout,
  setCurrentlayout,
  handleLayout,
  initialTranslateX,
  initialTranslateY,
  translateX,
  translateY,
}) => {
  const {ms, vs} = sizeConfig;

  const [editname, setEditName] = useState(name || '');

  const handleSheetChanges = useCallback((index: number) => {
    console.log('handleSheetChanges', index);
    // index == -1 && closeSheet();
  }, []);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [currentIndex1, setCurrentIndex1] = useState(0);
  // const [currentLayout, setCurrentlayout] = useState(0);
  // const [isBold, setIsBold] = useState(false);
  // const [isItalic, setIsItalic] = useState(false);
  // const [isUnderline, setIsUnderline] = useState(false);
  // const [currentAlign, setCurrentAlign] = useState(1);
  // const [fontSize, setFontSize] = useState(18);

  const snapPoints = useMemo(() => snap || ['50%', '50%'], []);

  const menus = [
    {
      name: 'Content',
      action: () => {
        setCurrentIndex(0);
      },
    },
    {
      name: 'Style',
      action: () => {
        setCurrentIndex(1);
        // closeSheet();
        // openSheet();
      },
    },
    // {
    //   name: 'Font',
    //   action: () => {
    //     setCurrentIndex(2);
    //   },
    // },
  ];

  const layoutMenus = [
    {
      name: 'Layout',
      action: () => {
        setCurrentIndex1(0);
      },
    },
    // {
    //   name: 'Style',
    //   action: () => {
    //     setCurrentIndex(1);
    //   },
    // },
    // {
    //   name: 'Font',
    //   action: () => {
    //     setCurrentIndex(2);
    //   },
    // },
  ];

  const layouts = [
    {
      name: 'empty',
      url: Images.empty,
    },
    {
      name: 'rightBorad',
      url: Images.rightBoard,
    },
    {
      name: 'equalBoard',
      url: Images.equalBoard,
    },
    {
      name: 'verticalBoard',
      url: Images.verticalBoard,
    },
  ];
  const styleMenu = [
    {
      Icon: Bold,
      action: () => setIsBold(!isBold),
      show: isBold,
    },
    {
      Icon: Underline,
      action: () => setIsUnderline(!isUnderline),
      show: isUnderline,
    },
    {
      Icon: Italic,
      action: () => setIsItalic(!isItalic),
      show: isItalic,
    },
  ];
  const alignMenu = [
    {
      Icon: LeftAlign,
      value: 'left',
    },
    {
      Icon: CenterAlign,
      value: 'center',
    },
    {
      Icon: RightAlign,
      value: 'right',
    },
  ];
  return (
    <BottomSheet
      // enableContentPanningGesture={false}
      // keyboardBehavior="interactive"
      // keyboardBlurBehavior="restore"
      handleComponent={null}
      backdropComponent={props => (
        <BottomSheetBackdrop
          pressBehavior="none"
          {...props}
          disappearsOnIndex={-1}
          appearsOnIndex={0}
        />
      )}
      ref={modalRef}
      enableDynamicSizing={true}
      // index={1}
      // snapPoints={snapPoints}
      // enablePanDownToClose
      // topInset={100}
      onChange={handleSheetChanges}>
      <BottomSheetScrollView scrollEnabled={false}>
        <GradientView rh={true} isfull={true} colors={['#FFFFFF', '#F2F2F2']}>
          {type == 'text' && (
            <View className="flex-1 py-2">
              <View
                className="flex-row justify-between border-b-[0.5px] border-ph"
                style={{paddingHorizontal: ms(10)}}>
                <View className="flex-row ">
                  {menus.map((item, index) => {
                    return (
                      <TouchableOpacity
                        key={index}
                        onPress={() => item.action()}
                        className={`px-5 py-2 ${
                          index == currentIndex
                            ? 'border-b-[2px] border-b-nvt'
                            : ''
                        } `}>
                        <Text
                          className={`font-inbl ${
                            index == currentIndex
                              ? 'text-nvt'
                              : 'text-[#667085]'
                          } `}
                          style={{fontSize: vs(12)}}>
                          {item.name}
                        </Text>
                      </TouchableOpacity>
                    );
                  })}
                </View>
                <TouchableOpacity
                  onPress={() => closeSheet()}
                  style={{flex: 1}}
                  className="justify-center items-end">
                  <Image
                    source={Images.back}
                    style={{height: vs(25), width: vs(25)}}
                    resizeMode="contain"
                  />
                </TouchableOpacity>
              </View>

              <View
                style={{paddingHorizontal: vs(10)}}
                className="flex-row items-center my-5 ">
                <View style={{flex: 3}} className=" ">
                  <View
                    className={`bg-w flex-row w-full rounded-lg border-ph border-[1.5px]`}
                    style={{height: vs(30), width: '100%'}}>
                    <TextInput
                      placeholder="Please enter content"
                      value={editname}
                      onChangeText={setEditName}
                      style={{
                        fontFamily: 'Inter-Medium',
                        letterSpacing: 1,
                        fontSize: sizeConfig.ms(12),
                        paddingHorizontal: 10,
                        // backgroundColor: 'red',
                        width: '100%',
                        height: vs(30),
                      }}
                    />

                    <View></View>
                  </View>
                </View>
                <View className="items-center" style={{flex: 1}}>
                  <TouchableOpacity
                    onPress={() => {
                      console.log('handle function', editname);
                      handleName(editname);
                      Keyboard.dismiss();
                    }}
                    className="justify-center">
                    <Text
                      className="font-in_sbl text-center text-vt"
                      style={{fontSize: vs(14)}}>
                      Done
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
              {currentIndex == 1 && (
                <View className="bg-[#E9EBEF] mx-3 rounded-lg  py-5 px-5 ">
                  <View className=" flex-row justify-center ">
                    <View className="flex-row">
                      {styleMenu.map((item, index) => {
                        const {Icon} = item;
                        return (
                          <TouchableOpacity
                            onPress={() => item.action()}
                            className={`${
                              item?.show ? 'bg-w' : ''
                            } mx-1 w-12 h-8 justify-center items-center rounded-lg py-1 px-2`}>
                            <Icon color={item?.show ? '#7F56D9' : '#000000'} />
                          </TouchableOpacity>
                        );
                      })}
                    </View>

                    <View className="flex-row">
                      {alignMenu.map((item, index) => {
                        const {Icon} = item;
                        const isSelected = currentAlign == index;

                        return (
                          <TouchableOpacity
                            onPress={() => setCurrentAlign(index)}
                            className={`${
                              isSelected ? 'bg-w' : ''
                            } mx-1 w-12 h-8 justify-center items-center rounded-lg py-1 px-2`}>
                            <Icon color={isSelected ? '#7F56D9' : '#000000'} />
                          </TouchableOpacity>
                        );
                      })}
                    </View>
                  </View>
                  <View className="border-b-[1px] border-b-ph mt-3" />

                  <View>
                    <View className="flex-row justify-between items-center  mt-4">
                      <View>
                        <Text
                          className="font-in_sbl text-[#475467]"
                          style={{fontSize: vs(13)}}>
                          Font Size
                        </Text>
                      </View>
                      <View className="rounded-lg justify-center bg-w h-8 w-12">
                        <Text
                          className="text-center font-inbl text-blp"
                          style={{fontSize: vs(10)}}>
                          {Math.round(fontSize)}px
                        </Text>
                      </View>
                    </View>

                    <View className="flex-row justify-between items-center  mt-4">
                      <View>
                        <Slider
                          style={{
                            width: 250,
                            // height: 40,
                            marginLeft: -15,
                          }}
                          minimumValue={0}
                          maximumValue={50}
                          thumbTintColor="#7F56D9"
                          value={fontSize}
                          onValueChange={value => {
                            setFontSize(value);
                          }}
                          minimumTrackTintColor="#7F56D9"
                          maximumTrackTintColor="#000000"
                        />
                      </View>
                      <View className="rounded-lg px-2 flex-row items-center justify-center bg-ph h-8 w-20">
                        <TouchableOpacity
                          className="px-2 "
                          onPress={() => {
                            setFontSize(prev => {
                              if (prev < 50 && prev != 1) {
                                return prev - 1;
                              }
                              return prev;
                            });
                          }}>
                          <Text
                            className="text-center font-inm text-blp"
                            style={{fontSize: vs(18)}}>
                            -
                          </Text>
                        </TouchableOpacity>
                        <View className="border-r-[1px] border-r-gy h-5 mx-1" />
                        <TouchableOpacity
                          onPress={() => {
                            setFontSize(prev => {
                              if (prev <= 50) {
                                return prev + 1;
                              }
                              return prev;
                            });
                          }}
                          className="px-2">
                          <Text
                            className="text-center font-inr text-blp"
                            style={{fontSize: vs(18)}}>
                            +
                          </Text>
                        </TouchableOpacity>
                      </View>
                    </View>

                    <View className="border-b-[1px] border-b-ph mt-7" />

                    <View className="flex-row justify-between items-center  mt-4">
                      <View>
                        <Text
                          className="font-in_sbl text-[#475467]"
                          style={{fontSize: vs(13)}}>
                          Font Color
                        </Text>
                      </View>
                      <View className="rounded-lg px-2 flex-row items-center justify-center  h-8 w-20 gap-x-1">
                        <TouchableOpacity className="h-6 w-6 rounded-full border-ph border-[2px] bg-w "></TouchableOpacity>
                        <TouchableOpacity className="h-6 w-6 rounded-full border-red-600 border-[2px] bg-b "></TouchableOpacity>
                      </View>
                    </View>
                  </View>
                </View>
              )}
            </View>
          )}

          {type == 'layout' && (
            <View className="flex-1 py-2">
              <View
                className="flex-row justify-between border-b-[0.5px] border-ph"
                style={{paddingHorizontal: ms(10)}}>
                <View className="flex-row ">
                  {layoutMenus.map((item, index) => {
                    return (
                      <TouchableOpacity
                        key={index}
                        onPress={() => item.action()}
                        className={`px-5 py-2 ${
                          index == currentIndex1
                            ? 'border-b-[2px] border-b-nvt'
                            : ''
                        } `}>
                        <Text
                          className={`font-inbl ${
                            index == currentIndex1
                              ? 'text-nvt'
                              : 'text-[#667085]'
                          } `}
                          style={{fontSize: vs(12)}}>
                          {item.name}
                        </Text>
                      </TouchableOpacity>
                    );
                  })}
                </View>
                <TouchableOpacity
                  onPress={() => closeSheet()}
                  style={{flex: 1}}
                  className="justify-center items-end">
                  <Image
                    source={Images.back}
                    style={{height: vs(25), width: vs(25)}}
                    resizeMode="contain"
                  />
                </TouchableOpacity>
              </View>
              <View className="flex-row flex-wrap py-5 justify-center  mx-2">
                {layouts.map((item, index) => {
                  return (
                    <TouchableOpacity
                      onPress={() => {
                        setCurrentlayout(index);
                      }}
                      className={`mx-2 my-2 ${
                        currentLayout == index
                          ? 'border-red-600 border-[2.5px]'
                          : 'border-ph border-[1.5px]'
                      } bg-w py-2 px-2   rounded-xl`}>
                      <Image
                        source={item?.url}
                        style={{
                          height: vs(65),
                          width: vs(120),
                        }}
                        resizeMode="contain"
                      />
                    </TouchableOpacity>
                  );
                })}
              </View>
            </View>
          )}
          <View className="mx-5 mb-5">
            <Button
              {...{
                onClick: () => {
                  handleLayout(
                    name,
                    translateX.value,
                    translateY.value,
                    currentAlign,
                    {bold: isBold, italic: isItalic, underline: isUnderline},
                    fontSize,
                    currentLayout,
                  );
                  navigation.goBack();
                },
                label: 'Save',
                enable: name.length > 3 && name != 'Tab-Text-Menu',

                // border: true,
                // bcl: 'bg-w',
                // bcc: 'border-fb',
                // c: 'text-vt',
              }}
            />
          </View>
        </GradientView>
      </BottomSheetScrollView>
    </BottomSheet>
  );
};

export default SpiceBottomSheet;
