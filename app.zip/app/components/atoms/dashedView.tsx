import {sizeConfig} from '@utils/sizeConfig';
import React from 'react';
import {View, Text, StyleSheet} from 'react-native';
import Svg, {Rect} from 'react-native-svg';

const DashedView = ({height, borderRadius, children, color, bg}) => {
  // Adjust for the border and radius
  const width = 356;
  const strokeWidth = 1.5; // Adjust as needed
  const rectWidth = width - strokeWidth;
  const rectHeight = height - strokeWidth;

  return (
    <View style={{width, height}}>
      <Svg width={width} height={height}>
        {/* Outer rectangle with border and border radius */}
        <Rect
          x={strokeWidth / 2}
          y={strokeWidth / 2}
          width={rectWidth}
          height={rectHeight}
          rx={borderRadius} // Border radius
          ry={borderRadius} // Border radius
          stroke={color}
          strokeWidth={strokeWidth}
          fill={'#FFFFFF'}
          opacity={0.6}
          strokeDasharray="5 5" // Dash pattern
        />
        {children}
      </Svg>
    </View>
  );
};

const styles = StyleSheet.create({
  innerContent: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff', // Optional background color for inner content
  },
});

export default DashedView;
