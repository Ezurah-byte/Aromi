import React, {useEffect, useState} from 'react';
import {ImageBackground, StyleSheet, View} from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
} from 'react-native-reanimated';
import {
  GestureHandlerRootView,
  Gesture,
  GestureDetector,
} from 'react-native-gesture-handler';
import {Images} from '@images/index';

const ExpandableBox = ({
  parentWidth,
  parentHeight,
  boxWidth,
  boxHeight,
  text,
  align = 'center', // default alignment
  isBold,
  isItalic,
  isUnderline,
  currentAlign,
  fontSize,
  initialTranslateX,
  initialTranslateY,
  setinitialTranslateX,
  setinitialTranslateY,
  translateY,
  translateX,
}) => {
  console.log(align, 'textbtext texbtebxt etx text');

  const initialX = useSharedValue(0);
  const initialY = useSharedValue(0);
  const [isMounted, isSetMounted] = useState(false);

  // Calculate the initial position based on alignment
  React.useEffect(() => {
    console.log(text, 'chnage');
  }, [text]);
  React.useEffect(() => {
    switch (align) {
      case 'left':
        translateX.value = 0;
        break;
      case 'right':
        translateX.value = parentWidth - boxWidth;
        break;
      case 'center':
        translateX.value = (parentWidth - boxWidth) / 2;
        break;
      case 'none':
        translateX.value = initialTranslateX;
        translateY.value = initialTranslateY;
        break;
    }
    // Center vertically by default

    align != 'none' && (translateY.value = (parentHeight - boxHeight) / 2);
  }, [align, parentWidth, parentHeight, boxWidth, boxHeight]);

  useEffect(() => {
    console.log(
      '--------------------------------------------------------',
      translateX.value,
      translateY.value,
    );
    if (isMounted) {
      setinitialTranslateX(translateX.value);
      setinitialTranslateY(translateY.value);
      isSetMounted(true);
    }
  }, [translateX.value, translateY.value]);

  // Pan gesture for dragging
  const panGesture = Gesture.Pan()
    .onBegin(() => {
      initialX.value = translateX.value;
      initialY.value = translateY.value;
    })
    .onUpdate(event => {
      const newX = initialX.value + event.translationX;
      const newY = initialY.value + event.translationY;

      // Constrain the box within the parent view
      const clampedX = Math.max(0, Math.min(newX, parentWidth - boxWidth));
      const clampedY = Math.max(0, Math.min(newY, parentHeight - boxHeight));

      translateX.value = clampedX;
      translateY.value = clampedY;
    });

  // Animated style for box
  const animatedStyle = useAnimatedStyle(() => {
    return {
      width: boxWidth,
      height: boxHeight,
      transform: [
        {translateX: translateX.value},
        {translateY: translateY.value},
      ],
    };
  });

  return (
    <GestureHandlerRootView style={styles.container}>
      <GestureDetector gesture={panGesture}>
        <Animated.View
          className={` ${
            text.length > 0 ? 'border-[#2970FF] border-[1.5px] ' : ''
          }`}
          style={[styles.box, animatedStyle]}>
          <Animated.Text
            className={'text-b'}
            style={{
              fontWeight: isBold ? 'bold' : '300',
              textDecorationLine: isUnderline ? 'underline' : 'none',
              fontStyle: isItalic ? 'italic' : '',
              fontSize: fontSize,
            }}>
            {text}
          </Animated.Text>
          {text.length > 0 && (
            <View
              className="h-3 w-3 rounded-full bg-[#2970FF] absolute "
              style={{bottom: -6, right: -6}}
            />
          )}
        </Animated.View>
      </GestureDetector>
    </GestureHandlerRootView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  box: {
    backgroundColor: 'transparent',
    borderRadius: 3,
  },
  text: {
    color: '',
    fontWeight: '500',
    textAlign: 'center',
    fontSize: 20,
  },
});

export default ExpandableBox;
