import React from 'react';
import {View, Image, StyleSheet} from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withTiming,
  Easing,
} from 'react-native-reanimated';

const InfiniteRotatingImage = ({source, style}) => {
  const rotateValue = useSharedValue(0);

  rotateValue.value = withRepeat(
    withTiming(360, {
      duration: 10000, // 10 seconds for a slow rotation
      easing: Easing.linear,
    }),
    -1, // Infinite repetitions
    false, // No reverse
  );

  const animatedStyle = useAnimatedStyle(() => {
    return {
      transform: [{rotate: `${rotateValue.value}deg`}],
    };
  });

  return (
    // <View style={style}>
    <Animated.Image
      source={source}
      resizeMode="contain"
      style={[style, animatedStyle]}
    />
    // </View>
  );
};

const styles = StyleSheet.create({
  image: {
    width: 100,
    height: 100,
  },
});

export default InfiniteRotatingImage;
