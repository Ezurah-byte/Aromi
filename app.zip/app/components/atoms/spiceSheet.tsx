import {View, TouchableOpacity, Text, Image} from 'react-native';
import React, {useMemo, useCallback, useState} from 'react';
import BottomSheet, {
  BottomSheetView,
  BottomSheetBackdrop,
  BottomSheetScrollView,
} from '@gorhom/bottom-sheet';
import {GrayText, HeaderText, InputField} from '@atoms/index';
import {sizeConfig} from '@utils/sizeConfig';
import {
  AddJar,
  AddTray,
  CloseIcon,
  RightArrow,
  Rssi,
  ScanIcon,
} from '@vectors/vectorImages';

import {TextField} from '@molecules/index';
import {Colors} from '@theme/colors';
import Button from './button';
import {navigate} from '@root/';
import {ScrollView} from 'react-native';

const SpiceSheet = ({modalRef, closeSheet, spiceType, setSpiceType}) => {
  const {ms, vs} = sizeConfig;

  const handleSheetChanges = useCallback((index: number) => {
    console.log('handleSheetChanges', index);
    index == -1 && closeSheet();
  }, []);

  const spiceList = [
    'Seed Spices',
    'Root Spices',
    'Bark Spices',
    'Leaf Spices',
    'Fruit Spices',
    'Flower Spices',
    'Bulb Spices',
    'Berry Spices',
    'Resin Spices',
    'Stalk Spices',
    'Bud Spices',
    'Aromatic Spices',
    'Heat Spices',
    'Sweet Spices',
    'Sour Spices',
    'Pepper Spices',
    'Herb Spices',
    'Citrus Spices',
    'Chili Spices',
    'Exotic Spices',
    'Savory Spices',
    'Warm Spices',
    'Cooling Spices',
    'Earthy Spices',
    'Nutty Spices',
    'Pungent Spices',
    'Smoky Spices',
    'Bitter Spices',
    'Fruity Spices',
    'Tropical Spices',
  ];

  return (
    <BottomSheet
      enableContentPanningGesture={false}
      keyboardBehavior="interactive"
      keyboardBlurBehavior="restore"
      handleComponent={null}
      backdropComponent={props => (
        <BottomSheetBackdrop
          pressBehavior="none"
          {...props}
          disappearsOnIndex={-1}
          appearsOnIndex={0}
        />
      )}
      ref={modalRef}
      enableDynamicSizing={true}
      //   index={1}
      //   snapPoints={snapPoints}

      onChange={handleSheetChanges}>
      <BottomSheetView style={{height: 350}}>
        <View style={{}} className="py-4">
          <View
            className="flex-row justify-between "
            style={{paddingHorizontal: ms(15)}}>
            <HeaderText content={'Spice Type'} size={vs(15)} />
            <TouchableOpacity onPress={() => closeSheet()}>
              <CloseIcon />
            </TouchableOpacity>
          </View>

          <ScrollView
            style={{
              paddingVertical: vs(10),
              paddingHorizontal: vs(10),
            }}>
            <View className="">
              <View className="pb-3">
                {spiceList.map((item, index) => {
                  return (
                    <TouchableOpacity
                      style={{}}
                      onPress={() => {
                        setSpiceType(item);
                        closeSheet();
                      }}>
                      <View
                        className="rounded-lg  items-center flex-row  "
                        style={{
                          height: vs(37),
                          paddingHorizontal: vs(15),
                          marginVertical: 0,
                          backgroundColor:
                            spiceType == item ? '#F9F5FF' : '#FFFFFF',
                        }}>
                        <View style={{flex: 1.5, rowGap: vs(0)}}>
                          <View>
                            <Text
                              className="font-inm text-[#101010]"
                              style={{fontSize: vs(14)}}>
                              {item}
                            </Text>
                          </View>
                        </View>

                        <View className="items-center" style={{flex: 0.2}}>
                          <View>{/* <Rssi /> */}</View>
                        </View>
                      </View>
                    </TouchableOpacity>
                  );
                })}
              </View>
            </View>
          </ScrollView>
        </View>
      </BottomSheetView>
    </BottomSheet>
  );
};

export default SpiceSheet;
