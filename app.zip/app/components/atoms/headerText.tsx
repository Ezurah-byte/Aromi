import {Text} from 'react-native';
import React from 'react';
import {sizeConfig} from '@utils/sizeConfig';

const HeaderText = ({content, size}) => {
  const {ms} = sizeConfig;
  return (
    <Text className="font-inbl text-blp" style={{fontSize: ms(size || 20)}}>
      {content}
    </Text>
  );
};

export default HeaderText;
