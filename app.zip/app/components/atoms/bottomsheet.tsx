import {View, KeyboardAvoidingView, TextInput} from 'react-native';
import React, {useMemo, useCallback} from 'react';
import BottomSheet, {
  BottomSheetModalProvider,
  BottomSheetModal,
  BottomSheetView,
  BottomSheetBackdrop,
} from '@gorhom/bottom-sheet';
const BottomViewSheet = ({
  modalRef,
  openSheet,
  closeSheet,
  WrapperComponent,
  snap,
  bg,
}) => {
  console.log('older sheet');
  const handleSheetChanges = useCallback((index: number) => {
    console.log('handleSheetChanges', index);
  }, []);

  const snapPoints = useMemo(() => snap || ['40%', '40%'], []);
  return (
    <BottomSheet
      keyboardBehavior="interactive"
      keyboardBlurBehavior="restore"
      handleComponent={null}
      backdropComponent={props => (
        <BottomSheetBackdrop
          {...props}
          disappearsOnIndex={-1}
          appearsOnIndex={0}
          pressBehavior="none"
        />
      )}
      ref={modalRef}
      index={1}
      snapPoints={snapPoints}
      onChange={handleSheetChanges}>
      <BottomSheetView style={{flex: 1}}>
        <WrapperComponent />
      </BottomSheetView>
    </BottomSheet>
  );
};

export default BottomViewSheet;
