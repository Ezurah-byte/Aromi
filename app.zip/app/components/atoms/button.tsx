import {View, Text, TouchableOpacity} from 'react-native';
import React, {memo} from 'react';
import {sizeConfig} from '@utils/sizeConfig';

const Button = ({label, bcl, bcc, border, c, onClick, enable, h}) => {
  const {ms, vs} = sizeConfig;

  const visibleStyle = 'rounded-lg bg-nvt justify-center';
  const inVisibleStyle =
    'rounded-lg bg-ds justify-center border-dsb border-[1.5px]';

  return (
    <TouchableOpacity
      onPress={() => {
        onClick();
      }}
      className={` ${
        enable
          ? border
            ? `rounded-lg ${bcl} justify-center ${bcc} border-[1.5px]`
            : visibleStyle
          : inVisibleStyle
      }`}
      style={{height: vs(h || 40)}}>
      <Text
        className={`text-center ${
          enable ? (border ? c : 'text-w') : border ? c : 'text-gy'
        }  font-in_sbl`}
        style={{fontSize: ms(14)}}>
        {label || ''}
      </Text>
    </TouchableOpacity>
  );
};

export default memo(Button);
// border
//           ? `rounded-lg ${bcl} justify-center ${bcc} border-[1.5px]`
//           : visibleStyle
