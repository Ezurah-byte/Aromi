import {View, Text, TouchableOpacity} from 'react-native';
import React from 'react';
import {GrayBack} from '@vectors/vectorImages';
import {sizeConfig} from '@utils/sizeConfig';
import {HeaderText} from '@atoms/index';
import Animated from 'react-native-reanimated';
import {starterAnimation} from '@animation/starterAnimation';
const HeaderTwo = ({bottom, single, header, bg, iconC, navigation}) => {
  const {vs, ms} = sizeConfig;

  return (
    <View
      className={`flex-row items-center ${bg || 'bg-w'} ${
        bottom ? 'border-b-[1.5px] border-[#E3E5F0]' : ''
      }`}
      style={{paddingVertical: vs(17), paddingHorizontal: bottom ? ms(16) : 0}}>
      <TouchableOpacity
        className=""
        onPress={() => {
          navigation();
        }}
        style={{flex: 1}}>
        <Animated.View {...starterAnimation('FadeInUp', 500, 200, 1)}>
          <GrayBack color={iconC} />
        </Animated.View>
      </TouchableOpacity>
      <View className="items-center" style={{flex: 1}}>
        <Animated.View {...starterAnimation('FadeInUp', 500, 200, 1)}>
          {!single && <HeaderText content={header} size={ms(16)} />}
        </Animated.View>
      </View>
      <View style={{flex: 1}}></View>
    </View>
  );
};

export default HeaderTwo;
