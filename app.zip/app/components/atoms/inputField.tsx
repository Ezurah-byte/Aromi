import {TextInput} from 'react-native';
import React, {memo, useState} from 'react';
import {Colors} from '@theme/colors';
import {sizeConfig} from '@utils/sizeConfig';

const InputField = ({
  handleChange,
  currentValue,
  placeholder,
  inputType,
  inputStyle,
  holderColor,
  setIsFocus,
}) => {
  return (
    <TextInput
      onFocus={() => {
        setIsFocus(true);
      }}
      onBlur={() => {
        setIsFocus(false);
      }}
      onChangeText={handleChange}
      style={{
        fontFamily: 'Inter-Medium',
        letterSpacing: 1.5,
        fontSize: sizeConfig.ms(14),
        ...inputStyle,
      }}
      value={currentValue}
      placeholder={placeholder || ''}
      keyboardType={inputType || 'default'}
      placeholderTextColor={holderColor || ''}
    />
  );
};

export default memo(InputField);
