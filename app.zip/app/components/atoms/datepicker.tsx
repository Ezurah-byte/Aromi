import {View, Text, TouchableOpacity} from 'react-native';
import React from 'react';
import {sizeConfig} from '@utils/sizeConfig';
import LabelText from './labelText';
import {DateIcon, DownIcon} from '@vectors/vectorImages';
import DateTimePicker from '@react-native-community/datetimepicker';
import moment from 'moment';

const DatePicker = ({showDate, setShowDate, expDate, setExpDate}) => {
  const {vs, ms} = sizeConfig;
  return (
    <View>
      <LabelText content={'Expire Date'} />

      <TouchableOpacity
        onPress={() => {
          setShowDate(true);
        }}
        className="px-1 py-1  rounded-xl">
        <View
          className={`bg-w flex-row w-full rounded-xl border-ph border-[1.5px]`}
          style={{height: vs(40), width: '100%'}}>
          <View className="flex-1 flex-row items-center gap-x-3 pl-7">
            <DateIcon />
            <Text
              className={`font-inm ${expDate ? 'text-blp' : 'text-gy'}`}
              style={{fontSize: vs(13)}}>
              {expDate ? moment(expDate).format('MMM D, YYYY') : 'Select Date'}
            </Text>
          </View>
        </View>
      </TouchableOpacity>

      {showDate && (
        <DateTimePicker
          minimumDate={new Date()}
          mode="date"
          display="calendar"
          onChange={(e, date) => {
            setExpDate(date);
            setShowDate(false);
          }}
          value={new Date(expDate) || new Date()}
        />
      )}
    </View>
  );
};

export default DatePicker;
