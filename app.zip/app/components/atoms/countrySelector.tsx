import React, {useState} from 'react';
import {TouchableOpacity, View, Text} from 'react-native';
import {CountryPicker} from 'react-native-country-codes-picker';

const CountrySelector = ({
  visible,
  setVisible,
  countryCode,
  setCountryCode,
}) => {
  return (
    <CountryPicker
      style={{
        modal: {
          height: 500,
        },
      }}
      show={visible}
      onBackdropPress={() => {
        setVisible(false);
      }}
      pickerButtonOnPress={item => {
        console.log(item);
        setCountryCode(item);
        setVisible(false);
      }}
    />
  );
};

export default CountrySelector;
