import {Text} from 'react-native';
import React from 'react';
import {sizeConfig} from '@utils/sizeConfig';

const LabelText = ({content}) => {
  const {ms} = sizeConfig;
  return (
    <Text className="ml-1 font-inm text-bls mb-1  " style={{fontSize: ms(14)}}>
      {content}
    </Text>
  );
};

export default LabelText;
