import {Text, TouchableOpacity} from 'react-native';
import React, {memo} from 'react';
import {sizeConfig} from '@utils/sizeConfig';

const ButtonQuestion = ({content, onClick}) => {
  const {ms} = sizeConfig;

  return (
    <TouchableOpacity
      onPress={() => {
        onClick();
      }}>
      <Text
        className={`text-center text-vt  font-in_sbl`}
        style={{fontSize: ms(14)}}>
        {content}
      </Text>
    </TouchableOpacity>
  );
};

export default memo(ButtonQuestion);
