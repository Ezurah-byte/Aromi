import {View, Text} from 'react-native';
import React from 'react';
import {sizeConfig} from '@utils/sizeConfig';
import LabelText from './labelText';
import {DownIcon} from '@vectors/vectorImages';
import {TouchableOpacity} from 'react-native';

const DropDown = ({openSheet, spiceType}) => {
  const {vs, ms} = sizeConfig;
  return (
    <View>
      <LabelText content={'Spice Type'} />

      <TouchableOpacity
        onPress={() => {
          openSheet();
        }}
        className="px-1 py-1  rounded-xl">
        <View
          className={`bg-w flex-row w-full rounded-xl border-ph border-[1.5px]`}
          style={{height: vs(40), width: '100%'}}>
          <View className="flex-1 flex-row items-center justify-between px-4">
            <Text
              className={`font-inm ${spiceType ? 'text-blp' : 'text-gy'}`}
              style={{fontSize: vs(13)}}>
              {spiceType ? spiceType : 'Select '}
            </Text>
            <DownIcon />
          </View>
        </View>
      </TouchableOpacity>
    </View>
  );
};

export default DropDown;
