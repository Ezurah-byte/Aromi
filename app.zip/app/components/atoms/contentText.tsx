import {Text} from 'react-native';
import React from 'react';
import {sizeConfig} from '@utils/sizeConfig';

const ContenText = ({content}) => {
  const {ms, vs} = sizeConfig;
  return (
    <Text
      className="font-inr text-blp"
      style={{fontSize: ms(14), lineHeight: vs(19)}}>
      {content}
    </Text>
  );
};

export default ContenText;
