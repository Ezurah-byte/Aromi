import {View, Text, TouchableOpacity} from 'react-native';
import React from 'react';
import RoundedImage from './roundedImage';
import {sizeConfig} from '@utils/sizeConfig';
import {Images} from '@images/index';
import {Colors} from '@theme/colors';
import HeaderText from './headerText';
import GrayText from './grayText';
import ButtonEdit from './buttonEdit';
import {navigate} from '@root/';
import moment from 'moment';
const {vs, ms} = sizeConfig;
const {jar, battery, warning, quantity, date} = Images;
const TrayJar = ({item, trayDetails, index}) => {
  console.log(item, 'Tray Jars');
  const persentage =
    index == 0 ? '50%' : index == 1 ? '70%' : index == 2 ? '35%' : '80%';
  const color =
    index == 0
      ? '#ECE7F3'
      : index == 1
      ? '#F0F3E7'
      : index == 2
      ? '#E7F2F3'
      : '#FDE0E0';
  return (
    <View
      className="bg-w rounded-lg items-center flex-row "
      style={{
        height: vs(53),
        paddingHorizontal: vs(10),
        marginVertical: 10,
      }}>
      <View
        className={` rounded-lg absolute`}
        style={{
          height: '100%',
          width: persentage,
          backgroundColor: color,
        }}></View>

      <View className=" " style={{flex: 0.4}}>
        <RoundedImage
          url={jar}
          style={{
            height: vs(40),
            width: vs(40),
            borderRadius: ms(100),
            backgroundColor: Colors.w,
          }}
        />
      </View>

      <View style={{flex: 1, rowGap: vs(0)}}>
        <View>
          <HeaderText content={item?.spiceName} size={13} />
        </View>
        <View className="flex-row gap-x-2">
          <View className="flex-row items-center" style={{columnGap: ms(3)}}>
            <RoundedImage
              url={quantity}
              style={{height: vs(10), width: vs(10)}}
            />
            <GrayText content={persentage} color={Colors.mgy} size={12} />
          </View>
          <View className="flex-row items-center" style={{columnGap: ms(5)}}>
            <RoundedImage url={date} style={{height: vs(12), width: vs(12)}} />
            <GrayText
              font={'font-inm'}
              content={moment(item?.expDate).format('MMMM D, YYYY')}
              color={Colors.mgy}
              size={12}
            />
          </View>
        </View>
      </View>

      <TouchableOpacity
        onPress={() => {
          navigate('smartJar', {
            addTray: false,
            trayDetails: trayDetails,
            jarData: item,
            Cindex: index,
          });
        }}
        className="items-end"
        style={{flex: 0.3}}>
        <ButtonEdit isBg={false} />
      </TouchableOpacity>
    </View>
  );
};

export default TrayJar;
