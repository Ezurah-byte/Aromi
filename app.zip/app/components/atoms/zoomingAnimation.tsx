import React, {useEffect} from 'react';
import {View, Image, StyleSheet} from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withTiming,
  Easing,
} from 'react-native-reanimated';

const ZoomingImage = ({source, style, direction = 'clock'}) => {
  const scaleValue = useSharedValue(1);

  useEffect(() => {
    const zoomIn = direction === 'clock' ? 1.1 : 0.7;
    const zoomOut = direction === 'clock' ? 0.7 : 1.1;

    scaleValue.value = withRepeat(
      withTiming(zoomIn, {
        duration: 2000, // 2 seconds for a slow zoom in
        easing: Easing.inOut(Easing.ease),
      }),
      -1, // Infinite repetitions
      true, // Reverse the animation
      finished => {
        if (finished) {
          scaleValue.value = withTiming(zoomOut, {
            duration: 2000,
            easing: Easing.inOut(Easing.ease),
          });
        }
      },
    );
  }, [direction, scaleValue]);

  const animatedStyle = useAnimatedStyle(() => {
    return {
      transform: [{scale: scaleValue.value}],
    };
  });

  return (
    <View style={style}>
      <Animated.Image source={source} style={[style, animatedStyle]} />
    </View>
  );
};

const styles = StyleSheet.create({
  image: {
    width: 100,
    height: 100,
  },
});

export default ZoomingImage;
