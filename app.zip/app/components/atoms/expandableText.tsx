import React from 'react';
import {StyleSheet, Text, View} from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withSpring,
  withDecay,
} from 'react-native-reanimated';
import {
  GestureHandlerRootView,
  Gesture,
  GestureDetector,
} from 'react-native-gesture-handler';

const THRESHOLD = 5; // Threshold for minimal movement after drag

const ExpandableText = ({parentWidth, parentHeight}) => {
  const translateX = useSharedValue(0);
  const translateY = useSharedValue(0);
  const initialX = useSharedValue(0);
  const initialY = useSharedValue(0);
  // console.log(parentWidth,"")

  const panGesture = Gesture.Pan()
    .onBegin(event => {
      // Store the initial position when drag starts
      initialX.value = translateX.value;
      initialY.value = translateY.value;
    })
    .onUpdate(event => {
      // Update the position based on drag movement
      translateX.value = event.translationX + initialX.value;
      translateY.value = event.translationY + initialY.value;

      // Constrain movement within the parent view
      translateX.value = Math.max(
        0,
        Math.min(translateX.value, parentWidth - 100),
      );
      translateY.value = Math.max(
        0,
        Math.min(translateY.value, parentHeight - 50),
      );
    })
    .onEnd(() => {
      // Apply threshold for minimal movement
      if (
        Math.abs(translateX.value - initialX.value) < THRESHOLD &&
        Math.abs(translateY.value - initialY.value) < THRESHOLD
      ) {
        translateX.value = withSpring(initialX.value);
        translateY.value = withSpring(initialY.value);
      } else {
        // Smooth end with decay
        translateX.value = withDecay({
          velocity: translateX.value,
          clamp: [0, parentWidth - 100],
        });
        translateY.value = withDecay({
          velocity: translateY.value,
          clamp: [0, parentHeight - 50],
        });
      }
    });

  const animatedStyle = useAnimatedStyle(() => {
    return {
      transform: [
        {translateX: translateX.value},
        {translateY: translateY.value},
      ],
    };
  }, [translateX.value, translateY.value]);

  return (
    <GestureHandlerRootView style={styles.container}>
      <GestureDetector gesture={panGesture}>
        <Animated.View
          style={[
            {...styles.textContainer, width: parentWidth},
            animatedStyle,
          ]}>
          <Text style={styles.text}>Drag Me</Text>
        </Animated.View>
      </GestureDetector>
    </GestureHandlerRootView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    // Ensure the container has fixed dimensions
  },
  textContainer: {
    backgroundColor: 'skyblue',
    borderRadius: 8,
    padding: 10,
    alignItems: 'center',
    justifyContent: 'center',
    height: 50, // Height of the draggable area
  },
  text: {
    color: 'white',
    fontSize: 16,
  },
});

export default ExpandableText;
