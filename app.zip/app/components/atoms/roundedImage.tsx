import {Image} from 'react-native';
import React from 'react';

const RoundedImage = ({url, style}) => {
  return <Image source={url} style={style} resizeMode="contain" />;
};

export default RoundedImage;
