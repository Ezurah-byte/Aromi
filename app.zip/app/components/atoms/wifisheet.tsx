import {View, TouchableOpacity, Text, Image} from 'react-native';
import React, {useMemo, useCallback, useState} from 'react';
import BottomSheet, {
  BottomSheetView,
  BottomSheetBackdrop,
  BottomSheetScrollView,
} from '@gorhom/bottom-sheet';
import {GrayText, HeaderText, InputField} from '@atoms/index';
import {sizeConfig} from '@utils/sizeConfig';
import {
  AddJar,
  AddTray,
  CloseIcon,
  RightArrow,
  Rssi,
  ScanIcon,
} from '@vectors/vectorImages';

import {TextField} from '@molecules/index';
import {Colors} from '@theme/colors';
import Button from './button';
import {navigate} from '@root/';

const WifiSheet = ({
  modalRef,
  closeSheet,
  snap,
  wifiList,
  connectableDevice,
}) => {
  const {ms, vs} = sizeConfig;
  const {mgy} = Colors;
  const [ssid, setSsid] = useState(null);
  const [password, setPassword] = useState('');
  const [isWifiPass, setIsWifiPassword] = useState(false);
  console.log(wifiList, 'wifiDevices');

  const handleSheetChanges = useCallback((index: number) => {
    console.log('handleSheetChanges', index);
    // index == -1 && closeSheet();
  }, []);

  const snapPoints = useMemo(() => snap || ['50%', '50%'], []);
  const isWifi = true;
  return (
    <BottomSheet
      enableContentPanningGesture={false}
      keyboardBehavior="interactive"
      keyboardBlurBehavior="restore"
      handleComponent={null}
      backdropComponent={props => (
        <BottomSheetBackdrop
          pressBehavior="none"
          {...props}
          disappearsOnIndex={-1}
          appearsOnIndex={0}
        />
      )}
      ref={modalRef}
      enableDynamicSizing={true}
      //   index={1}
      //   snapPoints={snapPoints}
      onChange={handleSheetChanges}>
      <BottomSheetScrollView scrollEnabled={false}>
        <View style={{flex: 1}} className="py-4">
          <View
            className="flex-row justify-between "
            style={{paddingHorizontal: ms(15)}}>
            <HeaderText
              content={isWifi ? 'Choose your WiFi' : 'Wi-Fi Password'}
              size={vs(15)}
            />
            <TouchableOpacity onPress={() => closeSheet()}>
              <CloseIcon />
            </TouchableOpacity>
          </View>

          <View
            style={{
              paddingVertical: vs(10),
              paddingHorizontal: vs(10),
              flex: 1,
            }}>
            {!isWifiPass ? (
              <View className="">
                <View className="pb-3">
                  {wifiList.map((item, index) => {
                    console.log(
                      ssid,
                      item.ssid,
                      'wifiList Map',
                      index,
                      ssid == item?.ssid,
                    );
                    return (
                      <TouchableOpacity
                        style={{}}
                        onPress={() => {
                          setSsid(item?.ssid);
                        }}>
                        <View
                          className=" rounded-lg items-center flex-row  "
                          style={{
                            height: vs(37),
                            paddingHorizontal: vs(15),
                            marginVertical: 0,
                            backgroundColor:
                              ssid == item?.ssid ? '#F9F5FF' : '#FFFFFF',
                          }}>
                          <View style={{flex: 1.5, rowGap: vs(0)}}>
                            <View>
                              <Text
                                className="font-inm text-[#101010]"
                                style={{fontSize: vs(14)}}>
                                {item?.ssid}
                              </Text>
                            </View>
                          </View>

                          <View className="items-center" style={{flex: 0.2}}>
                            <View>
                              <Rssi />
                            </View>
                          </View>
                        </View>
                      </TouchableOpacity>
                    );
                  })}
                </View>

                <Button
                  {...{
                    onClick: () => {
                      setIsWifiPassword(true);
                    },
                    label: 'Connect',
                    // border: true,
                    // bcl: 'bg-vt',
                    // bcc: 'border-vt',
                    // c: 'text-w',
                    enable: ssid ? true : false,
                  }}
                />
              </View>
            ) : (
              <View style={{flex: 1, rowGap: vs(20)}}>
                <View style={{flex: 1, rowGap: vs(10)}}>
                  <Text
                    className="font-inr text-bls "
                    style={{fontSize: vs(12)}}>
                    Now let’s add your Aromi Tray to your local WiFi
                  </Text>

                  <TextField
                    {...{
                      label: 'Password',
                      currentValue: password,
                      handleChange: setPassword,
                      placeholder: 'Type your password',
                      holderColor: Colors.gy,
                      inputStyle: {
                        marginLeft: sizeConfig.ms(7),
                      },
                    }}
                  />
                </View>
                <View style={{flex: 1, rowGap: vs(10)}}>
                  <Button
                    {...{
                      onClick: () => {
                        navigate('communication', {
                          connectableDevice: connectableDevice,
                          ssid: ssid,
                          password: password,
                        });
                      },
                      label: 'Connect',
                      // border: true,
                      // bcl: 'bg-vt',
                      // bcc: 'border-vt',
                      // c: 'text-w',
                      enable: password.length > 8 && true,
                    }}
                  />
                  <TouchableOpacity
                    className=""
                    onPress={() => {
                      setIsWifiPassword(false);
                    }}>
                    <Text className="text-center font-inbl text-vt">
                      Change network
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
            )}
          </View>
        </View>
      </BottomSheetScrollView>
    </BottomSheet>
  );
};

export default WifiSheet;
