import {View, Text} from 'react-native';
import React, {useState} from 'react';
// import {OtpInput} from 'react-native-otp-entry';
import {Colors} from '@theme/colors';
import {OtpInput} from '../../packageModule/src/index';
import {LabelText, GrayText, Button} from '@atoms/index';
import {sizeConfig, storage} from '@utils/index';
import {useAppDispatch} from '@hooks/';
import {setToken} from '@library/features/auth/authSlice';
import {setUser} from '@library/features/auth/userSlice';

const OtpField = ({mobileNumber}) => {
  const {ms, vs} = sizeConfig;
  const dispatch = useAppDispatch();
  const [isValid, setIsValid] = useState(false);

  const handelVerify = () => {
    try {
      storage.set('token', '123123');
      storage.set('lastLogin', mobileNumber);
      const token = storage.getString('token');
      const lastLogin = storage.getString('lastLogin');
      console.log(' token', token);
      const userInit = {
        number: mobileNumber,
      };
      dispatch(setToken({token: token}));
      try {
        const userDataStringfy = storage.getString(`${mobileNumber}`);
        let userData = JSON.parse(userDataStringfy);
        console.log('Already have a number', userData);
        dispatch(
          setUser({
            name: 'allData',
            data: userData,
          }),
        );
      } catch (e) {
        storage.set(`${mobileNumber}`, JSON.stringify(userInit));
        console.log('new  number');
      }

      dispatch(
        setUser({
          name: 'number',
          data: mobileNumber,
        }),
      );

      // dispatch(setUser({name: 'wifiCred', data: {ssid, password}}));

      const userDataStringfy = storage.getString(`${mobileNumber}`);
      // let userData = JSON.parse(userDataStringfy);

      // const userDataCheck = storage.getString(`${mobileNumber}`);
      console.log(userDataStringfy, 'userDataCheck');
    } catch (err) {
      console.log('err handleVerify', err);
    }
  };
  return (
    <View style={{gap: vs(2)}}>
      <LabelText content={'Secure code'} />
      <OtpInput
        numberOfDigits={4}
        autoFocus={true}
        focusColor="green"
        focusStickBlinkingDuration={500}
        onTextChange={text => {
          text.length <= 3 && setIsValid(false);
        }}
        onFilled={text => {
          setIsValid(true);
        }}
        theme={{
          containerStyle: {
            justifyContent: 'flex-start',
            gap: ms(8),
          },
          inputsContainerStyle: {},
          pinCodeContainerStyle: {
            width: ms(64),
            height: ms(64),
            // borderColor: Colors.nvt,
            borderWidth: ms(2),
            borderRadius: sizeConfig.ms(10),
          },
          pinCodeTextStyle: {
            color: Colors.nvt,
            fontFamily: 'Inter-Bold',
            fontSize: ms(34),
          },
          focusStickStyle: {
            backgroundColor: Colors.nvt,
          },
          filledPinCodeContainerStyle: {
            borderColor: Colors.nvt,
            borderWidth: ms(2),
            // height: ms(70),
            // width: ms(70),
          },
          focusedPinCodeContainerStyle: {
            borderColor: Colors.nvt,
            borderWidth: ms(2),
          },
        }}
      />
      <View className="flex-row">
        <GrayText content={'Didn’t receive your code?'} />
        <Text className="font-inr text-vt ml-1" style={{fontSize: ms(14)}}>
          00:60
        </Text>
      </View>

      <View style={{marginTop: vs(15)}}>
        <Button enable={isValid} onClick={handelVerify} label="Continue" />
      </View>
    </View>
  );
};

export default OtpField;
