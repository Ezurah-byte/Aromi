import {Text, TouchableOpacity, View} from 'react-native';
import React from 'react';
import {sizeConfig} from '@utils/sizeConfig';
import {HomeAdd} from '@vectors/vectorImages';
import Animated from 'react-native-reanimated';
import {starterAnimation} from '@animation/starterAnimation';
const DashBoardHeader = ({content, isRight, openSheet}) => {
  const {ms, vs} = sizeConfig;
  return (
    <Animated.View
      {...starterAnimation('FadeInUp', 500, 400, 0)}
      className="flex-row justify-between   items-center"
      style={{paddingVertical: vs(17)}}>
      <Text className="font-inbl text-blp" style={{fontSize: ms(30)}}>
        {content}
      </Text>
      {isRight && (
        <TouchableOpacity className="p-5" onPress={() => openSheet()}>
          <HomeAdd />
        </TouchableOpacity>
      )}
    </Animated.View>
  );
};

export default DashBoardHeader;
