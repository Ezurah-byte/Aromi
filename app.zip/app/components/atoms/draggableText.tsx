import React, {useState, useRef} from 'react';
import {View, Text, PanResponder, StyleSheet} from 'react-native';

const DraggableText = ({text}) => {
  const [textWidth, setTextWidth] = useState(200);
  const [textHeight, setTextHeight] = useState(30);
  const [position, setPosition] = useState({x: 0, y: 0});
  const [parentWidth, setParentWidth] = useState(0);
  const [parentHeight, setParentHeight] = useState(0);

  const panResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onPanResponderMove: (e, gestureState) => {
        const newX = position.x + gestureState.dx;
        const newY = position.y + gestureState.dy;

        const constrainedX = Math.max(
          0,
          Math.min(newX, parentWidth - textWidth),
        );
        const constrainedY = Math.max(
          0,
          Math.min(newY, parentHeight - textHeight),
        );

        setPosition({x: constrainedX, y: constrainedY});
      },
      onPanResponderRelease: () => {},
    }),
  ).current;

  return (
    <View
      style={styles.container}
      onLayout={event => {
        const {width, height} = event.nativeEvent.layout;
        setParentWidth(width);
        setParentHeight(height);
      }}>
      <View
        style={[
          styles.draggable,
          {
            width: textWidth,
            height: textHeight,
            transform: [{translateX: position.x}, {translateY: position.y}],
          },
        ]}
        {...panResponder.panHandlers}>
        <Text
          onLayout={event => {
            const {width, height} = event.nativeEvent.layout;
            setTextWidth(width);
            setTextHeight(height);
          }}
          style={styles.text}>
          {text}
        </Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  draggable: {
    position: 'absolute',
    backgroundColor: 'lightgrey',
    justifyContent: 'center',
    alignItems: 'center',
  },
  text: {
    fontSize: 16,
  },
});

export default DraggableText;
