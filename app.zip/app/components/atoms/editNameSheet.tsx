import {View, TouchableOpacity, Text, Image} from 'react-native';
import React, {useMemo, useCallback, useState} from 'react';
import BottomSheet, {
  BottomSheetView,
  BottomSheetBackdrop,
  BottomSheetScrollView,
} from '@gorhom/bottom-sheet';
import {HeaderText, InputField} from '@atoms/index';
import {sizeConfig} from '@utils/sizeConfig';
import {CloseIcon} from '@vectors/vectorImages';

import {TextField} from '@molecules/index';
import {Colors} from '@theme/colors';
import Button from './button';
// import {useReducedMotion} from 'react-native-reanimated';

const EditNameSheet = ({modalRef, closeSheet, snap, name, handleName}) => {
  const {ms, vs} = sizeConfig;
  // const reducedMotion = useReducedMotion();
  const [editName, setEditName] = useState(name || '');

  const handleSheetChanges = useCallback((index: number) => {
    console.log('handleSheetChanges', index);
    // index == -1 && closeSheet();
  }, []);

  return (
    <BottomSheet
      // animateOnMount={false}
      // enableContentPanningGesture={false}
      // keyboardBehavior="interactive"
      // keyboardBlurBehavior="restore"
      enableHandlePanningGesture={false}
      handleComponent={null}
      backdropComponent={props => (
        <BottomSheetBackdrop
          pressBehavior="none"
          {...props}
          disappearsOnIndex={-1}
          appearsOnIndex={0}
        />
      )}
      enableDynamicSizing
      ref={modalRef}
      // index={1}
      // snapPoints={snapPoints}
      onChange={handleSheetChanges}>
      <BottomSheetScrollView scrollEnabled={false}>
        <View className={'py-4'}>
          <View
            className="flex-row justify-between my-3"
            style={{paddingHorizontal: ms(15)}}>
            <HeaderText content={'Tray Name'} size={vs(15)} />
            <TouchableOpacity
              onPress={() => {
                closeSheet();
              }}>
              <CloseIcon />
            </TouchableOpacity>
          </View>

          <View className="mx-4">
            <TextField
              {...{
                label: 'Name your tray',
                currentValue: editName,
                handleChange: setEditName,
                placeholder: 'Enter your name',
                holderColor: Colors.gy,
                inputStyle: {
                  marginLeft: sizeConfig.ms(7),
                },
              }}
            />

            <View style={{paddingVertical: vs(15)}}>
              <Button
                {...{
                  onClick: () => {
                    handleName(editName);
                  },
                  label: 'Save',
                  // border: true,
                  // bcl: 'bg-vt',
                  // bcc: 'border-vt',
                  // c: 'text-w',
                  enable: true,
                }}
              />
            </View>
          </View>
        </View>
      </BottomSheetScrollView>
    </BottomSheet>
  );
};

export default EditNameSheet;
