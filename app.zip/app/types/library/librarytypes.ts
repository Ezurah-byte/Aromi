import type {PayloadAction} from '@reduxjs/toolkit';

export interface AuthLibrary {
  token: string;
}

interface Item {
  [key: string]: any;
}
export interface UserSlice {
  number?: any;
  name: string;
  trays: Item[];
  wifiCred: {
    ssid?: string | null;
    password?: string | null;
  };
}
export type {PayloadAction};
