import {createApi, fetchBaseQuery} from '@reduxjs/toolkit/query/react';

export const apiHandler = createApi({
  reducerPath: 'apiHandler',
  baseQuery: fetchBaseQuery({
    baseUrl: 'https://api-receipe-generator.katomaran.tech/',
  }),
  endpoints: builder => ({
    getRecips: builder.mutation({
      query: ({recipeData}) => ({
        url: 'get_suggested_recipes',
        method: 'POST',
        body: recipeData,
      }),
    }),
  }),
});

export const {useGetRecipsMutation} = apiHandler;
