import {configureStore} from '@reduxjs/toolkit';
import authSlice from './features/auth/authSlice';
import userSlice from './features/auth/userSlice';
import {apiHandler} from './service/apiSlice';

export const store = configureStore({
  reducer: {
    auth: authSlice,
    user: userSlice,
    [apiHandler.reducerPath]: apiHandler.reducer,
  },

  middleware: getDefaultMiddleware =>
    getDefaultMiddleware().concat(apiHandler.middleware),
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
