import {createSlice} from '@reduxjs/toolkit';
import {UserSlice} from '@types/library/librarytypes';
import {storage} from '@utils/index';

const initialState: UserSlice = {
  name: '',
  number: null,
  wifiCred: {
    ssid: null,
    password: null,
  },
  trays: [],
};

export const userSlice = createSlice({
  name: 'userData',
  initialState,
  reducers: {
    setUser: (state, action) => {
      console.log(
        action.payload.name,
        'token toolkit%%%%%%%%%%%%%%%%',
        action.payload.data,
      );

      if (action.payload.name == 'allData') {
        state.name = action.payload.data.name;
        state.number = action.payload.data.number;
        state.wifiCred = action.payload.data.wifiCred;
        state.trays = action.payload.data.trays;
      } else {
        state[action.payload.name] = action.payload.data;
      }
      storage.set(state.number, JSON.stringify(state));
      const userDataStrogae = storage.getString(state.number);
      console.log(userDataStrogae, 'userDataStrogae storage');
    },

    setJar: (state, action) => {
      console.log('setJar init');
      try {
        console.log(action.payload.data.id, 'setJar trays', state.trays);
        const trayIndex = state.trays.findIndex(
          item => item.id === action.payload.data.id,
        );
        state.trays[trayIndex].jars = action.payload.data.jars;
        console.log('setJar tray Data', state);
      } catch (e) {
        console.log('setJar tray Data error', e);
      }
      storage.set(state.number, JSON.stringify(state));
      const userDataStrogae = storage.getString(state.number);
      console.log(userDataStrogae, 'userDataStrogae storage');
    },

    updateJar: (state, action) => {
      try {
        console.log(action.payload.data.id, 'setJar trays', state.trays);
        const trayIndex = state.trays.findIndex(
          item => item.id === action.payload.data.id,
        );
        const jarIndex = state?.trays[trayIndex]?.jars?.findIndex(
          item => item.id === action.payload.data.jarId,
        );
        console.log(
          jarIndex,
          'action.payload.data.jarData',
          action.payload.data.jarData,
        );
        state.trays[trayIndex].jars[jarIndex] = action.payload.data.jarData;
        console.log('setJar tray Data', state);
      } catch (e) {
        console.log('setJar tray Data error', e);
      }
      storage.set(state.number, JSON.stringify(state));
      const userDataStrogae = storage.getString(state.number);
      console.log(userDataStrogae, 'userDataStrogae storage');
    },

    updateTray: (state, action) => {
      try {
        const trayIndex = state.trays.findIndex(
          item => item.id === action.payload.data.id,
        );
        console.log(
          trayIndex,
          state?.trays?.[trayIndex],
          'tray update trat',
          action.payload.name,
          action.payload.data,
        );
        state.trays[trayIndex][action.payload.name] = action.payload.data.value;
      } catch (e) {
        console.log(e, 'update Tray error');
      }
    },
  },
});

export const {setUser, setJar, updateJar, updateTray} = userSlice.actions;

export const userState = (state: any) => state.userData;

export default userSlice.reducer;
