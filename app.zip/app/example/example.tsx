import React, {useEffect, useState} from 'react';

import {
  SafeAreaView,
  StatusBar,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  FlatList,
  TextInput,
  Platform,
  ToastAndroid,
  Keyboard,
} from 'react-native';

import {
  ESPProvisionManager,
  ESPTransport,
  ESPSecurity,
  ESPDevice,
} from '@orbital-systems/react-native-esp-idf-provisioning';
import {Button, Modal} from '@atoms/index';

function Example(): React.JSX.Element {
  const [wifiDevices, setWifiDevices] = useState(null);
  const [bleDevices, setBleDevices] = useState([]);
  const [password, setpassword] = useState('');
  const [currentDevice, setConnectedDevice] = useState(null);
  const [wifiItem, setWifiItem] = useState(null);
  const [path, setPath] = useState('');
  const [customData, setCustomData] = useState('');
  const [isProvisioned, setIsProvisioned] = useState(false);
  const [isModal, setIsModal] = useState(false);
  const [loaderContent, setLoaderContent] = useState('');
  const [type, setType] = useState('search');

  useEffect(() => {
    console.log('Ble UseEffect');

    orgesp();
  }, []);

  const orgesp = async () => {
    console.log('Devices ESP INIT', JSON.stringify(ESPProvisionManager));
    setType('search');
    setIsModal(true);
    setLoaderContent('Searching...');
    try {
      let prefix = 'AR';
      let transport = ESPTransport.ble;
      let security = ESPSecurity.secure2;
      const devices = await ESPProvisionManager.searchESPDevices(
        prefix,
        transport,
        security,
      );
      console.log(devices, 'Devices ESP');
      setBleDevices(devices);
      setIsModal(false);
    } catch (e) {
      console.log(e, 'Error Esp Scan');
      setIsModal(false);
      ToastAndroid.show('Search Again...', ToastAndroid.SHORT);
    }
  };
  const handleConnectAndWifi = async item => {
    try {
      setIsModal(true);
      setLoaderContent('Creating...');
      console.log(
        'init  ',
        item.security,
        item.security == 0
          ? ESPSecurity.unsecure
          : item.security == 1
          ? ESPSecurity.secure
          : ESPSecurity.secure2,
      );

      const device = new ESPDevice({
        name: item.name,
        transport: ESPTransport.ble,
        security:
          item.security == 0
            ? ESPSecurity.unsecure
            : item.security == 1
            ? ESPSecurity.secure
            : ESPSecurity.secure2,
      });
      // Connect to device with proofOfPossession
      console.log('Connecting to device', device);
      const proofOfPossession = 'abcd1234';
      try {
        setLoaderContent('Possesioning...');

        console.log('proofOfPossession init', device);

        await device.setProofOfPossession(proofOfPossession);
        console.log('proofOfPossession complete');
      } catch (error) {
        console.log('proofOfPossession error', error);
        setIsModal(false);
        setType('searching');
        ToastAndroid.show('Possessioning Failed', ToastAndroid.SHORT);
      }

      try {
        setLoaderContent('Connecting...');
        console.log('Connecting to device init', device);
        await device?.connect(proofOfPossession, null, 'wifiprov');
        // await device.connect(proofOfPossession, null, 'wifiprov');
        console.log('Connecting to device CONENETCJKHBJHDJHB');
        setConnectedDevice(device);
        try {
          console.log('getVersionInfo to init');
          const getVersionInfo = await device.getVersionInfo();
          console.log('getVersionInfo to device', getVersionInfo);
        } catch (err) {
          setIsModal(false);
          setType('searching');
          ToastAndroid.show('getVersionInfo Failed', ToastAndroid.SHORT);
          console.log('getVersionInfo to error', err);
        }

        try {
          console.log('getDeviceCapabilities to init');
          const getDeviceCapabilities = await device.getDeviceCapabilities();
          console.log('getDeviceCapabilities to device', getDeviceCapabilities);
        } catch (err) {
          setIsModal(false);
          setType('searching');
          ToastAndroid.show('getDeviceCapabilities Failed', ToastAndroid.SHORT);
          console.log('getDeviceCapabilities to error', err);
        }

        try {
          console.log('getSecurityType to init');
          const getSecurityType = await device.getSecurityType();
          console.log('getSecurityType to device', getSecurityType);
        } catch (err) {
          setIsModal(false);
          setType('searching');
          ToastAndroid.show('getSecurityType Failed', ToastAndroid.SHORT);
          console.log('getSecurityType to error', err);
        }

        try {
          setLoaderContent('Scaning Wifi...');

          const wifiList = await device?.scanWifiList();
          console.log('Connecting to wifis', wifiList);
          setWifiDevices(wifiList);
          setIsModal(false);
          setType('wifi');
        } catch (err) {
          setIsModal(false);
          setType('searching');
          ToastAndroid.show('scanWifiList Failed', ToastAndroid.SHORT);
          console.log('Connecting to wifis eror', err);
        }
      } catch (err) {
        console.log('Connecting to erro ', err);
      }
    } catch (err) {
      console.log('init err ', err);
    }
  };
  const handleProvision = async password => {
    try {
      Keyboard.dismiss();
      setIsModal(true);
      setLoaderContent('Sharing Cred...');
      console.log('Wifi Connect', password);
      const feedback = await currentDevice?.provision(wifiItem.ssid, password);
      console.log('Provision Done', feedback);

      currentDevice?.disconnect();
      setIsProvisioned(true);
      setIsModal(false);

      console.log('Provision Disconnect', password);
    } catch (e) {
      setIsModal(false);
      ToastAndroid.show('Password Incorrect', ToastAndroid.SHORT);

      console.log('Provision Error', e);
    }
  };
  const handleCustomData = async () => {
    try {
      Keyboard.dismiss();

      console.log('handleCustomData init');
      ToastAndroid.show('Data Sending to Device', ToastAndroid.SHORT);

      const espResponse = await currentDevice.sendData(
        'custom-data',
        customData,
      );
      ToastAndroid.show('Data Recieved in Device', ToastAndroid.SHORT);

      console.log('handleCustomData', espResponse);
    } catch (e) {
      ToastAndroid.show('Error in Data Share', ToastAndroid.SHORT);

      console.log('handleCustomData Error', e);
    }
  };

  const handleButton = () => {
    if (type == 'search') {
      orgesp();
    }
    if (wifiDevices?.length > 0) {
      currentDevice?.disconnect();
      setWifiDevices(null);
      setBleDevices([]);
      setpassword('');
      setConnectedDevice(null);
      setWifiItem(null);
      setPath('');
      setCustomData('');
      setIsProvisioned(false);
      setIsModal(false);
      setLoaderContent('');
      setType('search');
    }
  };
  const RenderWifiDevice = ({item}: {item: any}) => {
    return (
      <TouchableOpacity
        key={item.ssid}
        onPress={async () => {
          setWifiItem(item);
        }}
        style={{
          backgroundColor: 'white',
          borderColor: '#a7bbd2',
          borderWidth: 1,
          marginHorizontal: 20,
          borderRadius: 10,
          elevation: 10,
          paddingVertical: 10,
          paddingHorizontal: 20,
          gap: 10,
        }}>
        <Text style={{color: 'black', fontSize: 15}}>{item.ssid}</Text>
        <Text style={{color: 'grey', fontSize: 11}}>{item.rssi}</Text>
      </TouchableOpacity>
    );
  };

  const RenderBleDevice = ({item}: {item: any}) => {
    return (
      <TouchableOpacity
        key={item.name}
        onPress={() => {
          if (Platform.OS == 'android') {
            handleConnectAndWifi(item);
            // handleConnectAndWifi(item);
            // handleConnectAndWifi(item);
          } else {
            handleConnectAndWifi(item);
          }
        }}
        className="border-nvt border-[0.3px]"
        style={{
          backgroundColor: 'white',
          marginHorizontal: 20,
          borderRadius: 10,
          elevation: 10,
          paddingVertical: 10,
          paddingHorizontal: 20,
          gap: 10,
        }}>
        <Text style={{color: 'black', fontSize: 15}}>{item.name}</Text>
        <Text style={{color: 'grey', fontSize: 11}}>{item.security}</Text>
      </TouchableOpacity>
    );
  };

  return (
    <SafeAreaView style={{backgroundColor: '#F5F7FA', flex: 1, paddingTop: 50}}>
      <StatusBar
        translucent
        barStyle={'dark-content'}
        backgroundColor={'transparent'}
      />

      <View style={{}}>
        {isProvisioned && (
          <View className="h-full justify-center items-center">
            <Text
              className="text-center text-blp font-in_sbl"
              style={{fontSize: 18}}>
              Provisioning Succesfully Done
            </Text>
          </View>
        )}
        {wifiItem && !isProvisioned && (
          <View
            className="border-nvt border-[0.3px]"
            style={{
              backgroundColor: 'white',
              marginHorizontal: 20,
              borderRadius: 10,
              elevation: 10,
              paddingVertical: 10,
              paddingHorizontal: 20,
              gap: 10,
            }}>
            <View style={{}}>
              <Text style={{color: 'black', fontSize: 15, textAlign: 'center'}}>
                WIFI Password
              </Text>
            </View>
            {/* <Text style={{color: 'black'}}>{currentWifi.SSID}</Text>
            <Text
              style={{
                color: 'black',
              }}>{`${currentWifi?.SSID}//${password}`}</Text> */}
            <TextInput
              style={styles.input}
              placeholderTextColor="#d0dae7"
              placeholder="Type Wifi Password"
              value={password}
              onChangeText={setpassword}
            />
            <TouchableOpacity
              style={{
                marginTop: 10,
                backgroundColor: '#a7bbd2',
                width: '30%',
                height: 35,
                justifyContent: 'center',
                borderRadius: 10,
                alignSelf: 'center',
              }}
              onPress={() => handleProvision(password)}>
              <Text style={{color: '#31445b', textAlign: 'center'}}>
                Submit
              </Text>
            </TouchableOpacity>
          </View>
        )}

        {wifiItem && !isProvisioned && (
          <View
            className="border-nvt border-[0.3px]"
            style={{
              backgroundColor: 'white',
              marginHorizontal: 20,
              borderRadius: 10,
              elevation: 10,
              paddingVertical: 10,
              paddingHorizontal: 20,
              gap: 10,
              marginTop: 20,
            }}>
            <View style={{}}>
              <Text style={{color: 'black', fontSize: 15, textAlign: 'center'}}>
                Path
              </Text>
            </View>
            {/* <Text style={{color: 'black'}}>{currentWifi.SSID}</Text>
            <Text
              style={{
                color: 'black',
              }}>{`${currentWifi?.SSID}//${password}`}</Text> */}
            <TextInput
              style={styles.input}
              placeholderTextColor="#d0dae7"
              placeholder="Type Path"
              value={'custom-data'}
              onChangeText={setPath}
              editable={false}
            />

            <View style={{}}>
              <Text style={{color: 'black', fontSize: 15, textAlign: 'center'}}>
                Custom Data
              </Text>
            </View>
            {/* <Text style={{color: 'black'}}>{currentWifi.SSID}</Text>
            <Text
              style={{
                color: 'black',
              }}>{`${currentWifi?.SSID}//${password}`}</Text> */}
            <TextInput
              style={styles.input}
              placeholderTextColor="#d0dae7"
              placeholder="Type Path"
              value={setCustomData}
              onChangeText={setCustomData}
            />
            <TouchableOpacity
              style={{
                marginTop: 10,
                backgroundColor: '#a7bbd2',
                width: '30%',
                height: 35,
                justifyContent: 'center',
                borderRadius: 10,
                alignSelf: 'center',
              }}
              onPress={() => handleCustomData()}>
              <Text style={{color: '#31445b', textAlign: 'center'}}>
                Submit
              </Text>
            </TouchableOpacity>
          </View>
        )}

        {wifiDevices && !wifiItem && (
          <View style={{}}>
            <Text
              style={{
                color: 'black',
                fontSize: 17,
                textAlign: 'center',
                marginBottom: 10,
                fontWeight: '800',
                letterSpacing: 1,
              }}>
              Availble Devices
            </Text>
            {wifiDevices?.length > 0 ? (
              <FlatList
                data={wifiDevices}
                contentContainerStyle={{rowGap: 12, paddingBottom: 100}}
                renderItem={RenderWifiDevice}
                keyExtractor={item => item.id}
              />
            ) : (
              <View>
                <Text
                  className="text-center text-blp font-in_sbl"
                  style={{fontSize: 18}}>
                  No WiFi Found
                </Text>
              </View>
            )}
          </View>
        )}

        {bleDevices && !wifiDevices && (
          <View>
            <Text
              style={{
                color: 'black',
                fontSize: 17,
                textAlign: 'center',
                marginBottom: 10,
                fontWeight: '800',
                letterSpacing: 1,
              }}>
              Availble Devices
            </Text>
            <View className="pb-10">
              {bleDevices?.length > 0 ? (
                <FlatList
                  data={bleDevices}
                  contentContainerStyle={{rowGap: 12, paddingBottom: 100}}
                  renderItem={RenderBleDevice}
                  keyExtractor={item => item.id}
                />
              ) : (
                <View className=" h-full justify-center items-center">
                  {!isModal && (
                    <Text
                      className="text-center text-blp font-in_sbl"
                      style={{fontSize: 18}}>
                      No Device Found
                    </Text>
                  )}
                </View>
              )}
            </View>
          </View>
        )}
      </View>
      <View className="absolute bottom-2 w-full px-10">
        <Button
          {...{
            onClick: handleButton,
            label: type == 'wifi' ? 'Back Home' : 'Search Again',
            border: true,
            bcl: 'bg-w',
            bcc: 'border-vt',
            c: 'text-vt',
          }}
        />
      </View>
      {isModal && (
        <Modal type={'loader'} close={setIsModal} content={loaderContent} />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  sectionContainer: {
    marginTop: 32,
    paddingHorizontal: 24,
  },
  sectionTitle: {
    fontSize: 24,
    fontWeight: '600',
  },
  sectionDescription: {
    marginTop: 8,
    fontSize: 18,
    fontWeight: '400',
  },
  highlight: {
    fontWeight: '700',
  },
  input: {
    height: 40,
    borderColor: '#d0dae7',
    borderWidth: 1,
    paddingHorizontal: 8,
    color: '#577aa0',
    borderRadius: 10,
  },
  text: {
    marginTop: 16,
    fontSize: 16,
  },
});

export default Example;
