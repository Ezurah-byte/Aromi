const {moderateScale} = require('react-native-size-matters');

module.exports = {
  sm: moderateScale(20),
};
