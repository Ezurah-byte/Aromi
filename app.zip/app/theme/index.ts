import {Colors} from './colors';

export {Colors};
