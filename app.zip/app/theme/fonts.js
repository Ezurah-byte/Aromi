module.exports = {
  inbk: ['Inter-Black'],
  inbl: ['Inter-Bold'],
  inebl: ['Inter-ExtraBold'],
  inel: ['Inter-ExtraLight'],
  inl: ['Inter-Light'],
  inm: ['Inter-Medium'],
  inr: ['Inter-Regular'],
  in_sbl: ['Inter-SemiBold'],
  int: ['Inter-Thin'],
};
